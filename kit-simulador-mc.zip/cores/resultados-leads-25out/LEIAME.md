# Leads do T1-G contra os cores de 25/out

- screen.js / screen.jsonl: todas as prévias e Megas, 30 batalhas, semente 11, contra os 11 cores antigos + N1, N1F, N3.
- top.js → top.json; confirm.js → confirm.jsonl (top 6 + linha antiga da §10.3, 200 fixa + 200 livre, semente 23); rank.js → rank.json.
- lib2.js, screen2.js, confirm2.js: C9 novo (C9M) e prévia geral contra o conjunto novo (B6, C1–C4, N3, C6–C8, C9M, N1F) → screen2/confirm2/top2/rank2.
- Os scripts usam caminhos relativos a sim25/v2 (../../simular.js, ../../cores/...). Para rodar de novo, copie esta pasta para sim25/v2 na raiz do kit.
- cores.js já tem os cores novos (C5 = N3, C9 = C9M, C10 = N1F); os antigos ficam em CORES_ANTIGOS e a variante Raichu-X em CORES_VARIANTES.
- calc-cores25out.json/.txt: cálculos do champions-multicalc usados na §10.3 do PLAYBOOK-T1-G.
