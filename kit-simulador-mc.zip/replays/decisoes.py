#!/usr/bin/env python3
"""Reconstrói cada decisão das partidas com o estado no início do turno.
Saída: decisoes.jsonl (uma linha por decisão de golpe/troca) e megas.jsonl (uma linha
por oportunidade de Mega). Só Reg M-C; ignora contas com "bot" no nome.
"""
import glob, json, os, re

DIR = os.path.dirname(os.path.abspath(__file__))
NOSSO = 'bernardomgj'
GOLPES = json.load(open(os.path.join(DIR, 'golpes.json')))
TID2NOME = {re.sub(r'[^a-z0-9]', '', k.lower()): k for k in GOLPES}
STONES = {re.sub(r'[^a-z0-9]', '', k.lower()) for k in json.load(open(os.path.join(DIR, 'megastones.json')))}
PROTECT = {'Protect', 'Detect', 'Spiky Shield', "King's Shield", 'Baneful Bunker', 'Silk Trap', 'Burning Bulwark'}
BOT = re.compile(r'bot', re.I)


def tid(s):
    return re.sub(r'[^a-z0-9]', '', (s or '').lower())


def base(sp):
    return re.sub(r'-Mega(-[XYZ])?$', '', sp.split(',')[0].strip())


def ident(s):
    m = re.match(r'(p\d)([ab]?): ?(.*)', s or '')
    return (m.group(1), m.group(2), m.group(3)) if m else (None, None, None)


def hp_status(campo):
    # "73/100 par" -> (73.0, 'par'); "0 fnt" -> (0, 'fnt')
    partes = campo.split(' ')
    status = partes[1] if len(partes) > 1 else ''
    if partes[0] == '0':
        return 0.0, 'fnt'
    a, b = partes[0].split('/')
    a = re.sub(r'[^0-9.]', '', a); b = re.sub(r'[^0-9.]', '', b)
    return round(100 * float(a) / float(b), 1), status


def ler_sets(txt):
    sets = {}
    for parte in txt.split(']'):
        c = parte.split('|')
        if len(c) < 7:
            continue
        sp = base(c[0])
        sets[sp] = {'item': tid(c[2]), 'ability': tid(c[3]),
                    'moves': [TID2NOME.get(tid(m), m) for m in c[4].split(',') if m], 'nature': c[5]}
    return sets


def processar(path, fonte):
    d = json.load(open(path))
    if 'regmc' not in d.get('formatid', ''):
        return [], []
    if any(BOT.search(p) for p in d['players']):
        return [], []
    linhas = d['log'].split('\n')
    jog = {}; nosso = None; sets = {'p1': {}, 'p2': {}}
    for l in linhas:
        c = l.split('|')
        if len(c) > 3 and c[1] == 'player' and c[3]:
            jog[c[2]] = c[3]
            if c[3].lower() == NOSSO:
                nosso = c[2]
        if len(c) > 3 and c[1] == 'showteam':
            sets[c[2]] = ler_sets('|'.join(c[3:]))
    grupo = {s: ('publico' if not nosso else ('nosso' if s == nosso else 'adv_nosso')) for s in ('p1', 'p2')}

    mons = {}       # (side, nick) -> estado
    ativos = {}     # (side, slot) -> nick
    campo = {'weather': '', 'terrain': '', 'tr': False, 'tw': {'p1': False, 'p2': False},
             'telas': {'p1': [], 'p2': []}}
    mega_usada = {'p1': False, 'p2': False}
    turno = 0
    snap = None
    decisoes, megas = [], []
    pendentes_mega = {}
    movs = 0
    fim = False

    def foto():
        f = {'campo': json.loads(json.dumps(campo)), 'ativos': {}}
        for (s, slot), nick in ativos.items():
            m = mons.get((s, nick))
            if m and m['hp'] > 0:
                f['ativos'][s + slot] = {'especie': m['especie'], 'hp': m['hp'], 'status': m['status'],
                                         'boosts': dict(m['boosts']), 'megado': m['megado'],
                                         'turnos_campo': m['turnos_campo'], 'nick': nick}
        return f

    def contexto(s, slot):
        eu = snap['ativos'].get(s + slot)
        outro = 'b' if slot == 'a' else 'a'
        foe = 'p2' if s == 'p1' else 'p1'
        st = sets[s].get(eu['especie'], {})
        return {
            'especie': eu['especie'], 'hp': eu['hp'], 'status': eu['status'], 'boosts': eu['boosts'],
            'megado': eu['megado'], 'primeiro_turno': eu['turnos_campo'] == 0,
            'moveset': st.get('moves', []), 'item': st.get('item', ''), 'ability': st.get('ability', ''),
            'aliado': snap['ativos'].get(s + outro),
            'oponentes': [dict(v, slot=k[-1]) for k, v in snap['ativos'].items() if k.startswith(foe)],
            'weather': snap['campo']['weather'], 'terrain': snap['campo']['terrain'], 'tr': snap['campo']['tr'],
            'tw_proprio': snap['campo']['tw'][s], 'tw_oponente': snap['campo']['tw'][foe],
            'telas_proprio': snap['campo']['telas'][s], 'telas_oponente': snap['campo']['telas'][foe],
        }

    for l in linhas:
        if not l.startswith('|'):
            continue
        c = l.split('|')
        cmd = c[1] if len(c) > 1 else ''
        if cmd == 'turn':
            # fecha oportunidades de Mega do turno anterior
            for k, v in pendentes_mega.items():
                megas.append(v)
            pendentes_mega = {}
            turno = int(c[2])
            movs = 0
            fim = False
            snap = foto()
            # oportunidades de Mega neste turno
            for key, a in snap['ativos'].items():
                s, slot = key[:2], key[2]
                st = sets[s].get(a['especie'], {})
                if not mega_usada[s] and not a['megado'] and st.get('item') in STONES:
                    pendentes_mega[(s, a['nick'])] = {'id': d['id'], 'grupo': grupo[s], 'jogador': jog.get(s, '?'),
                                                       'turno': turno, 'lado': s, 'especie': a['especie'],
                                                       'primeiro_turno': a['turnos_campo'] == 0, 'fez': False}
            for k, m in mons.items():
                if m['ativo']:
                    m['turnos_campo'] += 1
            continue
        if cmd in ('switch', 'drag', 'replace'):
            s, slot, nick = ident(c[2])
            hp, status = hp_status(c[4]) if len(c) > 4 else (100.0, '')
            antigo = ativos.get((s, slot))
            if antigo and (s, antigo) in mons:
                mons[(s, antigo)]['ativo'] = False
                mons[(s, antigo)]['boosts'] = {}
            prev = mons.get((s, nick), {})
            mons[(s, nick)] = {'especie': base(c[3]), 'hp': hp, 'status': status, 'boosts': {},
                               'megado': '-Mega' in c[3] or prev.get('megado', False),
                               'turnos_campo': 0, 'ativo': True}
            ativos[(s, slot)] = nick
            if turno > 0 and cmd == 'switch' and snap is not None:
                # troca voluntária = antes de qualquer golpe do turno e com o slot ocupado por alguém vivo na foto
                eu = snap['ativos'].get(s + slot)
                if eu and eu['nick'] == antigo and eu['nick'] != nick and not fim and movs == 0:
                    ctx = contexto(s, slot)
                    decisoes.append(dict(ctx, id=d['id'], grupo=grupo[s], jogador=jog.get(s, '?'), turno=turno,
                                         lado=s, slot=slot, acao='troca', golpe='(troca)', alvo_rel='', alvo_especie='',
                                         area=False, fonte=fonte))
            continue
        if cmd == 'turn':
            continue
        if cmd == 'move' and snap is not None:
            s, slot, nick = ident(c[2])
            extra = c[5:] if len(c) > 5 else []
            movs += 1
            if any('[from]' in x for x in extra):
                continue
            eu = snap['ativos'].get(s + slot)
            if not eu or eu['nick'] != nick:
                continue  # entrou no meio do turno: não decidiu com esta foto
            ts, tslot, tnick = ident(c[4]) if len(c) > 4 and c[4] else (None, None, None)
            alvo_rel = '' if not ts else ('proprio' if (ts == s and tnick == nick) else ('aliado' if ts == s else 'oponente'))
            alvo_sp = mons.get((ts, tnick), {}).get('especie', '') if ts else ''
            ctx = contexto(s, slot)
            decisoes.append(dict(ctx, id=d['id'], grupo=grupo[s], jogador=jog.get(s, '?'), turno=turno, lado=s,
                                 slot=slot, acao='golpe', golpe=c[3], alvo_rel=alvo_rel, alvo_especie=alvo_sp,
                                 alvo_slot=tslot or '', area=any(x.startswith('[spread]') for x in extra), fonte=fonte))
            continue
        if cmd in ('-damage', '-heal', '-sethp'):
            s, slot, nick = ident(c[2])
            if (s, nick) in mons and len(c) > 3:
                hp, status = hp_status(c[3])
                mons[(s, nick)]['hp'] = hp
                if status:
                    mons[(s, nick)]['status'] = status
        elif cmd == 'faint':
            s, slot, nick = ident(c[2])
            if (s, nick) in mons:
                mons[(s, nick)]['hp'] = 0
        elif cmd == '-status':
            s, slot, nick = ident(c[2])
            if (s, nick) in mons:
                mons[(s, nick)]['status'] = c[3]
        elif cmd == '-curestatus':
            s, slot, nick = ident(c[2])
            if (s, nick) in mons:
                mons[(s, nick)]['status'] = ''
        elif cmd in ('-boost', '-unboost'):
            s, slot, nick = ident(c[2])
            if (s, nick) in mons:
                b = mons[(s, nick)]['boosts']
                b[c[3]] = max(-6, min(6, b.get(c[3], 0) + (int(c[4]) if cmd == '-boost' else -int(c[4]))))
        elif cmd == '-setboost':
            s, slot, nick = ident(c[2])
            if (s, nick) in mons:
                mons[(s, nick)]['boosts'][c[3]] = int(c[4])
        elif cmd in ('-clearboost', '-clearallboost'):
            if cmd == '-clearallboost':
                for m in mons.values():
                    m['boosts'] = {}
            else:
                s, slot, nick = ident(c[2])
                if (s, nick) in mons:
                    mons[(s, nick)]['boosts'] = {}
        elif cmd == '-clearnegativeboost':
            s, slot, nick = ident(c[2])
            if (s, nick) in mons:
                mons[(s, nick)]['boosts'] = {k: v for k, v in mons[(s, nick)]['boosts'].items() if v > 0}
        elif cmd == 'detailschange' or cmd == '-formechange':
            s, slot, nick = ident(c[2])
            if (s, nick) in mons and '-Mega' in c[3]:
                mons[(s, nick)]['megado'] = True
        elif cmd == '-mega':
            s, slot, nick = ident(c[2])
            mega_usada[s] = True
            if (s, nick) in mons:
                mons[(s, nick)]['megado'] = True
            if (s, nick) in pendentes_mega:
                pendentes_mega[(s, nick)]['fez'] = True
        elif cmd == '-weather':
            campo['weather'] = '' if c[2] == 'none' else c[2]
        elif cmd == '-fieldstart':
            nome = c[2].replace('move: ', '')
            if nome == 'Trick Room':
                campo['tr'] = True
            elif 'Terrain' in nome:
                campo['terrain'] = nome
        elif cmd == '-fieldend':
            nome = c[2].replace('move: ', '')
            if nome == 'Trick Room':
                campo['tr'] = False
            elif 'Terrain' in nome:
                campo['terrain'] = ''
        elif cmd in ('-sidestart', '-sideend'):
            s = c[2][:2]
            nome = c[3].replace('move: ', '')
            if nome == 'Tailwind':
                campo['tw'][s] = cmd == '-sidestart'
            elif nome in ('Reflect', 'Light Screen', 'Aurora Veil'):
                if cmd == '-sidestart' and nome not in campo['telas'][s]:
                    campo['telas'][s].append(nome)
                elif cmd == '-sideend' and nome in campo['telas'][s]:
                    campo['telas'][s].remove(nome)
        if cmd in ('upkeep', 'faint'):
            fim = True
    for v in pendentes_mega.values():
        megas.append(v)
    return decisoes, megas


def main():
    fontes = {}
    for l in open(os.path.join(DIR, 'fontes.jsonl')):
        r = json.loads(l)
        fontes.setdefault(r['id'], r)
    rotulo = {k: v.get('rotulo', '') for k, v in fontes.items()}
    D, M = [], []
    for path in sorted(glob.glob(os.path.join(DIR, 'raw', '*.json'))):
        rid = os.path.basename(path)[:-5]
        dd, mm = processar(path, fontes.get(rid, {}).get('fonte', '?'))
        for x in dd:
            x['rotulo'] = rotulo.get(rid, '')
        D.extend(dd); M.extend(mm)
    with open(os.path.join(DIR, 'decisoes.jsonl'), 'w') as f:
        for x in D:
            f.write(json.dumps(x, ensure_ascii=False) + '\n')
    with open(os.path.join(DIR, 'megas.jsonl'), 'w') as f:
        for x in M:
            f.write(json.dumps(x, ensure_ascii=False) + '\n')
    print(f'{len(D)} decisões, {len(M)} oportunidades de Mega')


if __name__ == '__main__':
    main()
