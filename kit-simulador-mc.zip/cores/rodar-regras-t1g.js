// T1-G (Charizard) contra os 11 cores, prévia do bot, modelo de adversário, sementes fixas.
// Uso: node sim25/regras-t1g.js N "regrasNossas" "regrasDeles" saida.json
const fs=require('fs');const {simular}=require('../simular.js');const {CORES}=require('./cores.js');
const [,,N,ra,rb,out]=process.argv;const L=s=>(s||'').split(',').map(x=>x.trim()).filter(Boolean);
const t=fs.readFileSync('cores/T1G-CHARIZARD.txt','utf8');
(async()=>{const res={};let v=0,n=0;
for(const c of CORES){const r=await simular(t,c.text,{n:+N,nomes:['A',c.id],previaB:c.previaOpp,megaB:c.megaOpp,modeloB:'cores/modelo_adversario.json',semente:7,regrasA:L(ra),regrasB:L(rb)});
 const s=r.stats;res[c.id]={v:s.vitorias[0],n:s.batalhas,fb:s.fallbacks};v+=s.vitorias[0];n+=s.batalhas;}
res.total={v,n,wr:+(100*v/n).toFixed(2)};fs.writeFileSync(out,JSON.stringify(res,null,1));
console.log(`[${ra}] x [${rb}] ${res.total.wr}% (${v}/${n}) | `+CORES.map(c=>`${c.id} ${Math.round(100*res[c.id].v/res[c.id].n)}`).join(' '))})();
