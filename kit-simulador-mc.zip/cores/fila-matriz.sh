#!/bin/bash
# Roda cores/matriz.js para cada time assim que o resultado de cores/adversario.js fica pronto.
cd /home/claude; D=cores/resultados-28out/adv
for t in "$@"; do
  until [ -s $D/$t.json ]; do sleep 20; done
  node cores/matriz.js $t 80 > $D/$t-matriz.json 2> $D/$t-matriz.err
done
