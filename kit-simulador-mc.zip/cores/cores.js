// Os 11 cores de referência (instruções 0-A) montados para simulação. C5, C9 e C10 trocados em 25/out
// (03-META, complemento 25/out); previa/mega desses três = linha da §10.3 do PLAYBOOK-T1-G (T1-G Charizard).
// Sets: nature, SP, item e habilidade do pool do Team Atlas (index.html, MXD.POOL);
// golpes de suporte e o 5º/6º membros pelas listas do 03-META. SP completados
// com HP até 66 quando o pool somava 64. Itens trocados só para cumprir a Item Clause.
// previa/mega: prévia, lead e Mega recomendados para a T1-G (Atlas, entradas 13–23;
// regra de Mega do PLAYBOOK-T1-G §8.3).
// previaOpp/megaOpp: o que o core leva e com quem abre, pela definição da ameaça (instruções 0-A)
// e pelos leads citados no 03-META. Premissa nossa: os dados de lead do adversário são escassos.
'use strict';
const fs = require('fs');
const path = require('path');
const lista = id => fs.readFileSync(path.join(__dirname, 'candidatos', id + '.txt'), 'utf8');

const S = (species, item, ability, nature, evs, moves) =>
	`${species} @ ${item}\nAbility: ${ability}\nEVs: ${evs}\n${nature} Nature\n${moves.map(m => '- ' + m).join('\n')}\n`;
const team = (...sets) => sets.join('\n');

// ---- peças reutilizadas
const rilla = (m4 = 'High Horsepower') => S('Rillaboom', 'Miracle Seed', 'Grassy Surge', 'Adamant', '32 HP / 32 Atk / 2 Spe', ['Fake Out', 'Wood Hammer', 'Grassy Glide', m4]);
const incin = (item = 'Sitrus Berry') => S('Incineroar', item, 'Intimidate', 'Careful', '32 HP / 16 Def / 18 SpD', ['Fake Out', 'Parting Shot', 'Flare Blitz', 'Darkest Lariat']);
const zardY = S('Charizard', 'Charizardite Y', 'Blaze', 'Timid', '2 HP / 32 SpA / 32 Spe', ['Heat Wave', 'Weather Ball', 'Solar Beam', 'Protect']);
const sylveon = (m = ['Hyper Voice', 'Moonblast', 'Quick Attack', 'Protect']) => S('Sylveon', 'Fairy Feather', 'Pixilate', 'Modest', '32 HP / 32 SpA / 2 Def', m);
const farig = (item, m4 = 'Protect') => S('Farigiraf', item, 'Armor Tail', 'Bold', '32 HP / 16 Def / 18 SpD', ['Trick Room', 'Psychic', 'Helping Hand', m4]);
const kingambit = (item, m4 = 'Protect') => S('Kingambit', item, 'Defiant', 'Adamant', '32 HP / 32 Atk / 2 Spe', ['Kowtow Cleave', 'Sucker Punch', 'Iron Head', m4]);
const chompZ = (moves = ['Dragon Pulse', 'Earth Power', 'Power Gem', 'Protect']) => S('Garchomp', 'Garchompite Z', 'Rough Skin', 'Modest', '2 HP / 32 SpA / 32 Spe', moves);
const raichuY = S('Raichu', 'Raichunite Y', 'Lightning Rod', 'Timid', '2 HP / 32 SpA / 32 Spe', ['Zap Cannon', 'Focus Blast', 'Fake Out', 'Protect']);
const sneasler = item => S('Sneasler', item, 'Unburden', 'Adamant', '2 HP / 32 Atk / 32 Spe', ['Fake Out', 'Close Combat', 'Dire Claw', 'Protect']);
const archaludon = S('Archaludon', 'Leftovers', 'Stamina', 'Modest', '32 HP / 32 SpA / 2 SpD', ['Electro Shot', 'Dragon Pulse', 'Flash Cannon', 'Protect']);

const CORES = [
	{
		id: 'B6', nome: 'B6 (Whimsicott/Basculegion/Floette/Garchomp/Kingambit/Charizard-Y)', fonte: 'Atlas B6; Cary de Ortona (Louisville) para os sets',
		previa: ['Staraptor', 'Garchomp', 'Gallade', 'Gholdengo'], mega: ['Garchomp'],
		previaOpp: ['Whimsicott','Charizard','Kingambit','Floette-Eternal'], megaOpp: ['Charizard'],
		text: team(
			S('Whimsicott', 'Focus Sash', 'Prankster', 'Timid', '2 HP / 32 SpA / 32 Spe', ['Tailwind', 'Moonblast', 'Encore', 'Helping Hand']),
			S('Basculegion', 'Choice Scarf', 'Adaptability', 'Adamant', '2 HP / 32 Atk / 32 Spe', ['Last Respects', 'Wave Crash', 'Aqua Jet', 'Flip Turn']),
			S('Floette-Eternal', 'Floettite', 'Flower Veil', 'Modest', '2 HP / 32 SpA / 32 Spe', ['Moonblast', 'Dazzling Gleam', 'Calm Mind', 'Protect']),
			S('Garchomp', 'Life Orb', 'Rough Skin', 'Jolly', '2 HP / 32 Atk / 32 Spe', ['Dragon Claw', 'Stomping Tantrum', 'Earthquake', 'Protect']),
			kingambit('Chople Berry'),
			zardY),
	},
	{
		id: 'C1', nome: 'C1 Rios/Kelsch', fonte: 'Lista do Rios (Frankfurt 1º), sets do Cybertron no 03-META',
		previa: ['Indeedee-F', 'Staraptor', 'Garchomp', 'Gallade'], mega: ['Garchomp'],
		previaOpp: ['Raichu','Volcarona','Garchomp','Incineroar'], megaOpp: ['Raichu'],
		text: team(
			chompZ(),
			raichuY,
			S('Volcarona', 'Rocky Helmet', 'Flame Body', 'Timid', '32 HP / 10 Def / 24 Spe', ['Tailwind', 'Overheat', 'Struggle Bug', 'Rage Powder']),
			S('Gholdengo', 'Life Orb', 'Good as Gold', 'Modest', '17 HP / 7 SpA / 22 SpD / 20 Spe', ['Nasty Plot', 'Shadow Ball', 'Make It Rain', 'Protect']),
			rilla('U-turn'),
			incin()),
	},
	{
		id: 'C2', nome: 'C2 Sol com Chlorophyll', fonte: 'Lista do Ugarte (Louisville 1º); sets do pool',
		previa: ['Indeedee-F', 'Staraptor', 'Gallade', 'Garchomp'], mega: ['Staraptor', 'Garchomp'],
		previaOpp: ['Charizard','Venusaur','Sylveon','Garchomp'], megaOpp: ['Charizard'],
		text: team(
			zardY,
			S('Venusaur', 'Focus Sash', 'Chlorophyll', 'Modest', '2 HP / 32 SpA / 32 Spe', ['Sleep Powder', 'Sludge Bomb', 'Leaf Storm', 'Protect']),
			sylveon(['Moonblast', 'Hyper Voice', 'Yawn', 'Protect']),
			S('Garchomp', 'Choice Scarf', 'Rough Skin', 'Jolly', '2 HP / 32 Atk / 32 Spe', ['Dragon Claw', 'Rock Slide', 'Stomping Tantrum', 'Earthquake']),
			farig('Colbur Berry', 'Thunderbolt'),
			incin()),
	},
	{
		id: 'C3', nome: 'C3 TR com sol', fonte: 'Lista do Liu Li (Frankfurt 2º); sets do pool',
		previa: ['Indeedee-F', 'Gallade', 'Milotic', 'Garchomp'], mega: ['Garchomp'],
		previaOpp: ['Farigiraf','Torkoal','Sylveon','Incineroar'], megaOpp: [],
		text: team(
			S('Torkoal', 'Charcoal', 'Drought', 'Quiet', '32 HP / 32 SpA / 2 Def', ['Eruption', 'Weather Ball', 'Earth Power', 'Protect']),
			farig('Colbur Berry'),
			sneasler('White Herb'),
			sylveon(),
			S('Garchomp', 'Life Orb', 'Rough Skin', 'Jolly', '2 HP / 32 Atk / 32 Spe', ['Dragon Claw', 'Earthquake', 'Rock Slide', 'Protect']),
			incin()),
	},
	{
		id: 'C4', nome: 'C4 Chuva com Swampert-Mega', fonte: 'Lista do Nascimento (Recife 4º); sets do pool',
		previa: ['Indeedee-F', 'Gallade', 'Milotic', 'Garchomp'], mega: ['Garchomp'],
		previaOpp: ['Pelipper','Swampert','Archaludon','Grimmsnarl'], megaOpp: ['Swampert'],
		text: team(
			S('Swampert', 'Swampertite', 'Torrent', 'Adamant', '32 HP / 32 Atk / 2 Spe', ['Wave Crash', 'Earthquake', 'Ice Punch', 'Protect']),
			zardY,
			S('Pelipper', 'Focus Sash', 'Drizzle', 'Modest', '32 HP / 32 SpA / 2 SpD', ['Hurricane', 'Weather Ball', 'Tailwind', 'Wide Guard']),
			S('Venusaur', 'Life Orb', 'Chlorophyll', 'Modest', '2 HP / 32 SpA / 32 Spe', ['Sleep Powder', 'Sludge Bomb', 'Leaf Storm', 'Protect']),
			S('Grimmsnarl', 'Light Clay', 'Prankster', 'Sassy', '32 HP / 16 Def / 18 SpD', ['Spirit Break', 'Reflect', 'Light Screen', 'Fake Out']),
			archaludon),
	},
	{
		id: 'C5', nome: 'C5 Delphox-Mega + Floette-Mega + Incineroar + Sneasler + Sinistcha + Kingambit', fonte: 'mattia_vinti (Nice 50º), base /teams/ com SP; core trocado em 25/out (03-META, complemento 25/out)',
		previa: ['Garchomp', 'Volcarona', 'Charizard', 'Milotic'], mega: ['Garchomp'],
		previaOpp: undefined, megaOpp: undefined, // sem lead publicado: o modelo escolhe
		text: lista('N3'),
	},
	{
		id: 'C6', nome: 'C6 Floette/Salamence-Mega + Basculegion/Kingambit/Sneasler', fonte: 'Lista do El Bacha (Recife 3º) / Lett (Louisville 5º); sets do pool',
		previa: ['Staraptor', 'Gholdengo', 'Gallade', 'Garchomp'], mega: ['Staraptor', 'Garchomp'],
		previaOpp: ['Sneasler','Salamence','Floette-Eternal','Kingambit'], megaOpp: ['Salamence'],
		text: team(
			S('Salamence', 'Salamencite', 'Intimidate', 'Timid', '2 HP / 32 SpA / 32 Spe', ['Hyper Voice', 'Draco Meteor', 'Tailwind', 'Protect']),
			S('Floette-Eternal', 'Floettite', 'Flower Veil', 'Modest', '2 HP / 32 SpA / 32 Spe', ['Moonblast', 'Dazzling Gleam', 'Calm Mind', 'Protect']),
			S('Basculegion', 'Life Orb', 'Adaptability', 'Adamant', '2 HP / 32 Atk / 32 Spe', ['Last Respects', 'Wave Crash', 'Aqua Jet', 'Protect']),
			kingambit('Chople Berry'),
			sneasler('White Herb'),
			rilla('U-turn')),
	},
	{
		id: 'C7', nome: 'C7 Raichu-Y + Staraptor-Mega', fonte: 'Lista do JuanPabla (Limitless); sets da lista',
		previa: ['Indeedee-F', 'Gallade', 'Gholdengo', 'Garchomp'], mega: ['Garchomp'],
		previaOpp: ['Raichu','Staraptor','Gholdengo','Arcanine-Hisui'], megaOpp: ['Raichu'],
		text: team(
			S('Staraptor', 'Staraptite', 'Intimidate', 'Jolly', '2 HP / 32 Atk / 32 Spe', ['Close Combat', 'Brave Bird', 'Tailwind', 'Protect']),
			S('Arcanine-Hisui', 'Focus Sash', 'Rock Head', 'Jolly', '2 HP / 32 Atk / 32 Spe', ['Flare Blitz', 'Head Smash', 'Extreme Speed', 'Protect']),
			raichuY,
			S('Gholdengo', 'Life Orb', 'Good as Gold', 'Timid', '2 HP / 32 SpA / 32 Spe', ['Shadow Ball', 'Make It Rain', 'Nasty Plot', 'Protect']),
			rilla(),
			S('Sylveon', 'Fairy Feather', 'Pixilate', 'Modest', '32 HP / 32 SpA / 2 Def', ['Hyper Voice', 'Hyper Beam', 'Quick Attack', 'Detect'])),
	},
	{
		id: 'C8', nome: 'C8 Areia com Mega Tyranitar + Excadrill', fonte: 'Réplica JessdittaTTV B (03-META) + Corviknight do Ugarte; sets do pool',
		previa: ['Staraptor', 'Gallade', 'Garchomp', 'Milotic'], mega: ['Garchomp'],
		previaOpp: ['Tyranitar','Excadrill','Corviknight','Sneasler'], megaOpp: ['Tyranitar'],
		text: team(
			S('Indeedee', 'Choice Scarf', 'Psychic Surge', 'Modest', '2 HP / 32 SpA / 32 Spe', ['Expanding Force', 'Mystical Fire', 'Shadow Ball', 'Encore']),
			S('Sneasler', 'White Herb', 'Unburden', 'Jolly', '2 HP / 32 Atk / 32 Spe', ['Fake Out', 'Dire Claw', 'Close Combat', 'Coaching']),
			S('Corviknight', 'Psychic Seed', 'Mirror Armor', 'Careful', '32 HP / 16 Def / 18 SpD', ['Brave Bird', 'Power Trip', 'Bulk Up', 'Roost']),
			S('Milotic', 'Sitrus Berry', 'Competitive', 'Calm', '32 HP / 16 Def / 18 SpD', ['Scald', 'Ice Beam', 'Icy Wind', 'Recover']),
			S('Tyranitar', 'Tyranitarite', 'Sand Stream', 'Jolly', '2 HP / 32 Atk / 32 Spe', ['Rock Slide', 'Knock Off', 'Low Kick', 'Protect']),
			S('Excadrill', 'Focus Sash', 'Sand Rush', 'Adamant', '2 HP / 32 Atk / 32 Spe', ['High Horsepower', 'Iron Head', 'Rock Slide', 'Protect'])),
	},
	{
		id: 'C9', nome: 'C9 Perish Trap (Gengar-Mega + Incineroar + Rillaboom + Kommo-o)', fonte: 'Víctor Medina (VR Oct #1 10º, #2 12º); itens/natures/golpes da lista, SP pela convenção do pool; composição revista em 25/out',
		previa: ['Charizard', 'Garchomp', 'Gallade', 'Volcarona'], mega: ['Charizard'],
		previaOpp: ['Gengar','Rillaboom','Incineroar','Kommo-o'], megaOpp: ['Gengar'],
		text: lista('C9M'),
	},
	{
		id: 'C10', nome: 'C10 Chuva com Golisopod-Mega + Pelipper (+ Floette-Mega)', fonte: 'DitzyDoes (Louisville 39º), base /teams/ com SP; variante Raichu-Mega-X em CORES_VARIANTES (N1); core trocado em 25/out',
		previa: ['Gallade', 'Indeedee-F', 'Charizard', 'Milotic'], mega: ['Charizard'],
		previaOpp: undefined, megaOpp: undefined, // sem lead publicado: o modelo escolhe
		text: lista('N1F'),
	},
];

// Cores substituídos em 25/out (histórico; não entram nas simulações padrão)
const CORES_ANTIGOS = [
	{
		id: 'C5-antigo', nome: 'C5 Golisopod-Mega + Politoed + Farigiraf', fonte: 'Lista do Begot (Recife 2º); sets do pool',
		previa: ['Indeedee-F', 'Gallade', 'Garchomp', 'Milotic'], mega: ['Garchomp'],
		previaOpp: ['Politoed','Farigiraf','Golisopod','Archaludon'], megaOpp: ['Golisopod'],
		text: team(
			chompZ(),
			S('Golisopod', 'Golisopite', 'Emergency Exit', 'Adamant', '32 HP / 32 Atk / 2 Spe', ['First Impression', 'Leech Life', 'Iron Head', 'Sucker Punch']),
			S('Politoed', 'Damp Rock', 'Drizzle', 'Calm', '32 HP / 16 Def / 18 SpD', ['Weather Ball', 'Muddy Water', 'Ice Beam', 'Protect']),
			archaludon,
			farig('Colbur Berry'),
			incin()),
	},
	{
		id: 'C9-antigo', nome: 'C9 Perish Trap', fonte: 'Lista do Torviv (VR Oct #1) + Incineroar da lista do Joey (Louisville); sets do pool',
		previa: ['Indeedee-F', 'Gallade', 'Gholdengo', 'Milotic'], mega: [],
		previaOpp: ['Gengar','Politoed','Kommo-o','Kingambit'], megaOpp: ['Gengar'],
		text: team(
			S('Gengar', 'Gengarite', 'Cursed Body', 'Modest', '2 HP / 32 SpA / 32 Spe', ['Shadow Ball', 'Sludge Bomb', 'Perish Song', 'Protect']),
			S('Politoed', 'Damp Rock', 'Drizzle', 'Calm', '32 HP / 16 Def / 18 SpD', ['Perish Song', 'Weather Ball', 'Helping Hand', 'Protect']),
			S('Kommo-o', 'Leftovers', 'Soundproof', 'Modest', '2 HP / 32 SpA / 32 Spe', ['Clanging Scales', 'Aura Sphere', 'Flamethrower', 'Protect']),
			S('Ninetales-Alola', 'Choice Scarf', 'Snow Warning', 'Modest', '2 HP / 32 SpA / 32 Spe', ['Blizzard', 'Moonblast', 'Freeze-Dry', 'Hypnosis']),
			S('Kingambit', 'Life Orb', 'Defiant', 'Adamant', '32 HP / 32 Atk / 2 Spe', ['Kowtow Cleave', 'Sucker Punch', 'Swords Dance', 'Protect']),
			incin()),
	},
	{
		id: 'C10-antigo', nome: 'C10 Metagross-Mega + Psychic Terrain', fonte: 'Lista completa do Dylan Matthews (Baltimore top 16, SP publicados no 03-META)',
		previa: ['Indeedee-F', 'Gholdengo', 'Gallade', 'Garchomp'], mega: ['Garchomp'],
		previaOpp: ['Indeedee-F','Metagross','Milotic','Dragapult'], megaOpp: ['Metagross'],
		text: team(
			S('Dragapult', 'Life Orb', 'Infiltrator', 'Timid', '1 Def / 32 SpA / 1 SpD / 32 Spe', ['Draco Meteor', 'Shadow Ball', 'Will-O-Wisp', 'Protect']),
			S('Arcanine-Hisui', 'Focus Sash', 'Rock Head', 'Jolly', '32 Atk / 1 Def / 1 SpD / 32 Spe', ['Rock Slide', 'Flare Blitz', 'Head Smash', 'Protect']),
			S('Altaria', 'Haban Berry', 'Cloud Nine', 'Timid', '32 HP / 1 Def / 1 SpD / 32 Spe', ['Ice Beam', 'Tailwind', 'Will-O-Wisp', 'Protect']),
			S('Metagross', 'Metagrossite', 'Clear Body', 'Jolly', '2 HP / 32 Atk / 32 Spe', ['Psychic Fangs', 'Body Press', 'Psych Up', 'Protect']),
			S('Indeedee-F', 'Rocky Helmet', 'Psychic Surge', 'Bold', '32 HP / 32 Def / 1 SpD / 1 Spe', ['Psychic', 'Follow Me', 'Helping Hand', 'Protect']),
			S('Milotic', 'Psychic Seed', 'Competitive', 'Calm', '32 HP / 21 Def / 1 SpA / 6 SpD / 6 Spe', ['Muddy Water', 'Coil', 'Hypnosis', 'Recover'])),
	},
];

// Variantes dos cores atuais
const CORES_VARIANTES = [
	{id: 'C10-RaichuX', nome: 'C10 com Raichu-Mega-X no lugar da Floette', fonte: 'euphitc (Louisville 37º)', previa: ['Garchomp', 'Volcarona', 'Charizard', 'Gallade'], mega: ['Charizard'], previaOpp: undefined, megaOpp: undefined, text: lista('N1')},
];

module.exports = {CORES, CORES_ANTIGOS, CORES_VARIANTES};
