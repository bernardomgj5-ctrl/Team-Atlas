#!/usr/bin/env python3
"""Baixa logs brutos de replays do Showdown.

Uso:
  python3 baixar.py ids <arquivo>        # linhas "time|id" (id com ou sem prefixo de formato)
  python3 baixar.py usuario <nome>       # todos os replays públicos do usuário (Champions)
  python3 baixar.py publicos <formato> <rating_min> <max_paginas>
Saída: raw/<id>.json e fontes.jsonl (id, fonte, rótulo).
"""
import json, os, sys, time, urllib.request, urllib.error

BASE = 'https://replay.pokemonshowdown.com'
DIR = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(DIR, 'raw')
os.makedirs(RAW, exist_ok=True)
PREFIXOS = ['gen9championsvgc2026regmcbo3', 'gen9championsvgc2026regmbbo3',
            'gen9championsvgc2026regmc', 'gen9championsvgc2026regmb']


def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'pkm-analise/1.0'})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode('utf-8'))


def registrar(rid, fonte, rotulo):
    with open(os.path.join(DIR, 'fontes.jsonl'), 'a') as f:
        f.write(json.dumps({'id': rid, 'fonte': fonte, 'rotulo': rotulo}) + '\n')


def baixar(rid):
    """Baixa um replay pelo id completo. Devolve o id salvo ou None."""
    base_id = rid.split('-')[0] + '-' + rid.split('-')[1]  # sem senha, para o nome do arquivo
    destino = os.path.join(RAW, base_id + '.json')
    if os.path.exists(destino):
        return base_id
    try:
        d = get(f'{BASE}/{rid}.json')
    except urllib.error.HTTPError as e:
        return None
    with open(destino, 'w') as f:
        json.dump(d, f)
    time.sleep(0.25)
    return base_id


def por_ids(arquivo):
    ok, falhas = 0, []
    for linha in open(arquivo):
        linha = linha.strip()
        if not linha or linha.startswith('#'):
            continue
        rotulo, rid = linha.split('|', 1)
        candidatos = [rid] if rid.startswith('gen9') else [f'{p}-{rid}' for p in PREFIXOS]
        salvo = None
        for c in candidatos:
            salvo = baixar(c)
            if salvo:
                break
        if salvo:
            ok += 1
            registrar(salvo, 'registro', rotulo)
        else:
            falhas.append(linha)
    print(f'registro: {ok} baixados, {len(falhas)} falharam')
    for f in falhas:
        print('  falhou:', f)


def busca(params, fonte, rotulo, rating_min=0, max_paginas=50, limite=500):
    antes, total, vistos = None, 0, 0
    for _ in range(max_paginas):
        if total >= limite:
            break
        q = '&'.join(f'{k}={urllib.parse.quote(str(v))}' for k, v in params.items())
        if antes:
            q += f'&before={antes}'
        try:
            res = get(f'{BASE}/search.json?{q}')
        except urllib.error.HTTPError as e:
            print('erro na busca:', e)
            break
        if not res:
            break
        for r in res[:50]:
            vistos += 1
            if (r.get('rating') or 0) < rating_min:
                continue
            if r.get('password') or r.get('private'):
                continue
            salvo = baixar(r['id'])
            if salvo:
                total += 1
                registrar(salvo, fonte, rotulo)
        # a API devolve 51 itens quando há próxima página; a próxima começa antes do 50º
        if len(res) <= 50:
            break
        antes = res[49]['uploadtime']
        if vistos % 1000 < 50:
            print(f'  ... {vistos} vistos, {total} baixados', flush=True)
        time.sleep(0.4)
    print(f'{fonte}: {vistos} vistos, {total} baixados (rating >= {rating_min})')


if __name__ == '__main__':
    import urllib.parse
    modo = sys.argv[1]
    if modo == 'ids':
        por_ids(sys.argv[2])
    elif modo == 'usuario':
        for fmt in ['gen9championsvgc2026regmcbo3', 'gen9championsvgc2026regmc']:
            busca({'user': sys.argv[2], 'format': fmt}, 'usuario', sys.argv[2])
    elif modo == 'publicos':
        busca({'format': sys.argv[2]}, 'publico', sys.argv[2], int(sys.argv[3]), int(sys.argv[4]))
