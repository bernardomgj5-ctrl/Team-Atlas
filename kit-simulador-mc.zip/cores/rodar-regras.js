// Testa as regras aprendidas dos vídeos: T1G contra os 11 cores, prévia/lead fixos (modo atlas),
// adversário com o modelo dos replays. Mesmas sementes em todas as configurações.
// Uso: node cores/rodar-regras.js N "regrasNossas" "regrasDeles" [saida.json]
//   ex.: node cores/rodar-regras.js 100 "troca,protect" ""
'use strict';
const fs = require('fs');
const path = require('path');
const {simular} = require('../simular.js');
const {CORES} = require('./cores.js');
const N = parseInt(process.argv[2] || '50', 10);
const lista = s => (s || '').split(',').map(x => x.trim()).filter(Boolean);
const regrasA = lista(process.argv[3]), regrasB = lista(process.argv[4]); // vazio = nenhuma regra
const MODELO = path.join(__dirname, 'modelo_adversario.json');
const t1g = fs.readFileSync(path.join(__dirname, 'T1G.txt'), 'utf8');
(async () => {
	const res = {};
	let v = 0, n = 0, fb = 0;
	for (const core of CORES) {
		const r = await simular(t1g, core.text, {n: N, nomes: ['T1G', core.id], megaA: core.mega, previaA: core.previa,
			previaB: core.previaOpp, megaB: core.megaOpp, modeloB: MODELO, semente: 7, regrasA, regrasB});
		const s = r.stats;
		res[core.id] = {v: s.vitorias[0], n: s.batalhas, turnos: s.turnos.reduce((a, b) => a + b, 0) / Math.max(1, s.batalhas), fallbacks: s.fallbacks};
		v += s.vitorias[0]; n += s.batalhas; fb += s.fallbacks;
	}
	res.total = {v, n, wr: +(100 * v / n).toFixed(1), fallbacks: fb};
	if (process.argv[5]) fs.writeFileSync(process.argv[5], JSON.stringify(res, null, 1));
	console.log(`[${regrasA.join(',') || '-'}] x [${regrasB.join(',') || '-'}]  ${res.total.wr}%  (${v}/${n})  fallbacks ${fb}  |  ` +
		CORES.map(c => `${c.id} ${Math.round(100 * res[c.id].v / res[c.id].n)}`).join(' '));
})().catch(e => { console.error('ERRO:', e.stack); process.exit(1); });
