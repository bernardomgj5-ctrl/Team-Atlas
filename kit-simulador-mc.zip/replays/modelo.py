#!/usr/bin/env python3
"""Modelo de frequências das decisões adversárias.

  python3 modelo.py preparar   -> decisoes_eval.jsonl (só adversários, com fold por jogador)
  python3 modelo.py avaliar    -> compara frequências, heurística (heur.jsonl) e mistura
  python3 modelo.py exportar   -> modelo_adversario.json (para o simular.js)
"""
import hashlib, json, math, os, sys
from collections import Counter, defaultdict

DIR = os.path.dirname(os.path.abspath(__file__))
PROTECT = {'Protect', 'Detect', 'Spiky Shield', "King's Shield", 'Baneful Bunker', 'Silk Trap', 'Burning Bulwark'}
TROCA = '(troca)'
ALFA = 60.0  # força do recuo para o nível mais geral (validação cruzada)
EPS = 0.3    # mistura com o uniforme (validação cruzada)


def fold(jogador):
    return int(hashlib.md5(jogador.lower().encode()).hexdigest(), 16) % 5


def hp_b(hp):
    return 'alto' if hp > 66 else ('medio' if hp > 33 else 'baixo')


def fase(d):
    return 'T1' if d['turno'] == 1 else ('entrada' if d['primeiro_turno'] else 'meio')


def niveis(d):
    """Chaves de contexto do mais específico ao mais geral (sem a espécie, que entra antes)."""
    f = fase(d)
    pa = 'P' if d.get('protegeu_antes') else '-'
    return [
        (f, hp_b(d['hp']), pa, 'TR' if d['tr'] else '-', 'TW' if d['tw_proprio'] else '-', 'tw' if d['tw_oponente'] else '-'),
        (f, hp_b(d['hp']), pa),
        (f, pa),
        (f,),
        (),
    ]


def preparar():
    D = [json.loads(l) for l in open(os.path.join(DIR, 'decisoes.jsonl'))]
    # Protect no turno anterior pela mesma peça no mesmo slot
    ultimo = {}
    D.sort(key=lambda d: (d['id'], d['turno']))
    for d in D:
        k = (d['id'], d['lado'], d['slot'], d['especie'])
        prev = ultimo.get(k)
        d['protegeu_antes'] = bool(prev and prev[0] == d['turno'] - 1 and prev[1] in PROTECT and not d['primeiro_turno'])
        ultimo[k] = (d['turno'], d['golpe'])
    out = []
    for i, d in enumerate(x for x in D if x['grupo'] != 'nosso'):
        d['idx'] = i
        d['fold'] = fold(d['jogador'])
        d['candidatos'] = list(dict.fromkeys(d['moveset'] + [TROCA]))
        if d['golpe'] not in d['candidatos']:
            continue
        out.append(d)
    with open(os.path.join(DIR, 'decisoes_eval.jsonl'), 'w') as f:
        for d in out:
            f.write(json.dumps(d, ensure_ascii=False) + '\n')
    print(f'{len(out)} decisões de adversários; folds {Counter(d["fold"] for d in out)}')


class Frequencias:
    """Contagens por (espécie, contexto) com recuo hierárquico; peso por jogador opcional."""

    def __init__(self, decisoes, peso_jogador=False):
        self.c = defaultdict(Counter)   # (esp, ctx) -> golpe -> peso
        self.g = defaultdict(Counter)   # ctx sem espécie -> categoria do golpe
        n_jog = Counter(d['jogador'] for d in decisoes)
        for d in decisoes:
            w = 1.0 / math.sqrt(n_jog[d['jogador']]) if peso_jogador else 1.0
            for ctx in niveis(d):
                self.c[(d['especie'], ctx)][d['golpe']] += w
            # prior global por "classe" de golpe (Protect / troca / outros) no contexto
            classe = 'protect' if d['golpe'] in PROTECT else ('troca' if d['golpe'] == TROCA else 'outro')
            for ctx in niveis(d):
                self.g[ctx][classe] += w

    def prever(self, d):
        cands = d['candidatos']
        # prior global: classe do golpe no contexto mais geral com dado, repartida entre os golpes da classe
        def prior():
            for ctx in niveis(d):
                g = self.g.get(ctx)
                if g and sum(g.values()) > 20:
                    break
            tot = sum(g.values()) or 1
            cl = {'protect': [m for m in cands if m in PROTECT], 'troca': [TROCA],
                  'outro': [m for m in cands if m not in PROTECT and m != TROCA]}
            p = {}
            for k, ms in cl.items():
                if not ms:
                    continue
                for m in ms:
                    p[m] = (g.get(k, 0) + 1) / (tot + 3) / len(ms)
            s = sum(p.values())
            return {m: p.get(m, 0) / s for m in cands}
        p = prior()
        for ctx in reversed(niveis(d)):
            cnt = self.c.get((d['especie'], ctx))
            if not cnt:
                continue
            n = sum(cnt[m] for m in cands)
            p = {m: (cnt.get(m, 0) + ALFA * p[m]) / (n + ALFA) for m in cands}
        s = sum(p.values())
        return {m: (1 - EPS) * v / s + EPS / len(cands) for m, v in p.items()}


def softmax(vals, T):
    mx = max(vals.values())
    ex = {k: math.exp((v - mx) / T) for k, v in vals.items()}
    s = sum(ex.values())
    return {k: v / s for k, v in ex.items()}


def metricas(D, P):
    n = len(D)
    top1 = top2 = ll = 0.0
    for d in D:
        p = P[d['idx']]
        orden = sorted(p, key=p.get, reverse=True)
        top1 += orden[0] == d['golpe']
        top2 += d['golpe'] in orden[:2]
        ll += -math.log(max(p.get(d['golpe'], 0), 1e-6))
    return {'n': n, 'acerto': round(100 * top1 / n, 1), 'top2': round(100 * top2 / n, 1), 'logloss': round(ll / n, 3)}


def avaliar():
    D = [json.loads(l) for l in open(os.path.join(DIR, 'decisoes_eval.jsonl'))]
    H = {}
    hp = os.path.join(DIR, 'heur.jsonl')
    if os.path.exists(hp):
        for l in open(hp):
            r = json.loads(l)
            H[r['idx']] = r['valores']
    # previsões fora da amostra: treina sem o fold do jogador
    Pf, Pfw = {}, {}
    for k in range(5):
        treino = [d for d in D if d['fold'] != k]
        m, mw = Frequencias(treino), Frequencias(treino, peso_jogador=True)
        for d in D:
            if d['fold'] == k:
                Pf[d['idx']] = m.prever(d)
                Pfw[d['idx']] = mw.prever(d)
    uniforme = {d['idx']: {m: 1 / len(d['candidatos']) for m in d['candidatos']} for d in D}
    com_h = [d for d in D if d['idx'] in H]
    res = {'uniforme': metricas(D, uniforme), 'frequencias': metricas(D, Pf), 'frequencias_peso_jogador': metricas(D, Pfw)}
    if com_h:
        # temperatura e mistura escolhidas nos folds 1–4, relatadas no fold 0
        ajuste = [d for d in com_h if d['fold'] != 0]
        teste = [d for d in com_h if d['fold'] == 0]

        def ph(d, T):
            v = {m: H[d['idx']].get(m, 0.0) for m in d['candidatos']}
            return softmax(v, T)
        melhor = None
        for T in (0.05, 0.1, 0.2, 0.3, 0.5, 1.0):
            for lam in (0.0, 0.2, 0.4, 0.6, 0.8, 1.0):
                P = {d['idx']: {m: lam * Pf[d['idx']][m] + (1 - lam) * ph(d, T)[m] for m in d['candidatos']} for d in ajuste}
                ll = metricas(ajuste, P)['logloss']
                if not melhor or ll < melhor[0]:
                    melhor = (ll, T, lam)
        _, T, lam = melhor
        Pheur = {d['idx']: ph(d, T) for d in teste}
        Pmix = {d['idx']: {m: lam * Pf[d['idx']][m] + (1 - lam) * Pheur[d['idx']][m] for m in d['candidatos']} for d in teste}
        Pfreq_t = {d['idx']: Pf[d['idx']] for d in teste}
        res['teste_fold0'] = {
            'ajuste': {'temperatura': T, 'peso_frequencias': lam},
            'heuristica': metricas(teste, Pheur), 'frequencias': metricas(teste, Pfreq_t), 'mistura': metricas(teste, Pmix),
        }
        # recortes no fold 0
        recortes = {
            'T1': lambda d: d['turno'] == 1,
            'protect': lambda d: d['golpe'] in PROTECT,
            'troca': lambda d: d['golpe'] == TROCA,
            'meio de jogo': lambda d: d['turno'] > 1 and not d['primeiro_turno'],
        }
        res['recortes_fold0'] = {}
        for nome, f in recortes.items():
            sub = [d for d in teste if f(d)]
            if sub:
                res['recortes_fold0'][nome] = {'heuristica': metricas(sub, Pheur), 'frequencias': metricas(sub, Pfreq_t),
                                               'mistura': metricas(sub, Pmix)}
    json.dump(res, open(os.path.join(DIR, 'avaliacao.json'), 'w'), ensure_ascii=False, indent=1)
    print(json.dumps(res, ensure_ascii=False, indent=1))


def exportar():
    """Tabela de contagens para o simulador: espécie -> contexto -> golpe -> peso; mais prior por classe e Megas."""
    D = [json.loads(l) for l in open(os.path.join(DIR, 'decisoes_eval.jsonl'))]
    m = Frequencias(D)
    cont = {}
    for (esp, ctx), cnt in m.c.items():
        cont.setdefault(esp, {})['|'.join(ctx)] = dict(cnt)
    glob_ = {'|'.join(ctx): dict(c) for ctx, c in m.g.items()}
    # Mega: P(evoluir) na primeira oportunidade e nas seguintes, por espécie
    M = [json.loads(l) for l in open(os.path.join(DIR, 'megas.jsonl')) if json.loads(l)['grupo'] != 'nosso']
    mega = defaultdict(lambda: Counter())
    for x in M:
        k = 'T1' if x['turno'] == 1 else 'depois'
        mega[x['especie']][k + '_n'] += 1
        mega[x['especie']][k + '_sim'] += x['fez']
    av = json.load(open(os.path.join(DIR, 'avaliacao.json')))
    aj = av.get('teste_fold0', {}).get('ajuste', {'temperatura': 0.2, 'peso_frequencias': 1.0})
    out = {'alfa': ALFA, 'eps': EPS, 'contagens': cont, 'prior': glob_, 'mega': {k: dict(v) for k, v in mega.items()},
           'temperatura': aj['temperatura'], 'peso_frequencias': aj['peso_frequencias'],
           'fonte': 'replays Reg M-C (públicos rating >= 1300 e adversários nossos), sem contas bot'}
    json.dump(out, open(os.path.join(DIR, 'modelo_adversario.json'), 'w'), ensure_ascii=False)
    print('espécies no modelo:', len(cont), '| Megas:', {k: dict(v) for k, v in list(mega.items())[:5]})


if __name__ == '__main__':
    {'preparar': preparar, 'avaliar': avaliar, 'exportar': exportar}[sys.argv[1]]()
