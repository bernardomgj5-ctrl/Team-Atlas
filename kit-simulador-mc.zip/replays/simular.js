#!/usr/bin/env node
/*
 * simular.js — simulador de batalhas em massa para Pokémon Champions (VGC)
 * usando o motor oficial do Pokémon Showdown (smogon/pokemon-showdown).
 *
 * ---------------------------------------------------------------------------
 * COMO REINSTALAR O SHOWDOWN E RODAR NUMA CONVERSA NOVA
 * ---------------------------------------------------------------------------
 * O ambiente de cada conversa é zerado, então a instalação precisa ser refeita.
 * Requisito: Node >= 22.18 (confira com `node --version`).
 *
 *   cd ~
 *   git clone --depth 1 https://github.com/smogon/pokemon-showdown.git
 *   cd pokemon-showdown && npm install && node build && cd ..
 *
 * Deixe este arquivo na mesma pasta que contém a pasta `pokemon-showdown`
 * (ou aponte para ela com --ps <pasta> ou com a variável PS_DIR).
 *
 * Confira se o formato ainda existe (o ID pode mudar quando sair nova regulação):
 *   node -e "const {Dex}=require('./pokemon-showdown/dist/sim');
 *            console.log(Dex.formats.get('gen9championsvgc2026regmc').exists)"
 * Para listar os formatos Champions:  grep -n "Champions" pokemon-showdown/config/formats.ts
 *
 * USO
 *   node simular.js timeA.txt timeB.txt [opções]
 *
 *   timeA.txt / timeB.txt  times em texto de exportação do Showdown. Em Champions,
 *                          os Stat Points vão na linha "EVs:" (máx. 32 por stat,
 *                          66 no total), ex.: "EVs: 32 HP / 32 Atk / 2 Spe".
 *   -n, --batalhas N       número de batalhas (padrão 100)
 *   -f, --formato ID       formato (padrão gen9championsvgc2026regmc)
 *   --nomes A,B            nomes dos times no relatório (padrão: nomes dos arquivos)
 *   --log                  grava um resumo turno a turno de cada batalha em
 *                          logs/batalha-N.txt e imprime o da primeira
 *   --json                 imprime o resultado final em JSON
 *   --ps PASTA             pasta do pokemon-showdown já com build
 *   --previa-a A,B,C,D     prévia fixa do time A (os dois primeiros lideram);
 *                          aceita a espécie base ("Garchomp" para o Garchomp-Mega-Z)
 *   --mega-a X,Y           ordem de preferência de Mega do time A: só evolui o
 *                          primeiro da lista que ainda pode evoluir
 *   --previa-b / --mega-b  o mesmo para o time B
 *   --modelo-b ARQ         o time B joga com a política aprendida dos replays
 *                          (modelo_adversario.json): mistura as frequências observadas
 *                          por espécie e contexto com a heurística e sorteia a ação,
 *                          incluindo trocas voluntárias e o momento da Mega.
 *                          --modelo-a faz o mesmo para o time A.
 *   --semente N            semente dos sorteios do modelo (padrão 1), para repetir
 *                          uma rodada exatamente
 *
 * Uso como módulo (vários confrontos num script):
 *   const {simular, report} = require('./simular.js');
 *   const r = await simular(textoA, textoB, {n: 50, nomes: ['A','B'], previaA: [...], megaA: [...]});
 *   console.log(report(r));
 *
 * O QUE O BOT FAZ (heurística determinística, sem aleatoriedade)
 *   - Prévia: pontua cada Pokémon contra os 6 do oponente (dano que causa menos
 *     dano que recebe, mais bônus de função: Fake Out, Tailwind, Trick Room,
 *     Intimidate, Mega). Leva os 4 melhores e lidera com os 2 de maior pressão.
 *     Mesmo confronto = mesma escolha sempre.
 *   - Turno: estima o dano esperado de cada golpe em cada alvo (fórmula de dano
 *     do jogo com STAB, tipo, clima, terreno, itens e habilidades mais comuns,
 *     spread 0,75x, rolagem média), valoriza KO, evita acertar o aliado, usa
 *     Fake Out só no primeiro turno em campo, usa Protect quando o dano recebido
 *     estimado derruba o Pokémon e não repete Protect, monta Tailwind/Trick Room
 *     quando faz sentido e evita dois ataques no mesmo alvo quando o primeiro já
 *     deve derrubar. Mega evolui na primeira oportunidade.
 *   - Trocas: só as forçadas (KO, U-turn, Parting Shot); escolhe o reserva com
 *     melhor confronto contra os ativos do oponente.
 *
 * LIMITAÇÕES (leia antes de interpretar os números)
 *   - O bot lê o estado real da batalha, inclusive SP e nature do oponente, que
 *     um jogador não veria nem com Open Team Sheets.
 *   - Não faz trocas voluntárias, não prevê Protect do oponente, não joga em
 *     torno de Wide Guard/Follow Me e não planeja mais de um turno à frente.
 *   - A taxa de vitória mede o confronto entre dois pilotos iguais e simples,
 *     não o confronto entre jogadores humanos. Serve para comparar variações
 *     (spread, golpe, item) com o resto fixo, não como previsão de resultado real.
 */
'use strict';

const fs = require('fs');
const path = require('path');

// ---------------------------------------------------------------------------
// Argumentos
// ---------------------------------------------------------------------------
function parseArgs(argv) {
	const opts = {files: [], n: 100, formato: 'gen9championsvgc2026regmc', log: false, json: false, ps: null, nomes: null};
	for (let i = 0; i < argv.length; i++) {
		const a = argv[i];
		if (a === '-n' || a === '--batalhas') opts.n = parseInt(argv[++i], 10);
		else if (a === '-f' || a === '--formato') opts.formato = argv[++i];
		else if (a === '--nomes') opts.nomes = argv[++i].split(',');
		else if (a === '--log') opts.log = true;
		else if (a === '--json') opts.json = true;
		else if (a === '--ps') opts.ps = argv[++i];
		else if (a === '--previa-a') opts.previaA = argv[++i].split(',').map(s => s.trim());
		else if (a === '--previa-b') opts.previaB = argv[++i].split(',').map(s => s.trim());
		else if (a === '--mega-a') opts.megaA = argv[++i].split(',').map(s => s.trim());
		else if (a === '--mega-b') opts.megaB = argv[++i].split(',').map(s => s.trim());
		else if (a === '--modelo-a') opts.modeloA = argv[++i];
		else if (a === '--modelo-b') opts.modeloB = argv[++i];
		else if (a === '--semente') opts.semente = parseInt(argv[++i], 10);
		else if (a === '-h' || a === '--help') opts.help = true;
		else opts.files.push(a);
	}
	return opts;
}

function loadShowdown(psDir) {
	const dir = psDir || process.env.PS_DIR || path.join(__dirname, 'pokemon-showdown');
	const simPath = path.join(dir, 'dist', 'sim');
	if (!fs.existsSync(simPath)) {
		throw new Error(`Não encontrei o build do Showdown em ${simPath}. Instale e rode "node build" (veja o comentário no topo).`);
	}
	const sim = require(simPath);
	const {BattlePlayer} = require(path.join(simPath, 'battle-stream'));
	return {...sim, BattlePlayer};
}

// ---------------------------------------------------------------------------
// Tabelas usadas na estimativa de dano
// ---------------------------------------------------------------------------
const TYPE_ITEMS = {
	miracleseed: 'Grass', charcoal: 'Fire', mysticwater: 'Water', fairyfeather: 'Fairy', magnet: 'Electric',
	nevermeltice: 'Ice', blackbelt: 'Fighting', poisonbarb: 'Poison', softsand: 'Ground', sharpbeak: 'Flying',
	twistedspoon: 'Psychic', silverpowder: 'Bug', hardstone: 'Rock', spelltag: 'Ghost', dragonfang: 'Dragon',
	blackglasses: 'Dark', metalcoat: 'Steel', silkscarf: 'Normal',
};
const RESIST_BERRIES = {
	occaberry: 'Fire', passhoberry: 'Water', wacanberry: 'Electric', rindoberry: 'Grass', yacheberry: 'Ice',
	chopleberry: 'Fighting', kebiaberry: 'Poison', shucaberry: 'Ground', cobaberry: 'Flying', payapaberry: 'Psychic',
	tangaberry: 'Bug', chartiberry: 'Rock', kasibberry: 'Ghost', habanberry: 'Dragon', colburberry: 'Dark',
	babiriberry: 'Steel', roseliberry: 'Fairy',
};
const ABILITY_IMMUNE = {
	levitate: 'Ground', eartheater: 'Ground', flashfire: 'Fire', wellbakedbody: 'Fire', waterabsorb: 'Water',
	stormdrain: 'Water', dryskin: 'Water', voltabsorb: 'Electric', lightningrod: 'Electric', motordrive: 'Electric',
	sapsipper: 'Grass',
};
const REDIRECT = {lightningrod: 'Electric', stormdrain: 'Water'};
const ATE = {pixilate: 'Fairy', aerilate: 'Flying', refrigerate: 'Ice', galvanize: 'Electric', dragonize: 'Dragon'};
const PROTECT_MOVES = new Set(['protect', 'detect', 'spikyshield', 'kingsshield', 'banefulbunker', 'silktrap', 'burningbulwark', 'obstruct', 'maxguard']);
const STATUS_TYPE_IMMUNE = {par: ['Electric'], brn: ['Fire'], psn: ['Poison', 'Steel'], tox: ['Poison', 'Steel'], frz: ['Ice']};

function toID(s) {
	return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '');
}
// Índice do Pokémon do time pelo nome da espécie (aceita a forma base: "Garchomp" acha o portador do Garchompite Z)
function findMon(list, name) {
	const id = toID(name);
	const i = list.findIndex(p => {
		const sp = p.species || p;
		return [sp.name, sp.baseSpecies, p.name].some(n => n && toID(n) === id);
	});
	if (i < 0) throw new Error(`"${name}" não está no time`);
	return i;
}

// Gerador pseudoaleatório com semente (mulberry32), para a política do modelo ser reproduzível
function rngSemente(seed) {
	let a = seed >>> 0;
	return function () {
		a |= 0; a = (a + 0x6D2B79F5) | 0;
		let t = Math.imul(a ^ (a >>> 15), 1 | a);
		t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
		return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
	};
}
function sortear(probs, rng) {
	const r = rng();
	let acc = 0;
	const ks = Object.keys(probs);
	for (const k of ks) { acc += probs[k]; if (r < acc) return k; }
	return ks[ks.length - 1];
}

function boostMult(stage) {
	return stage >= 0 ? (2 + stage) / 2 : 2 / (2 - stage);
}
function alive(p) {
	return !!(p && !p.fainted && p.hp > 0);
}
function isGrounded(p) {
	if (!p) return true;
	if (p.hasType && p.hasType('Flying')) return false;
	if (p.ability === 'levitate' || p.item === 'airballoon') return false;
	return true;
}

// ---------------------------------------------------------------------------
// Estimativa de dano (determinística)
// ---------------------------------------------------------------------------
function estimateDamage(battle, attacker, defender, move, opts = {}) {
	const dex = battle.dex;
	if (!move || move.category === 'Status') return {avg: 0, min: 0, eff: 1};
	const attTypes = attacker.getTypes ? attacker.getTypes() : attacker.species.types;
	const defTypes = defender.getTypes ? defender.getTypes() : defender.species.types;
	const atkAbility = attacker.ability;
	const defAbility = defender.ability;
	const isAlly = attacker.side === defender.side;

	// Dano fixo
	if (move.damage === 'level') return {avg: attacker.level, min: attacker.level, eff: 1};
	if (typeof move.damage === 'number') return {avg: move.damage, min: move.damage, eff: 1};
	if (['superfang', 'ruination', 'naturesmadness'].includes(move.id)) {
		if (move.id === 'superfang' && defTypes.includes('Ghost')) return {avg: 0, min: 0, eff: 0};
		const d = Math.floor(defender.hp / 2);
		return {avg: d, min: d, eff: 1};
	}

	let type = move.type;
	let bp = move.basePower;
	if (type === 'Normal' && ATE[atkAbility]) {
		type = ATE[atkAbility];
		bp *= 1.2;
	}
	if (move.id === 'weatherball') {
		const w = battle.field.weather;
		if (w === 'sunnyday') type = 'Fire';
		if (w === 'raindance') type = 'Water';
		if (w === 'sandstorm') type = 'Rock';
		if (w === 'snowscape') type = 'Ice';
		if (w) bp = 100;
	}
	if (!bp) {
		if (['lowkick', 'grassknot'].includes(move.id)) {
			const w = defender.species.weighthg ? defender.species.weighthg / 10 : defender.species.weightkg;
			bp = w < 10 ? 20 : w < 25 ? 40 : w < 50 ? 60 : w < 100 ? 80 : w < 200 ? 100 : 120;
		} else {
			bp = 60;
		}
	}

	// Imunidades
	if (!dex.getImmunity(type, defTypes)) {
		const ringTarget = defender.item === 'ringtarget';
		if (!ringTarget) return {avg: 0, min: 0, eff: 0};
	}
	if (type === 'Ground' && !isGrounded(defender) && move.id !== 'thousandarrows') return {avg: 0, min: 0, eff: 0};
	if (ABILITY_IMMUNE[defAbility] === type && !isAlly) return {avg: 0, min: 0, eff: 0};
	if (defAbility === 'bulletproof' && move.flags.bullet) return {avg: 0, min: 0, eff: 0};
	if (defAbility === 'soundproof' && move.flags.sound) return {avg: 0, min: 0, eff: 0};
	if (defAbility === 'windrider' && move.flags.wind) return {avg: 0, min: 0, eff: 0};
	if (defAbility === 'telepathy' && isAlly) return {avg: 0, min: 0, eff: 0};
	if (battle.field.terrain === 'psychicterrain' && move.priority > 0 && isGrounded(defender) && !isAlly) {
		return {avg: 0, min: 0, eff: 0};
	}

	let eff = 2 ** dex.getEffectiveness(type, defTypes);
	if (move.id === 'freezedry' && defTypes.includes('Water')) eff *= 4;

	// Stats
	const offPoke = move.overrideOffensivePokemon === 'target' ? defender : attacker;
	let offStat = move.overrideOffensiveStat || (move.category === 'Physical' ? 'atk' : 'spa');
	let defStat = move.overrideDefensiveStat || (move.category === 'Physical' ? 'def' : 'spd');
	let A = offPoke.storedStats[offStat] * boostMult(offPoke.boosts[offStat] || 0);
	let D = defender.storedStats[defStat] * boostMult(defender.boosts[defStat] || 0);

	if (offStat === 'atk' && ['hugepower', 'purepower'].includes(atkAbility)) A *= 2;
	if (offStat === 'atk' && attacker.item === 'choiceband') A *= 1.5;
	if (offStat === 'spa' && attacker.item === 'choicespecs') A *= 1.5;
	if (offStat === 'atk' && atkAbility === 'guts' && attacker.status) A *= 1.5;
	if (offStat === 'atk' && atkAbility === 'hustle') A *= 1.5;
	if (offStat === 'spa' && atkAbility === 'solarpower' && battle.field.weather === 'sunnyday') A *= 1.5;
	if (defStat === 'spd' && defender.item === 'assaultvest') D *= 1.5;
	if (defender.item === 'eviolite' && defender.species.nfe) D *= 1.5;
	if (defStat === 'def' && defAbility === 'furcoat') D *= 2;
	if (defStat === 'spd' && battle.field.weather === 'sandstorm' && defTypes.includes('Rock')) D *= 1.5;
	if (defStat === 'def' && battle.field.weather === 'snowscape' && defTypes.includes('Ice')) D *= 1.5;

	// Poder base
	if (atkAbility === 'technician' && bp <= 60) bp *= 1.5;
	if (atkAbility === 'toughclaws' && move.flags.contact) bp *= 1.3;
	if (atkAbility === 'sheerforce' && move.secondaries) bp *= 1.3;
	if (atkAbility === 'ironfist' && move.flags.punch) bp *= 1.2;
	if (atkAbility === 'strongjaw' && move.flags.bite) bp *= 1.5;
	if (atkAbility === 'megalauncher' && move.flags.pulse) bp *= 1.5;
	if (atkAbility === 'sharpness' && move.flags.slicing) bp *= 1.5;
	if (atkAbility === 'reckless' && (move.recoil || move.hasCrashDamage)) bp *= 1.2;
	if (atkAbility === 'sandforce' && battle.field.weather === 'sandstorm' && ['Rock', 'Ground', 'Steel'].includes(type)) bp *= 1.3;
	if (TYPE_ITEMS[attacker.item] === type) bp *= 1.2;
	if (move.multihit) {
		const hits = Array.isArray(move.multihit) ? (atkAbility === 'skilllink' ? move.multihit[1] : 3) : move.multihit;
		bp *= hits;
	}
	if (opts.helpingHand) bp *= 1.5;

	// Fórmula base (nível 50 no VGC)
	const L = attacker.level;
	let base = Math.floor(Math.floor(Math.floor(2 * L / 5 + 2) * bp * A / D) / 50) + 2;
	let mod = 1;

	if (opts.spread) mod *= 0.75;
	const w = battle.field.weather;
	if (w === 'sunnyday' || w === 'desolateland') { if (type === 'Fire') mod *= 1.5; if (type === 'Water') mod *= 0.5; }
	if (w === 'raindance' || w === 'primordialsea') { if (type === 'Water') mod *= 1.5; if (type === 'Fire') mod *= 0.5; }
	const t = battle.field.terrain;
	if (isGrounded(attacker)) {
		if (t === 'grassyterrain' && type === 'Grass') mod *= 1.3;
		if (t === 'electricterrain' && type === 'Electric') mod *= 1.3;
		if (t === 'psychicterrain' && type === 'Psychic') mod *= 1.3;
	}
	if (isGrounded(defender)) {
		if (t === 'mistyterrain' && type === 'Dragon') mod *= 0.5;
		if (t === 'grassyterrain' && ['earthquake', 'bulldoze'].includes(move.id)) mod *= 0.5;
	}

	if (attTypes.includes(type)) mod *= atkAbility === 'adaptability' ? 2 : 1.5;
	mod *= eff;
	if (move.category === 'Physical' && attacker.status === 'brn' && atkAbility !== 'guts') mod *= 0.5;

	// Telas e modificadores finais
	const sc = defender.side.sideConditions;
	if (!isAlly && (sc.auroraveil || (move.category === 'Physical' && sc.reflect) || (move.category === 'Special' && sc.lightscreen))) {
		mod *= 2732 / 4096;
	}
	if (attacker.item === 'lifeorb') mod *= 1.3;
	if (attacker.item === 'expertbelt' && eff > 1) mod *= 1.2;
	if (['filter', 'solidrock', 'prismarmor'].includes(defAbility) && eff > 1) mod *= 0.75;
	if (defAbility === 'multiscale' && defender.hp === defender.maxhp) mod *= 0.5;
	if (defAbility === 'shadowshield' && defender.hp === defender.maxhp) mod *= 0.5;
	if (defAbility === 'icescales' && move.category === 'Special') mod *= 0.5;
	if (defAbility === 'fluffy' && move.flags.contact) mod *= 0.5;
	if (defAbility === 'thickfat' && ['Fire', 'Ice'].includes(type)) mod *= 0.5;
	if (defAbility === 'heatproof' && type === 'Fire') mod *= 0.5;
	if (RESIST_BERRIES[defender.item] === type && eff > 1) mod *= 0.5;
	const defAlly = defender.side.active.find(p => alive(p) && p !== defender);
	if (defAlly && defAlly.ability === 'friendguard') mod *= 0.75;

	const avg = Math.floor(base * mod * 0.925);
	const min = Math.floor(base * mod * 0.85);
	return {avg, min, eff};
}

function accuracyOf(attacker, defender, move) {
	if (move.accuracy === true) return 1;
	if (attacker.ability === 'noguard' || (defender && defender.ability === 'noguard')) return 1;
	let acc = move.accuracy / 100;
	if (attacker.ability === 'compoundeyes') acc *= 1.3;
	return Math.min(1, acc);
}

function speedOf(battle, p) {
	let s = p.storedStats.spe * boostMult(p.boosts.spe || 0);
	if (p.side.sideConditions.tailwind) s *= 2;
	if (p.status === 'par') s *= 0.5;
	if (p.item === 'choicescarf') s *= 1.5;
	const w = battle.field.weather;
	if ((p.ability === 'chlorophyll' && w === 'sunnyday') || (p.ability === 'swiftswim' && w === 'raindance') ||
		(p.ability === 'sandrush' && w === 'sandstorm') || (p.ability === 'slushrush' && w === 'snowscape')) s *= 2;
	return s;
}
function outspeeds(battle, a, b) {
	const tr = !!battle.field.pseudoWeather.trickroom;
	const sa = speedOf(battle, a), sb = speedOf(battle, b);
	return tr ? sa < sb : sa > sb;
}

// Se o Pokémon ainda pode Mega evoluir (tem a pedra e o lado não usou a Mega), devolve uma
// visão dele já na forma Mega (stats, tipos e habilidade), para a estimativa de ameaça
// não subestimar, por exemplo, o Zap Cannon de um Raichu que vai virar Mega-Y (No Guard).
function megaView(battle, p) {
	// canMegaEvo traz o nome da forma Mega e vira false quando o lado já usou a Mega
	const megaName = p.canMegaEvo || p.canMegaEvoX || p.canMegaEvoY;
	if (!megaName || p.species.isMega) return p;
	const mega = battle.dex.species.get(megaName);
	if (!mega || !mega.exists) return p;
	const stats = battle.spreadModify(mega.baseStats, p.set);
	const view = Object.create(p);
	view.storedStats = {atk: stats.atk, def: stats.def, spa: stats.spa, spd: stats.spd, spe: stats.spe};
	view.ability = toID(mega.abilities[0]);
	view.species = mega;
	view.getTypes = () => mega.types;
	view.hasType = t => (Array.isArray(t) ? t : [t]).some(x => mega.types.includes(x));
	return view;
}

// Maior dano que `attacker` consegue causar em `defender` com algum golpe (em HP).
// singleOnly: só golpes de alvo único (os que Follow Me / Rage Powder puxam).
function bestDamage(battle, attacker, defender, singleOnly = false) {
	attacker = megaView(battle, attacker);
	let best = 0;
	for (const ms of attacker.moveSlots) {
		const move = battle.dex.moves.get(ms.id);
		if (move.category === 'Status') continue;
		const spread = ['allAdjacentFoes', 'allAdjacent'].includes(move.target);
		if (singleOnly && spread) continue;
		const d = estimateDamage(battle, attacker, defender, move, {spread}).avg * accuracyOf(attacker, defender, move);
		if (d > best) best = d;
	}
	return best;
}

// ---------------------------------------------------------------------------
// Bot heurístico
// ---------------------------------------------------------------------------
function makePlayerClass(BattlePlayer) {
	return class HeuristicPlayer extends BattlePlayer {
		constructor(stream, battleStream, sideIndex, cfg = {}) {
			super(stream, false);
			this.bs = battleStream;
			this.sideIndex = sideIndex;
			this.cfg = cfg; // {previa: [4 nomes, os 2 primeiros lideram], mega: [ordem de preferência]}
			this.preview = null;
			this.fallbacks = 0;
			// Regras opcionais aprendidas dos vídeos (Battle Room), ligadas uma a uma para teste:
			//   troca   — trocar a peça ameaçada pela que recebe menos do golpe esperado
			//   protect — descontar golpes num alvo que tem Protect e está ameaçado; atacar direto quem não tem
			//   dividir — dois golpes no mesmo alvo só se juntos derrubam; senão, dividir entre os slots
			//   fim     — no fim do jogo (sem banco dos dois lados), escolher a jogada que vence contra as respostas
			//   setup   — usar o boost no turno em que o adversário ameaçado tende a trocar
			this.R = new Set(cfg.regras || []);
		}

		// Com preferência de Mega: só evolui o primeiro da lista que ainda pode evoluir.
		// Se nenhum da lista estiver disponível, evolui quem puder.
		megaAllowed(me) {
			if (!this.cfg.mega || !this.cfg.mega.length) return true;
			for (const name of this.cfg.mega) {
				const id = toID(name);
				const p = this.mySide.pokemon.find(x => toID(x.baseSpecies.baseSpecies) === id || toID(x.baseSpecies.name) === id);
				if (p && p.hp > 0 && !p.fainted && p.getItem().megaStone) return p === me;
			}
			return true;
		}
		get battle() { return this.bs.battle; }
		get mySide() { return this.battle.sides[this.sideIndex]; }
		get foeSide() { return this.battle.sides[1 - this.sideIndex]; }

		receiveError(error) {
			if (error.message.startsWith('[Unavailable choice]')) return;
			// Escolha inválida: o Showdown escolhe sozinho para não travar a batalha.
			this.fallbacks++;
			if (process.env.DEBUG_FB) console.error('FB', this.sideIndex, error.message, '|', this.ultimaEscolha);
			this.choose('default');
		}

		receiveRequest(request) {
			if (request.wait) return;
			let choice;
			try {
				if (request.teamPreview) choice = this.chooseTeamPreview(request);
				else if (request.forceSwitch) choice = this.chooseForcedSwitch(request);
				else if (request.active) choice = this.chooseMoves(request);
			} catch (e) {
				if (process.env.DEBUG_FB) console.error('EXC', this.sideIndex, e.stack.split('\n').slice(0, 3).join(' '));
				choice = 'default';
				this.fallbacks++;
			}
			this.ultimaEscolha = choice;
			if (choice) this.choose(choice);
		}

		// ---- prévia de time -------------------------------------------------
		matchupScore(me, foes) {
			const b = this.battle;
			let off = 0, def = 0;
			for (const f of foes) {
				off += Math.min(1, bestDamage(b, me, f) / f.maxhp);
				def += Math.min(1, bestDamage(b, f, me) / me.maxhp);
			}
			return {off: off / foes.length, def: def / foes.length};
		}
		roleBonus(p) {
			const ids = p.moveSlots.map(m => m.id);
			let bonus = 0;
			if (ids.includes('fakeout')) bonus += 0.1;
			if (ids.includes('tailwind') || ids.includes('trickroom')) bonus += 0.1;
			if (p.ability === 'intimidate') bonus += 0.05;
			if (p.getItem().megaStone) bonus += 0.05;
			return bonus;
		}
		chooseTeamPreview(request) {
			const size = request.maxChosenTeamSize || 4;
			const mine = this.mySide.pokemon;
			const foes = this.foeSide.pokemon;
			if (this.cfg.previa) {
				const idx = this.cfg.previa.map(name => findMon(mine, name));
				this.preview = {
					escolhidos: idx.map(i => mine[i].species.name),
					leads: idx.slice(0, 2).map(i => mine[i].species.name),
				};
				return 'team ' + idx.map(i => i + 1).join('');
			}
			const scored = mine.map((p, i) => {
				const m = this.matchupScore(p, foes);
				return {i, p, off: m.off, value: m.off - 0.6 * m.def + this.roleBonus(p)};
			});
			// Escolha gulosa. Mega só evolui uma vez por batalha, então um segundo
			// portador de Mega Stone perde 0,15 de valor.
			const picked = [];
			let megas = 0;
			const rest = [...scored];
			while (picked.length < size && rest.length) {
				const adj = s => s.value - (s.p.getItem().megaStone && megas >= 1 ? 0.15 : 0);
				rest.sort((a, b) => adj(b) - adj(a) || a.i - b.i);
				const s = rest.shift();
				if (s.p.getItem().megaStone) megas++;
				picked.push(s);
			}
			// Leads: maior pressão ofensiva + Fake Out / controle de Speed
			const leadScore = s => {
				const ids = s.p.moveSlots.map(m => m.id);
				return s.off + (ids.includes('fakeout') ? 0.15 : 0) + (ids.some(id => ['tailwind', 'trickroom'].includes(id)) ? 0.15 : 0);
			};
			const order = [...picked].sort((a, b) => leadScore(b) - leadScore(a) || a.i - b.i);
			this.preview = {
				escolhidos: order.map(s => s.p.species.name),
				leads: order.slice(0, 2).map(s => s.p.species.name),
			};
			return 'team ' + order.map(s => s.i + 1).join('');
		}

		// ---- trocas forçadas ------------------------------------------------
		chooseForcedSwitch(request) {
			const foes = this.foeSide.active.filter(alive);
			const used = new Set();
			const parts = request.forceSwitch.map((must, slot) => {
				if (!must) return 'pass';
				let best = null;
				request.side.pokemon.forEach((info, i) => {
					if (info.active || info.condition.endsWith(' fnt') || used.has(i)) return;
					const p = this.mySide.pokemon[i];
					const m = foes.length ? this.matchupScore(p, foes) : {off: 0, def: 0};
					const v = m.off - 0.7 * m.def;
					if (!best || v > best.v) best = {i, v};
				});
				if (!best) return 'pass';
				used.add(best.i);
				return `switch ${best.i + 1}`;
			});
			return parts.join(', ');
		}

		// ---- regras aprendidas (ver this.R) ---------------------------------
		bancoVivo(side) {
			if (this.bancoFixo && this.bancoFixo[side === this.mySide ? 'meu' : 'dele']) return this.bancoFixo[side === this.mySide ? 'meu' : 'dele'];
			return side.pokemon.filter(p => alive(p) && !p.isActive);
		}
		// Chance de o alvo usar Protect neste turno (regra "protect")
		pProtect(t) {
			if (!this.R.has('protect') || t.side === this.mySide) return 0;
			if (!t.moveSlots.some(ms => PROTECT_MOVES.has(ms.id))) return 0;
			if (t.lastMove && PROTECT_MOVES.has(t.lastMove.id) && t.volatiles.stall) return 0.03;
			const ameacado = this.mySide.active.some(a => alive(a) && bestDamage(this.battle, a, t) >= t.hp);
			return ameacado ? 0.35 : 0.12;
		}
		// Chance de o alvo trocar: ameaçado de KO, quase sem dano em nós e com banco (regra "setup")
		pTroca(t) {
			if (!this.R.has('setup') || t.side === this.mySide) return 0;
			if (!this.bancoVivo(t.side).length) return 0;
			const b = this.battle;
			const ameacado = this.mySide.active.some(a => alive(a) && bestDamage(b, a, t) >= t.hp);
			if (!ameacado) return 0;
			const fraco = this.mySide.active.filter(alive).every(a => bestDamage(b, t, a) < 0.35 * a.hp);
			return fraco ? 0.4 : 0;
		}
		// Valor de trocar `me` por alguém do banco (regra "troca"). banco: lista de Pokémon.
		opcaoTroca(me, danger, banco) {
			if (!this.R.has('troca') || !banco.length) return null;
			if (!(danger.fasterKO || danger.frac >= 1)) return null;
			const b = this.battle;
			const foes = this.foeSide.active.filter(alive);
			if (!foes.length) return null;
			let best = null;
			for (const p of banco) {
				let inc = 0, off = 0;
				for (const f of foes) {
					inc += bestDamage(b, f, p) / p.maxhp;
					off = Math.max(off, Math.min(1, bestDamage(b, p, f) / f.hp));
				}
				const value = 0.95 * (danger.fasterKO ? 1 : 0.7) * Math.max(0, 1 - 1.3 * inc) + 0.15 * off;
				if (!best || value > best.value) best = {value, p};
			}
			return best;
		}
		// Fim de jogo (regra "fim"): todos os vivos em campo; testa as combinações de jogadas
		// contra as respostas do adversário com dano médio e ordem de ação, e fica com a melhor
		// mistura de pior caso (60%) e média (40%).
		planoFinal(request, opcoesPorSlot) {
			if (!this.R.has('fim')) return null;
			const b = this.battle;
			const meusBanco = request.side.pokemon.filter(p => !p.active && !p.condition.endsWith(' fnt'));
			if (meusBanco.length || this.bancoVivo(this.foeSide).length) return null;
			const nossos = this.mySide.active.filter(alive), deles = this.foeSide.active.filter(alive);
			if (!nossos.length || !deles.length) return null;
			const protegeuAntes = p => p.lastMove && PROTECT_MOVES.has(p.lastMove.id) && p.volatiles.stall;
			// opções do adversário
			const opF = deles.map(f => {
				const L = [];
				for (const ms of f.moveSlots) {
					const mv = b.dex.moves.get(ms.id);
					if (PROTECT_MOVES.has(mv.id)) { if (!protegeuAntes(f)) L.push({user: f, move: mv, prot: true}); continue; }
					if (mv.category === 'Status') continue;
					if (['allAdjacentFoes', 'allAdjacent'].includes(mv.target)) L.push({user: f, move: mv, spread: true});
					else for (const t of nossos) L.push({user: f, move: mv, alvo: t});
				}
				L.sort((x, y) => (y.prot ? 0.5 : this.danoPrev(y)) - (x.prot ? 0.5 : this.danoPrev(x)));
				return L.slice(0, 5);
			});
			const prod = listas => listas.reduce((acc, l) => acc.flatMap(a => l.map(x => [...a, x])), [[]]);
			const jogF = prod(opF.filter(l => l.length));
			const jogN = prod(opcoesPorSlot.map(l => l.slice(0, 5)));
			if (!jogN.length || !jogF.length || jogN.length * jogF.length > 4000) return null;
			let melhor = null;
			for (const jn of jogN) {
				let pior = Infinity, soma = 0;
				for (const jf of jogF) {
					const sc = this.simTurno(jn.map(o => ({user: o.user, move: o.move, alvo: o.targetMon, spread: ['allAdjacentFoes', 'allAdjacent'].includes(o.move.target), prot: PROTECT_MOVES.has(o.move.id)})), jf);
					pior = Math.min(pior, sc);
					soma += sc;
				}
				const v = 0.6 * pior + 0.4 * soma / jogF.length;
				if (!melhor || v > melhor.v) melhor = {v, jn};
			}
			return melhor && melhor.jn;
		}
		danoPrev(a) {
			const b = this.battle;
			if (a.spread) return this.mySide.active.filter(alive).reduce((s, t) => s + estimateDamage(b, a.user, t, a.move, {spread: true}).avg / t.maxhp, 0);
			return estimateDamage(b, a.user, a.alvo, a.move).avg / a.alvo.maxhp;
		}
		simTurno(nossas, delas) {
			const b = this.battle;
			const hp = new Map();
			const todos = [...this.mySide.active, ...this.foeSide.active].filter(alive);
			for (const p of todos) hp.set(p, p.hp);
			const prot = new Set(), flinch = new Set();
			const acoes = [...nossas, ...delas].filter(a => a.move);
			const tr = !!b.field.pseudoWeather.trickroom;
			acoes.sort((x, y) => (y.move.priority - x.move.priority) ||
				(tr ? speedOf(b, x.user) - speedOf(b, y.user) : speedOf(b, y.user) - speedOf(b, x.user)));
			for (const a of acoes) {
				if (hp.get(a.user) <= 0 || flinch.has(a.user)) continue;
				if (a.prot) { prot.add(a.user); continue; }
				if (a.move.category === 'Status') continue;
				const ladoAlvo = a.user.side === this.mySide ? this.foeSide : this.mySide;
				let alvos;
				if (a.spread) {
					alvos = ladoAlvo.active.filter(p => alive(p) && hp.get(p) > 0);
					if (a.move.target === 'allAdjacent') alvos.push(...a.user.side.active.filter(p => alive(p) && p !== a.user && hp.get(p) > 0));
				} else {
					let t = a.alvo;
					if (!t || !(hp.get(t) > 0)) t = ladoAlvo.active.find(p => alive(p) && hp.get(p) > 0);
					alvos = t ? [t] : [];
				}
				let causado = 0;
				for (const t of alvos) {
					if (prot.has(t) && a.move.id !== 'feint') continue;
					if (a.move.id === 'feint') prot.delete(t);
					const est = estimateDamage(b, a.user, t, a.move, {spread: alvos.length > 1});
					const acc = accuracyOf(a.user, t, a.move);
					const d = Math.min(hp.get(t), est.avg * (acc >= 0.9 ? 1 : acc));
					hp.set(t, hp.get(t) - d);
					causado += d;
					if (a.move.id === 'fakeout' && a.user.activeMoveActions === 0 && d > 0 && t.ability !== 'innerfocus') flinch.add(t);
				}
				if (causado > 0) {
					let rec = 0;
					if (a.move.recoil) rec += causado * a.move.recoil[0] / a.move.recoil[1];
					if (a.user.item === 'lifeorb') rec += a.user.maxhp / 10;
					hp.set(a.user, hp.get(a.user) - rec);
				}
			}
			let sc = 0;
			for (const p of todos) {
				const sinal = p.side === this.mySide ? 1 : -1;
				const h = Math.max(0, hp.get(p));
				sc += sinal * ((h > 0 ? 1 : 0) + 0.5 * h / p.maxhp);
			}
			return sc;
		}

		// ---- escolha de golpes ----------------------------------------------
		// Probabilidade de cada candidato: frequências observadas (com recuo) misturadas com a heurística
		probPolitica(me, cands, melhorPorGolpe) {
			const M = this.cfg.modelo;
			const b = this.battle;
			const hp = 100 * me.hp / me.maxhp;
			const fase = b.turn === 1 ? 'T1' : (me.activeMoveActions === 0 ? 'entrada' : 'meio');
			const hpB = hp > 66 ? 'alto' : (hp > 33 ? 'medio' : 'baixo');
			const pa = me.lastMove && PROTECT_MOVES.has(me.lastMove.id) && me.volatiles.stall && me.activeMoveActions > 0 ? 'P' : '-';
			const tr = b.field.pseudoWeather.trickroom ? 'TR' : '-';
			const tw = this.mySide.sideConditions.tailwind ? 'TW' : '-';
			const two = this.foeSide.sideConditions.tailwind ? 'tw' : '-';
			const ctxs = [[fase, hpB, pa, tr, tw, two], [fase, hpB, pa], [fase, pa], [fase], []];
			const esp = me.baseSpecies.name;
			const isProt = m => PROTECT_MOVES.has(toID(m));
			// prior por classe (Protect / troca / outros) no contexto mais específico com dados
			let g = null;
			for (const c of ctxs) {
				const x = M.prior[c.join('|')];
				if (x && Object.values(x).reduce((s, v) => s + v, 0) > 20) { g = x; break; }
			}
			g = g || {};
			const tot = Object.values(g).reduce((s, v) => s + v, 0) || 1;
			const classes = {protect: cands.filter(isProt), troca: cands.filter(m => m === '(troca)'),
				outro: cands.filter(m => !isProt(m) && m !== '(troca)')};
			let p = {};
			for (const [k, ms] of Object.entries(classes)) {
				for (const m of ms) p[m] = ((g[k] || 0) + 1) / (tot + 3) / ms.length;
			}
			let s = Object.values(p).reduce((a, v) => a + v, 0);
			for (const m of cands) p[m] = (p[m] || 0) / s;
			const porEsp = M.contagens[esp] || {};
			for (const c of [...ctxs].reverse()) {
				const cnt = porEsp[c.join('|')];
				if (!cnt) continue;
				const n = cands.reduce((a, m) => a + (cnt[m] || 0), 0);
				const q = {};
				for (const m of cands) q[m] = ((cnt[m] || 0) + M.alfa * p[m]) / (n + M.alfa);
				p = q;
			}
			s = Object.values(p).reduce((a, v) => a + v, 0);
			for (const m of cands) p[m] = (1 - M.eps) * p[m] / s + M.eps / cands.length;
			// heurística em softmax
			const vals = {};
			for (const m of cands) vals[m] = melhorPorGolpe.has(m) ? melhorPorGolpe.get(m).value : 0;
			const mx = Math.max(...Object.values(vals));
			let z = 0;
			const h = {};
			for (const m of cands) { h[m] = Math.exp((vals[m] - mx) / M.temperatura); z += h[m]; }
			const out = {};
			for (const m of cands) out[m] = M.peso_frequencias * p[m] + (1 - M.peso_frequencias) * h[m] / z;
			return out;
		}

		// Mega pelos dados: chance observada de evoluir na primeira oportunidade (T1) ou depois
		querMega(me) {
			const M = this.cfg.modelo;
			if (!M) return true;
			const d = M.mega[me.baseSpecies.name];
			const k = this.battle.turn === 1 ? 'T1' : 'depois';
			const sim = d ? (d[k + '_sim'] || 0) : 0, n = d ? (d[k + '_n'] || 0) : 0;
			const prob = (sim + 1) / (n + 2);
			return this.cfg.rng() < prob;
		}

		chooseMoves(request) {
			this.trocasNoTurno = new Set();
			const b = this.battle;
			const actives = this.mySide.active;
			const foes = this.foeSide.active;
			const parts = [];
			let megaUsed = false;
			let committed = null; // {target, ko} da primeira posição
			// Fim de jogo: plano conjunto para os dois slots (regra "fim")
			let plano = null;
			if (this.R.has('fim') && !this.cfg.modelo) {
				const opcoes = request.active.map((reqActive, slot) => {
					const me = actives[slot];
					if (!reqActive || !alive(me)) return [];
					const ally = actives[1 - slot];
					const danger = this.dangerTo(me);
					const L = [];
					reqActive.moves.forEach((m, mi) => {
						if (m.disabled || (m.pp !== undefined && m.pp <= 0 && m.id !== 'struggle')) return;
						const move = b.dex.moves.get(m.id);
						for (const opt of this.scoreMove(me, ally, move, m.target || move.target, danger, null)) {
							if (opt.value > -1) L.push({...opt, mi, move, user: me});
						}
					});
					L.sort((x, y) => y.value - x.value);
					// garante Protect entre as opções, se houver
					const pr = L.find(o => PROTECT_MOVES.has(o.move.id));
					const top = L.slice(0, 4);
					if (pr && !top.includes(pr)) top.push(pr);
					return top;
				}).filter(l => l.length);
				try { plano = this.planoFinal(request, opcoes); } catch (e) { plano = null; }
			}

			request.active.forEach((reqActive, slot) => {
				const me = actives[slot];
				const info = request.side.pokemon[slot];
				if (!reqActive || !alive(me) || (info && info.condition.endsWith(' fnt')) || info?.commanding) {
					parts.push('pass');
					return;
				}
				const ally = actives[1 - slot];
				const options = [];
				const danger = this.dangerTo(me);

				reqActive.moves.forEach((m, mi) => {
					if (m.disabled || (m.pp !== undefined && m.pp <= 0 && m.id !== 'struggle')) return;
					const move = b.dex.moves.get(m.id);
					const targetType = m.target || move.target;
					for (const opt of this.scoreMove(me, ally, move, targetType, danger, committed)) {
						options.push({...opt, mi, move});
					}
				});

				options.sort((x, y) => y.value - x.value);
				let chosen = options[0];
				if (!chosen) {
					parts.push('move 1');
					return;
				}
				if (plano) {
					const p = plano.find(o => o.user === me);
					const o = p && options.find(x => x.mi === p.mi && x.target === p.target);
					if (o) chosen = o;
				}
				const bancoReq = reqActive.trapped ? [] : request.side.pokemon
					.map((p, i) => ({p, i}))
					.filter(({p, i}) => !p.active && !p.condition.endsWith(' fnt') && !this.trocasNoTurno.has(i));
				const troca = this.opcaoTroca(me, danger, bancoReq.map(({i}) => this.mySide.pokemon[i]));
				// Bot puro: troca se valer mais que o melhor golpe
				if (!this.cfg.modelo && !plano && troca && troca.value > chosen.value) {
					const i = this.mySide.pokemon.indexOf(troca.p);
					this.trocasNoTurno.add(i);
					parts.push(`switch ${i + 1}`);
					return;
				}
				const megaCmd = reqActive.canMegaEvo ? 'mega' : reqActive.canMegaEvoX ? 'megax' : reqActive.canMegaEvoY ? 'megay' : null;

				// Política guiada pelos dados: mistura frequências observadas com a heurística e sorteia
				if (this.cfg.modelo) {
					const melhorPorGolpe = new Map();
					for (const o of options) if (!melhorPorGolpe.has(o.move.name)) melhorPorGolpe.set(o.move.name, o);
					const banco = bancoReq;
					const cands = [...melhorPorGolpe.keys()];
					if (banco.length) cands.push('(troca)');
					if (troca) melhorPorGolpe.set('(troca)', {value: troca.value});
					const probs = this.probPolitica(me, cands, melhorPorGolpe);
					const escolha = sortear(probs, this.cfg.rng);
					if (escolha === '(troca)') {
						const foesVivos = this.foeSide.active.filter(alive);
						let best = troca ? {i: this.mySide.pokemon.indexOf(troca.p)} : null;
						if (!best) for (const {i} of banco) {
							const p = this.mySide.pokemon[i];
							const m = foesVivos.length ? this.matchupScore(p, foesVivos) : {off: 0, def: 0};
							const v = m.off - 0.7 * m.def;
							if (!best || v > best.v) best = {i, v};
						}
						this.trocasNoTurno.add(best.i);
						parts.push(`switch ${best.i + 1}`);
						return;
					}
					chosen = melhorPorGolpe.get(escolha) || chosen;
				}

				let cmd = `move ${chosen.mi + 1}`;
				// Golpe travado (2º turno de Electro Shot / Solar Beam) vem sem alvo na requisição
				if (chosen.target !== undefined && reqActive.moves[chosen.mi]?.target !== undefined) cmd += ` ${chosen.target}`;
				if (!megaUsed && megaCmd && this.megaAllowed(me) && this.querMega(me)) {
					cmd += ' ' + megaCmd;
					megaUsed = true;
				}
				if (slot === 0) {
					committed = {target: chosen.targetMon || null, ko: chosen.ko, dmg: chosen.dmg || 0, moveId: chosen.move.id,
						fakeout: chosen.move.id === 'fakeout' ? chosen.targetMon : null};
				}
				parts.push(cmd);
			});
			return parts.join(', ');
		}

		// Dano esperado que os oponentes ativos causam em `me`, como fração do HP atual
		dangerTo(me) {
			let total = 0, fasterKO = false;
			for (const f of this.foeSide.active) {
				if (!alive(f)) continue;
				const d = bestDamage(this.battle, f, me);
				total += d;
				if (d >= me.hp && outspeeds(this.battle, f, me)) fasterKO = true;
			}
			return {frac: total / Math.max(1, me.hp), fasterKO};
		}

		scoreMove(me, ally, move, targetType, danger, committed) {
			const b = this.battle;
			const foes = this.foeSide.active.map((p, i) => ({p, loc: i + 1})).filter(x => alive(x.p));
			const allyAlive = alive(ally);
			const allyLoc = allyAlive ? -(this.mySide.active.indexOf(ally) + 1) : null;
			const out = [];
			const firstTurn = me.activeMoveActions === 0;

			if (move.id === 'fakeout' || move.id === 'firstimpression') {
				if (!firstTurn) return [{value: -1, target: foes[0]?.loc}];
			}

			// --- golpes de dano
			if (move.category !== 'Status') {
				const selfDrop = move.self?.boosts && Object.values(move.self.boosts).some(v => v < 0);
				const penalty = (selfDrop ? 0.05 : 0) + (move.recoil ? 0.03 : 0);
				const speedDrop = move.secondary?.boosts?.spe < 0 || move.secondaries?.some(s => s.boosts?.spe < 0);

				const valueOn = (target, spread) => {
					const est = estimateDamage(b, me, target, move, {spread});
					const acc = accuracyOf(me, target, move);
					const frac = Math.min(est.avg, target.hp) / target.maxhp;
					const koBonus = est.min >= target.hp ? 0.6 : est.avg >= target.hp ? 0.35 : 0;
					let v = acc * (frac + koBonus);
					if (speedDrop && est.avg > 0 && !outspeeds(b, me, target)) v += 0.1;
					if (move.id === 'fakeout' && est.eff > 0 && target.ability !== 'innerfocus') {
						// Fake Out vale mais quando segura um oponente mais rápido que derrubaria um dos nossos
						const threatensKO = this.mySide.active.some(a => alive(a) &&
							bestDamage(b, target, a) >= a.hp && outspeeds(b, target, a));
						v += threatensKO ? 1.0 : 0.4;
						if (committed && committed.fakeout === target) v = 0;
					}
					if (target.side !== this.mySide) {
						// Regra "protect": alvo com Protect e ameaçado tende a proteger; Feint fura
						const pp = this.pProtect(target);
						v *= (move.id === 'feint' ? 1 : 1 - pp) * (1 - this.pTroca(target));
						if (move.id === 'feint') v += 0.5 * pp;
						// Regra "troca": se o adversário age antes e nos derruba, o golpe pode não sair
						if (this.R.has('troca') && danger.fasterKO && move.priority <= 0) v *= 0.5;
					}
					return {v, ko: est.avg >= target.hp, dmg: est.avg};
				};

				if (['allAdjacentFoes', 'allAdjacent'].includes(targetType)) {
					const spread = foes.length + (targetType === 'allAdjacent' && allyAlive ? 1 : 0) > 1;
					let v = 0;
					for (const f of foes) v += valueOn(f.p, spread).v;
					if (targetType === 'allAdjacent' && allyAlive) {
						const est = estimateDamage(b, me, ally, move, {spread});
						v -= 1.5 * Math.min(est.avg, ally.hp) / ally.maxhp + (est.avg >= ally.hp ? 1 : 0);
					}
					out.push({value: v - penalty});
				} else if (['normal', 'any', 'adjacentFoe', 'randomNormal'].includes(targetType)) {
					// Redirecionamento (Lightning Rod / Storm Drain) anula golpes de alvo único
					const redirector = foes.find(f => REDIRECT[f.p.ability] === move.type);
					for (const f of foes) {
						let {v, ko, dmg} = valueOn(f.p, false);
						if (redirector && targetType !== 'randomNormal') v = 0;
						if (committed && committed.target === f.p && committed.ko) v *= 0.4;
						// Regra "dividir": dobrar só se os dois golpes juntos derrubam
						if (this.R.has('dividir') && committed && committed.target === f.p && !committed.ko && foes.length > 1) {
							v *= (committed.dmg || 0) + dmg >= f.p.hp ? 1.2 : 0.75;
						}
						out.push({value: v - penalty, target: targetType === 'randomNormal' ? undefined : f.loc, targetMon: f.p, ko, dmg});
					}
				} else {
					out.push({value: 0.05});
				}
				return out;
			}

			// --- golpes de status
			const id = move.id;
			if (PROTECT_MOVES.has(id)) {
				const usedLast = me.lastMove && PROTECT_MOVES.has(me.lastMove.id) && me.volatiles.stall;
				if (usedLast) return [{value: -1}];
				let v = 0.05;
				if (danger.fasterKO) v = 0.7;
				else if (danger.frac >= 1) v = 0.45;
				else if (danger.frac >= 0.6) v = 0.2;
				return [{value: v}];
			}
			if (id === 'tailwind') {
				if (this.mySide.sideConditions.tailwind) return [{value: -1}];
				// Tailwind e Trick Room se anulam: não combinar no mesmo turno nem com o TR ativo
				if (committed && committed.moveId === 'trickroom') return [{value: -1}];
				// Vale mais quando algum oponente ativo passa algum dos nossos ativos
				const ours = this.mySide.active.filter(alive);
				const outsped = foes.some(f => ours.some(a => outspeeds(b, f.p, a)));
				return [{value: 0.5 + (outsped ? 0.4 : 0)}];
			}
			if (id === 'trickroom') {
				const tr = !!b.field.pseudoWeather.trickroom;
				if (!tr && (this.mySide.sideConditions.tailwind || (committed && committed.moveId === 'tailwind'))) return [{value: -1}];
				const avg = side => {
					const ps = side.pokemon.filter(alive);
					return ps.reduce((s, p) => s + p.storedStats.spe, 0) / Math.max(1, ps.length);
				};
				const weSlower = avg(this.mySide) < avg(this.foeSide);
				if (!tr) return [{value: weSlower ? 0.75 : -1}];
				// TR adversário ativo e somos mais rápidos: desfazer é a prioridade
				return [{value: weSlower ? -1 : 0.95}];
			}
			if (id === 'followme' || id === 'ragepowder') {
				if (!allyAlive) return [{value: -1}];
				// Puxa só golpes de alvo único: vale muito quando um deles derrubaria o parceiro,
				// mesmo que o redirecionador caia no lugar (troca planejada, como no C4 do playbook).
				let single = 0;
				for (const f of foes) single = Math.max(single, bestDamage(b, f.p, ally, true));
				const v = single >= ally.hp ? 0.9 : single / ally.hp >= 0.6 ? 0.45 : 0.1;
				return [{value: v}];
			}
			if (id === 'helpinghand') {
				return allyAlive ? [{value: 0.25, target: allyLoc}] : [];
			}
			if (id === 'wideguard' || id === 'quickguard') {
				const flag = id === 'wideguard'
					? m => ['allAdjacentFoes', 'allAdjacent'].includes(m.target) && m.category !== 'Status'
					: m => m.priority > 0 && m.category !== 'Status';
				const threat = foes.some(f => f.p.moveSlots.some(ms => flag(b.dex.moves.get(ms.id))));
				const usedLast = me.lastMove && me.lastMove.id === id;
				return [{value: threat && !usedLast ? 0.3 : 0.02}];
			}
			if (['reflect', 'lightscreen', 'auroraveil'].includes(id)) {
				if (this.mySide.sideConditions[id]) return [{value: -1}];
				if (id === 'auroraveil' && b.field.weather !== 'snowscape') return [{value: -1}];
				return [{value: 0.35}];
			}
			if (move.heal || move.flags.heal) {
				return [{value: me.hp / me.maxhp < 0.5 ? 0.45 : 0}];
			}
			if (move.target === 'self' && move.boosts) {
				const stats = Object.keys(move.boosts);
				const capped = stats.every(s => (me.boosts[s] || 0) >= 2);
				let v = me.hp / me.maxhp > 0.6 && danger.frac < 0.5 && !capped ? 0.35 : 0.03;
				// Regra "setup": adversário ameaçado e sem dano em nós tende a trocar: turno de boost
				if (this.R.has('setup') && !capped && me.hp / me.maxhp > 0.5 && danger.frac < 0.5 && foes.some(f => this.pTroca(f.p) > 0)) v = 0.8;
				return [{value: v}];
			}
			if (id === 'partingshot' || id === 'chillyreception') {
				const v = 0.15 + (danger.frac >= 1 ? 0.25 : 0);
				return foes.length ? foes.map(f => ({value: f.p.ability === 'goodasgold' ? 0 : v, target: f.loc})) : [{value: 0}];
			}

			// Status em alvo inimigo (Spore, Thunder Wave, Will-O-Wisp, Taunt, Encore...)
			if (['normal', 'adjacentFoe', 'any'].includes(targetType)) {
				for (const f of foes) {
					const t = f.p;
					let v = 0.08;
					const blocked = t.ability === 'goodasgold' ||
						(me.ability === 'prankster' && t.hasType('Dark')) ||
						(move.flags.powder && (t.hasType('Grass') || t.ability === 'overcoat' || t.item === 'safetygoggles'));
					if (move.status) {
						const immune = (STATUS_TYPE_IMMUNE[move.status] || []).some(ty => t.hasType(ty)) ||
							(move.status === 'par' && move.type === 'Electric' && t.hasType('Ground'));
						v = t.status || immune ? 0 : move.status === 'slp' ? 0.5 : 0.3;
					}
					if (id === 'taunt') {
						const setup = t.moveSlots.some(ms => ['trickroom', 'tailwind', 'followme', 'ragepowder'].includes(ms.id));
						v = t.volatiles.taunt ? 0 : setup ? 0.4 : 0.12;
					}
					if (move.volatileStatus && t.volatiles[move.volatileStatus]) v = 0;
					out.push({value: blocked ? 0 : v, target: f.loc});
				}
				return out.length ? out : [{value: 0}];
			}
			if (['adjacentAlly', 'adjacentAllyOrSelf'].includes(targetType)) {
				return allyAlive ? [{value: 0.05, target: allyLoc}] : [];
			}
			return [{value: 0.05}];
		}
	};
}

// ---------------------------------------------------------------------------
// Resumo legível de uma batalha a partir do log do Showdown
// ---------------------------------------------------------------------------
function summarizeLog(lines, names) {
	const out = [];
	// Após "|split|pN" vêm duas versões da mesma linha (HP exato e em %): usa a primeira.
	let split = 0;
	let current = [];
	const nick = id => {
		const [side, name] = id.split(': ');
		return `${names[side.slice(0, 2)]}:${name}`;
	};
	const flush = turn => { if (current.length) out.push(`${turn}: ${current.join(' | ')}`); current = []; };
	let turn = 'Prévia/entrada';
	for (const line of lines) {
		if (line.startsWith('|split|')) { split = 1; continue; }
		if (split === 2) { split = 0; continue; }
		if (split === 1) split = 2;
		const parts = line.split('|');
		const cmd = parts[1];
		if (cmd === 'turn') { flush(turn); turn = `Turno ${parts[2]}`; }
		else if (cmd === 'move') {
			const alvo = parts[4] && parts[4] !== parts[2] ? ' → ' + nick(parts[4]) : '';
			current.push(`${nick(parts[2])} usa ${parts[3]}${alvo}${parts.includes('[miss]') ? ' (errou)' : ''}`);
		}
		else if (cmd === 'switch' || cmd === 'drag') {
			const s = `${nick(parts[2])} entra (${parts[4]})`;
			if (current[current.length - 1] !== s) current.push(s);
		}
		else if (cmd === '-mega') current.push(`${nick(parts[2])} Mega evolui`);
		else if (cmd === 'faint') current.push(`${nick(parts[2])} desmaia`);
		else if (cmd === 'win') { current.push(`Vencedor: ${parts[2]}`); }
		else if (cmd === 'tie') { current.push('Empate'); }
	}
	flush(turn);
	return out.join('\n');
}

// ---------------------------------------------------------------------------
// Execução
// ---------------------------------------------------------------------------
function prepareTeam(sim, text, label, formatid) {
	const team = sim.Teams.import(text);
	if (!team || !team.length) throw new Error(`${label}: não consegui ler o time. Use o texto de exportação do Showdown.`);
	const problems = sim.TeamValidator.get(formatid).validateTeam(team);
	if (problems && problems.length) {
		const err = new Error(`${label} é ilegal em ${formatid}:\n  - ${problems.join('\n  - ')}`);
		err.validation = true;
		throw err;
	}
	// O validador aplica as regras de nível do formato (Adjust Level = 50) no próprio
	// objeto do time; por isso o time empacotado tem de ser o que passou pelo validador.
	return sim.Teams.pack(team);
}

async function runBattle(sim, Player, formatid, p1, p2, wantLog, semente = 1) {
	const stream = new sim.BattleStream();
	const ps = sim.getPlayerStreams(stream);
	const a = new Player(ps.p1, stream, 0, {...p1.cfg, rng: rngSemente(semente * 2 + 1)});
	const b = new Player(ps.p2, stream, 1, {...p2.cfg, rng: rngSemente(semente * 2 + 2)});
	void a.start();
	void b.start();
	const log = [];
	const reading = (async () => {
		for await (const chunk of ps.omniscient) if (wantLog) log.push(...chunk.split('\n'));
	})();
	void ps.omniscient.write(`>start ${JSON.stringify({formatid})}\n` +
		`>player p1 ${JSON.stringify({name: p1.name, team: p1.packed})}\n` +
		`>player p2 ${JSON.stringify({name: p2.name, team: p2.packed})}`);
	let timer;
	const timeout = new Promise(resolve => { timer = setTimeout(() => resolve('timeout'), 60000); });
	const r = await Promise.race([reading, timeout]);
	clearTimeout(timer);
	const battle = stream.battle;
	const base = p => p.baseSpecies.baseSpecies;
	const result = {
		timeout: r === 'timeout',
		winner: battle?.winner || '',
		turns: battle?.turn || 0,
		preview: [a.preview, b.preview],
		megas: battle ? battle.sides.map(s => s.pokemon.filter(p => p.species.isMega || /-Mega/.test(p.species.name)).map(base)) : [[], []],
		desmaios: battle ? battle.sides.map(s => s.pokemon.filter(p => p.fainted || p.hp <= 0).map(base)) : [[], []],
		fallbacks: a.fallbacks + b.fallbacks,
		log,
	};
	if (result.timeout) void stream.destroy?.();
	return result;
}

function wilson(k, n) {
	if (!n) return [0, 0];
	const z = 1.96, p = k / n;
	const den = 1 + z * z / n;
	const c = (p + z * z / (2 * n)) / den;
	const h = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den;
	return [Math.max(0, c - h), Math.min(1, c + h)];
}

// Regras ligadas por padrão (teste de 22/out/2026): só a "troca" passou nos dois testes —
// melhorou a previsão dos replays (log-loss) e a taxa de vitória do nosso lado (+2,6 pp em 3.300 batalhas).
// "protect", "dividir", "fim" e "setup" ficam desligadas; passe regrasA/regrasB para testar.
const REGRAS_PADRAO = ['troca'];

async function simular(textA, textB, options = {}) {
	const opts = {n: 100, formato: 'gen9championsvgc2026regmc', nomes: ['Time A', 'Time B'], log: false, ...options};
	const sim = loadShowdown(opts.ps);
	const format = sim.Dex.formats.get(opts.formato);
	if (!format.exists) throw new Error(`O formato "${opts.formato}" não existe nesta versão do Showdown.`);
	const formatid = format.id;
	const Player = makePlayerClass(sim.BattlePlayer);
	const carregar = x => !x ? null : (typeof x === 'string' ? JSON.parse(fs.readFileSync(x, 'utf8')) : x);
	const teams = [
		{name: opts.nomes[0], packed: prepareTeam(sim, textA, opts.nomes[0], formatid), cfg: {previa: opts.previaA, mega: opts.megaA, modelo: carregar(opts.modeloA), regras: opts.regrasA ?? REGRAS_PADRAO}},
		{name: opts.nomes[1], packed: prepareTeam(sim, textB, opts.nomes[1], formatid), cfg: {previa: opts.previaB, mega: opts.megaB, modelo: carregar(opts.modeloB), regras: opts.regrasB ?? REGRAS_PADRAO}},
	];
	// Confere a prévia fixa antes de começar
	[[opts.previaA, textA, opts.nomes[0]], [opts.previaB, textB, opts.nomes[1]]].forEach(([previa, text, label]) => {
		if (!previa) return;
		const sets = sim.Teams.import(text).map(s => ({...sim.Dex.species.get(s.species), species: sim.Dex.species.get(s.species), name: s.name}));
		if (previa.length !== 4 || new Set(previa.map(toID)).size !== 4) throw new Error(`${label}: a prévia fixa precisa de 4 nomes diferentes.`);
		for (const n of previa) {
			try { findMon(sets, n); } catch (e) { throw new Error(`${label}: ${e.message}`); }
		}
	});

	const stats = {
		formato: format.name, batalhas: 0, vitorias: [0, 0], empates: 0, erros: 0, turnos: [],
		previa: [{}, {}], leads: [{}, {}], megas: [{}, {}], desmaios: [{}, {}], fallbacks: 0, logs: [],
	};
	for (let i = 0; i < opts.n; i++) {
		// Alterna os lados (p1/p2) para não favorecer ninguém
		const swap = i % 2 === 1;
		const [p1, p2] = swap ? [teams[1], teams[0]] : [teams[0], teams[1]];
		const r = await runBattle(sim, Player, formatid, p1, p2, opts.log, (opts.semente || 1) * 100003 + i);
		stats.fallbacks += r.fallbacks;
		if (r.timeout) { stats.erros++; continue; }
		stats.batalhas++;
		stats.turnos.push(r.turns);
		if (r.winner === teams[0].name) stats.vitorias[0]++;
		else if (r.winner === teams[1].name) stats.vitorias[1]++;
		else stats.empates++;
		const prev = swap ? [r.preview[1], r.preview[0]] : r.preview;
		const order = swap ? [1, 0] : [0, 1];
		order.forEach((sideIdx, t) => {
			for (const m of r.megas[sideIdx]) stats.megas[t][m] = (stats.megas[t][m] || 0) + 1;
			for (const m of r.desmaios[sideIdx]) stats.desmaios[t][m] = (stats.desmaios[t][m] || 0) + 1;
		});
		prev.forEach((pv, t) => {
			if (!pv) return;
			for (const s of pv.escolhidos) stats.previa[t][s] = (stats.previa[t][s] || 0) + 1;
			const lead = pv.leads.join(' + ');
			stats.leads[t][lead] = (stats.leads[t][lead] || 0) + 1;
		});
		if (opts.log) {
			const names = swap ? {p1: teams[1].name, p2: teams[0].name} : {p1: teams[0].name, p2: teams[1].name};
			stats.logs.push({prev, texto: summarizeLog(r.log, names), vencedor: r.winner || 'empate', turnos: r.turns});
		}
	}
	return {stats, teams: teams.map(t => t.name)};
}

function report({stats, teams}) {
	const n = stats.batalhas;
	const lines = [];
	lines.push(`Formato: ${stats.formato}`);
	lines.push(`Batalhas concluídas: ${n}${stats.erros ? ` (${stats.erros} travaram e foram descartadas)` : ''}`);
	teams.forEach((t, i) => {
		const k = stats.vitorias[i];
		const [lo, hi] = wilson(k, n);
		lines.push(`${t}: ${k} vitórias (${(100 * k / Math.max(1, n)).toFixed(1)}%, IC95% ${(100 * lo).toFixed(0)}–${(100 * hi).toFixed(0)}%)`);
	});
	if (stats.empates) lines.push(`Empates: ${stats.empates}`);
	if (n) {
		const avg = stats.turnos.reduce((s, x) => s + x, 0) / n;
		lines.push(`Duração média: ${avg.toFixed(1)} turnos (mín. ${Math.min(...stats.turnos)}, máx. ${Math.max(...stats.turnos)})`);
	}
	teams.forEach((t, i) => {
		const pv = Object.entries(stats.previa[i]).sort((a, b) => b[1] - a[1]);
		lines.push(`Prévia ${t}: ${pv.map(([s, c]) => `${s} ${(100 * c / n).toFixed(0)}%`).join(', ')}`);
		const ld = Object.entries(stats.leads[i]).sort((a, b) => b[1] - a[1]);
		lines.push(`  Leads: ${ld.map(([s, c]) => `${s} ${(100 * c / n).toFixed(0)}%`).join(', ')}`);
		const mg = Object.entries(stats.megas[i]).sort((a, b) => b[1] - a[1]);
		const semMega = n - mg.reduce((s, [, c]) => s + c, 0);
		lines.push(`  Mega: ${mg.map(([s, c]) => `${s} ${(100 * c / n).toFixed(0)}%`).join(', ')}${semMega > 0 ? `${mg.length ? ', ' : ''}nenhuma ${(100 * semMega / n).toFixed(0)}%` : ''}`);
		const ds = Object.entries(stats.desmaios[i]).sort((a, b) => b[1] - a[1]);
		lines.push(`  Desmaios: ${ds.map(([s, c]) => `${s} ${(100 * c / n).toFixed(0)}%`).join(', ')}`);
	});
	if (stats.fallbacks) lines.push(`Aviso: ${stats.fallbacks} escolhas inválidas do bot foram trocadas pela escolha automática do Showdown.`);
	return lines.join('\n');
}

async function main() {
	const opts = parseArgs(process.argv.slice(2));
	if (opts.help || opts.files.length !== 2) {
		console.log('Uso: node simular.js timeA.txt timeB.txt [-n 100] [-f gen9championsvgc2026regmc] [--nomes A,B] [--log] [--json] [--ps pasta]');
		process.exit(opts.help ? 0 : 1);
	}
	if (!(opts.n > 0)) { console.error('Número de batalhas inválido.'); process.exit(1); }
	const nomes = opts.nomes || opts.files.map(f => path.basename(f).replace(/\.[^.]+$/, ''));
	if (nomes[0] === nomes[1]) { nomes[0] += ' (A)'; nomes[1] += ' (B)'; }
	let res;
	try {
		res = await simular(fs.readFileSync(opts.files[0], 'utf8'), fs.readFileSync(opts.files[1], 'utf8'),
			{n: opts.n, formato: opts.formato, nomes, log: opts.log, ps: opts.ps,
				previaA: opts.previaA, previaB: opts.previaB, megaA: opts.megaA, megaB: opts.megaB,
				modeloA: opts.modeloA, modeloB: opts.modeloB, semente: opts.semente});
	} catch (e) {
		console.error(`ERRO: ${e.message}`);
		process.exit(e.validation ? 2 : 1);
	}
	if (opts.log) {
		fs.mkdirSync('logs', {recursive: true});
		res.stats.logs.forEach((l, i) => fs.writeFileSync(path.join('logs', `batalha-${i + 1}.txt`),
			`Escolhidos: ${res.teams[0]} = ${l.prev[0]?.escolhidos.join(', ')}; ${res.teams[1]} = ${l.prev[1]?.escolhidos.join(', ')}\n` +
			`Leads: ${l.prev[0]?.leads.join(' + ')} vs ${l.prev[1]?.leads.join(' + ')}\n\n${l.texto}\n`));
		if (res.stats.logs[0] && !opts.json) {
			const l = res.stats.logs[0];
			console.log(`=== Batalha 1 ===\nEscolhidos: ${res.teams[0]} = ${l.prev[0]?.escolhidos.join(', ')}; ${res.teams[1]} = ${l.prev[1]?.escolhidos.join(', ')}`);
			console.log(`Leads: ${l.prev[0]?.leads.join(' + ')} vs ${l.prev[1]?.leads.join(' + ')}\n${l.texto}\n`);
		}
	}
	if (opts.json) {
		const {logs, ...rest} = res.stats;
		console.log(JSON.stringify({times: res.teams, ...rest}, null, 2));
	} else {
		console.log(report(res));
	}
}

module.exports = {simular, report, estimateDamage, makePlayerClass, loadShowdown, bestDamage, megaView};
if (require.main === module) void main();
