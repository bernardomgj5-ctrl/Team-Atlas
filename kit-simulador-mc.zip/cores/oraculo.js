// Duplo oráculo para o jogo de prévias T1-G x adversário (28/out/2026).
// Parte das prévias já testadas (matriz.js + rodada 2) e alterna melhores respostas:
// a cada iteração, (a) a melhor prévia nossa contra a estratégia mista deles e (b) a melhor deles
// contra a nossa, triando todas as configurações (4 de 6 + par de lead + Mega) com n1 batalhas por
// coluna/linha do suporte. Depois resolve o jogo de novo. Termina quando nenhum lado acha prévia
// nova que ganhe mais de 3 pp, ou após ITER iterações. Confirmação final: célula a célula com n3.
// Uso: node cores/oraculo.js <time> [ITER=3] [n1=12] [nCelula=60] [n3=200] > adv/<time>-oraculo.json
'use strict';
const fs = require('fs');
const {simular} = require('../simular.js');
const [,, T, ITER = 3, N1 = 12, NC = 60, N3 = 200] = process.argv;
const D = process.env.DIR || 'cores/resultados/adv';
const adv = JSON.parse(fs.readFileSync(`${D}/${T}.json`, 'utf8'));
const mat = JSON.parse(fs.readFileSync(`${D}/${T}-matriz.json`, 'utf8'));
const r2 = fs.existsSync(`${D}/${T}-r2.json`) && fs.statSync(`${D}/${T}-r2.json`).size ? JSON.parse(fs.readFileSync(`${D}/${T}-r2.json`, 'utf8')) : null;
const t1g = fs.readFileSync(process.env.TIME || 'times/T1G.txt', 'utf8');
const opp = fs.readFileSync(adv.arquivo, 'utf8');
const MODELO = 'cores/modelo_adversario.json';

const membros = txt => txt.trim().split(/\n\s*\n/).map(b => {
	const [l1] = b.split('\n');
	return {nome: l1.split('@')[0].trim(), mega: /ite( [XYZ])?\s*$/.test(l1)};
});
function configs(mons) {
	const out = [];
	for (let a = 0; a < 6; a++) for (let b = a + 1; b < 6; b++) for (let c = b + 1; c < 6; c++) for (let d = c + 1; d < 6; d++) {
		const q = [a, b, c, d];
		for (let i = 0; i < 4; i++) for (let j = i + 1; j < 4; j++) {
			const ord = [q[i], q[j], ...q.filter(x => x !== q[i] && x !== q[j])];
			const previa = ord.map(x => mons[x].nome), megas = ord.filter(x => mons[x].mega).map(x => mons[x].nome);
			if (megas.length <= 1) out.push({previa, mega: megas.length ? megas : undefined});
			else for (const m of megas) out.push({previa, mega: [m, ...megas.filter(x => x !== m)]});
		}
	}
	return out;
}
const rot = c => c.previa ? c.previa.join('/') + (c.mega ? ' (M ' + c.mega[0] + ')' : '') : 'bot';
const deRot = s => {
	if (s === 'bot') return {};
	const m = s.match(/^(.*?)(?: \(M (.*)\))?$/);
	return {previa: m[1].split('/'), mega: m[2] ? [m[2]] : undefined};
};
let sem = 500;
async function wr(a, b, n) {
	const r = await simular(t1g, opp, {n, nomes: ['T1G', 'OPP'], previaA: a.previa, megaA: a.mega, previaB: b.previa, megaB: b.mega, modeloB: MODELO, semente: sem++});
	return r.stats.vitorias[0] / Math.max(1, r.stats.batalhas);
}
function resolver(M) {
	const R = M.length, C = M[0].length, cr = Array(R).fill(0), cc = Array(C).fill(0), sr = Array(R).fill(0), sc = Array(C).fill(0);
	let i = 0, j = 0; const IT = 30000;
	for (let it = 0; it < IT; it++) {
		cr[i]++; cc[j]++;
		for (let c = 0; c < C; c++) sc[c] += M[i][c];
		for (let r = 0; r < R; r++) sr[r] += M[r][j];
		i = sr.indexOf(Math.max(...sr)); j = sc.indexOf(Math.min(...sc));
	}
	const x = cr.map(v => v / IT), y = cc.map(v => v / IT);
	const valor = x.reduce((s, p, r) => s + p * y.reduce((t, q, c) => t + q * M[r][c], 0), 0);
	return {x, y, valor};
}
(async () => {
	const t0 = Date.now();
	const linhas = mat.linhas.map(deRot), colunas = mat.colunas.map(deRot);
	if (r2) colunas.push({previa: r2.pior.previa, mega: r2.pior.mega});
	const M = [];
	for (const a of linhas) { const row = []; for (const b of colunas) row.push(await wr(a, b, +NC)); M.push(row); }
	const nossas = configs(membros(t1g)), deles = configs(membros(opp));
	const hist = [];
	for (let it = 0; it < +ITER; it++) {
		let s = resolver(M);
		// (a) melhor resposta nossa
		const supC = colunas.map((c, j) => [c, s.y[j]]).filter(([, p]) => p > 0.05);
		let best = null;
		for (const a of nossas) { let v = 0; for (const [c, p] of supC) v += p * await wr(a, c, +N1); if (!best || v > best.v) best = {a, v}; }
		const novaLinha = !linhas.some(l => rot(l) === rot(best.a));
		if (novaLinha) { linhas.push(best.a); const row = []; for (const b of colunas) row.push(await wr(best.a, b, +NC)); M.push(row); }
		s = resolver(M);
		// (b) melhor resposta deles
		const supR = linhas.map((l, i) => [l, s.x[i]]).filter(([, p]) => p > 0.05);
		let pior = null;
		for (const b of deles) { let v = 0; for (const [l, p] of supR) v += p * await wr(l, b, +N1); if (!pior || v < pior.v) pior = {b, v}; }
		const novaCol = !colunas.some(c => rot(c) === rot(pior.b));
		if (novaCol) { colunas.push(pior.b); for (const [i, l] of linhas.entries()) M[i].push(await wr(l, pior.b, +NC)); }
		s = resolver(M);
		hist.push({it, nossaBR: rot(best.a), triagemNossa: +(100 * best.v).toFixed(1), delesBR: rot(pior.b), triagemDeles: +(100 * pior.v).toFixed(1), valor: +(100 * s.valor).toFixed(1)});
		if (!novaLinha && !novaCol) break;
	}
	// confirmação: refaz as células do suporte com n3
	let s = resolver(M);
	const supR = linhas.map((l, i) => i).filter(i => s.x[i] > 0.05), supC = colunas.map((c, j) => j).filter(j => s.y[j] > 0.05);
	const conf = {};
	for (const i of supR) for (const j of supC) conf[`${i},${j}`] = +(100 * await wr(linhas[i], colunas[j], +N3)).toFixed(1);
	const pct = v => +(100 * v).toFixed(1);
	console.log(JSON.stringify({time: T, n: {triagem: +N1, celula: +NC, confirmacao: +N3}, hist,
		linhas: linhas.map(rot), colunas: colunas.map(rot), matriz: M.map(r => r.map(pct)),
		valor: pct(s.valor), nossas: s.x.map(pct), deles: s.y.map(pct), confirmacao: conf, segundos: Math.round((Date.now() - t0) / 1000)}, null, 1));
})();
