// C9M: top 6 + REF antiga do C9; prévia geral nova (top 3 no conjunto novo + referência) contra os 11 cores novos
const fs=require('fs');const {simular}=require('../../simular.js');const {NOVOS,C9M}=require('./lib2.js')
const [,,W,K,N,NG,out]=process.argv;const w=+W,k=+K
const team=fs.readFileSync(__dirname+'/../../cores/T1G-CHARIZARD.txt','utf8')
const S=fs.readFileSync(__dirname+'/screen.jsonl','utf8').trim().split('\n').concat(fs.readFileSync(__dirname+'/screen2.jsonl','utf8').trim().split('\n')).map(JSON.parse)
const ids=NOVOS.map(c=>c.id);const key=r=>r.previa.join()+'|'+r.mega.join()
const c9=S.filter(r=>r.core==='C9M').sort((a,b)=>b.v/b.n-a.v/a.n).slice(0,6).map(r=>({previa:r.previa,mega:r.mega}))
const REF=[['Gallade','Indeedee-F','Garchomp','Milotic'],['Garchomp']];if(!c9.some(p=>key(p)===key({previa:REF[0],mega:REF[1]})))c9.push({previa:REF[0],mega:REF[1],ref:true})
const g={};for(const r of S)if(ids.includes(r.core)){const kk=key(r);(g[kk]=g[kk]||{previa:r.previa,mega:r.mega,v:0,n:0});g[kk].v+=r.v;g[kk].n+=r.n}
const G=Object.values(g).sort((a,b)=>b.v/b.n-a.v/a.n).slice(0,3).map(x=>({previa:x.previa,mega:x.mega,screen:x.v/x.n}))
const GREF={previa:['Charizard','Garchomp','Volcarona','Milotic'],mega:['Charizard'],gref:true};if(!G.some(p=>key(p)===key(GREF)))G.push(GREF)
fs.writeFileSync(__dirname+'/top2.json',JSON.stringify({C9M:c9,GERAL2:G},null,1))
const jobs=[];for(const p of c9)for(const opp of ['fixa','livre'])jobs.push({core:'C9M',...p,opp,n:+N})
for(const p of G)for(const c of NOVOS)for(const opp of (c.cand?['livre']:['fixa','livre']))jobs.push({core:c.id,previa:p.previa,mega:p.mega,opp,geral2:true,gref:!!p.gref,n:+NG})
;(async()=>{for(const jb of jobs.filter((_,x)=>x%k===w)){const c=NOVOS.find(x=>x.id===jb.core)
 const o={n:jb.n,nomes:['A',c.id],previaA:jb.previa,megaA:jb.mega.length?jb.mega:['__nenhuma__'],megaB:c.megaOpp,modeloB:__dirname+'/../../cores/modelo_adversario.json',semente:23}
 if(jb.opp==='fixa')o.previaB=c.previaOpp
 const r=await simular(team,c.text,o);fs.appendFileSync(out,JSON.stringify({...jb,v:r.stats.vitorias[0],n:r.stats.batalhas})+'\n')}
 fs.appendFileSync(out+'.fim',w+'\n')})()
