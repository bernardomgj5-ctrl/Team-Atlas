// Controle das mecânicas confirmadas no projeto (01-MECANICAS), em duas camadas:
//   MOTOR: o Showdown aplica a mecânica numa batalha roteirizada (formato gen9championsvgc2026regmc);
//   BOT:   a estimativa/heurística do simular.js leva a mecânica em conta.
// Uso: node cores/teste-mecanicas.js   (esperado: todas as linhas OK)
'use strict';
const {loadShowdown, makePlayerClass, estimateDamage, bestDamage, speedOf, emArea} = require('../simular.js');
const sim = loadShowdown();
const Player = makePlayerClass(sim.BattlePlayer);
const FMT = 'gen9championsvgc2026regmc';
const T = s => sim.Teams.pack(sim.Teams.import(s).map(x => ({...x, level: 50})));
const mon = (nome, item, hab, nat, evs, golpes) => `${nome}${item ? ' @ ' + item : ''}\nAbility: ${hab}\nEVs: ${evs}\n${nat} Nature\n${golpes.map(g => '- ' + g).join('\n')}`;
const M = {
	ind: mon('Indeedee-F', 'Psychic Seed', 'Psychic Surge', 'Relaxed', '32 HP / 32 Def / 2 SpD', ['Psychic', 'Helping Hand', 'Follow Me', 'Trick Room']),
	gal: mon('Gallade', 'Life Orb', 'Sharpness', 'Adamant', '32 HP / 16 Atk / 10 Def / 2 SpD / 6 Spe', ['Leaf Blade', 'Sacred Sword', 'Psycho Cut', 'Wide Guard']),
	char: mon('Charizard', 'Charizardite Y', 'Blaze', 'Modest', '20 HP / 8 Def / 21 SpA / 17 Spe', ['Heat Wave', 'Weather Ball', 'Ancient Power', 'Protect']),
	charLento: mon('Charizard', 'Charizardite Y', 'Blaze', 'Modest', '30 HP / 14 Def / 1 SpA / 21 SpD', ['Heat Wave', 'Weather Ball', 'Ancient Power', 'Protect']),
	chomp: mon('Garchomp', 'Sitrus Berry', 'Rough Skin', 'Jolly', '2 HP / 32 Atk / 32 Spe', ['Stomping Tantrum', 'Rock Slide', 'Dragon Claw', 'Protect']),
	kingSP: mon('Kingambit', 'Black Glasses', 'Defiant', 'Brave', '32 HP / 32 Atk / 2 SpD', ['Kowtow Cleave', 'Sucker Punch', 'Low Kick', 'Swords Dance']),
	ghol: mon('Gholdengo', 'Life Orb', 'Good as Gold', 'Modest', '27 HP / 25 SpD / 14 Spe', ['Make It Rain', 'Shadow Ball', 'Nasty Plot', 'Protect']),
	gard: mon('Gardevoir', 'Gardevoirite', 'Trace', 'Modest', '28 HP / 17 Def / 10 SpA / 11 Spe', ['Hyper Voice', 'Expanding Force', 'Trick Room', 'Protect']),
	inci: mon('Incineroar', 'Sitrus Berry', 'Intimidate', 'Impish', '30 HP / 10 Def / 26 SpD', ['Fake Out', 'Flare Blitz', 'Throat Chop', 'Parting Shot']),
	venu: mon('Venusaur', 'Focus Sash', 'Chlorophyll', 'Modest', '1 HP / 32 SpA / 1 SpD / 32 Spe', ['Sleep Powder', 'Sludge Bomb', 'Leaf Storm', 'Protect']),
	ttar: mon('Tyranitar', 'Tyranitarite', 'Sand Stream', 'Jolly', '17 HP / 17 Atk / 32 Spe', ['Rock Slide', 'Knock Off', 'Low Kick', 'Protect']),
	raiX: mon('Raichu', 'Raichunite X', 'Lightning Rod', 'Jolly', '24 HP / 1 Atk / 10 Def / 3 SpD / 28 Spe', ['Volt Tackle', 'Volt Switch', 'Fake Out', 'Protect']),
	whim: mon('Whimsicott', 'Focus Sash', 'Prankster', 'Timid', '2 HP / 32 SpA / 32 Spe', ['Moonblast', 'Encore', 'Tailwind', 'Protect']),
	king: mon('Kingambit', 'Chople Berry', 'Defiant', 'Adamant', '32 HP / 25 Atk / 8 Def / 1 SpD', ['Kowtow Cleave', 'Iron Head', 'Sucker Punch', 'Low Kick']),
	arch: mon('Archaludon', 'Leftovers', 'Stamina', 'Bold', '30 HP / 1 Def / 1 SpA / 19 SpD / 15 Spe', ['Dragon Pulse', 'Electro Shot', 'Aura Sphere', 'Protect']),
	snea: mon('Sneasler', 'Psychic Seed', 'Unburden', 'Adamant', '1 HP / 30 Atk / 2 Def / 1 SpD / 32 Spe', ['Close Combat', 'Dire Claw', 'Rock Tomb', 'Protect']),
	peli: mon('Pelipper', 'Damp Rock', 'Drizzle', 'Bold', '32 HP / 10 Def / 17 SpA / 7 SpD', ['Weather Ball', 'Hurricane', 'Helping Hand', 'Wide Guard']),
};
function batalha(a, b) {
	const bt = new sim.Battle({formatid: FMT, seed: [1, 2, 3, 4]});
	bt.setPlayer('p1', {name: 'A', team: T(a.join('\n\n'))});
	bt.setPlayer('p2', {name: 'B', team: T(b.join('\n\n'))});
	bt.makeChoices('team 1234', 'team 1234');
	return bt;
}
const logDe = (bt, de) => bt.log.slice(de).join('\n');
let falhas = 0;
const ok = (camada, nome, cond, obs = '') => { if (!cond) falhas++; console.log(`${cond ? 'OK    ' : 'FALHOU'} ${camada.padEnd(5)} ${nome}${obs ? ' — ' + obs : ''}`); };
const bot = (bt, lado = 0, regras = ['troca', 'custo', 'previa']) => { const pl = Object.create(Player.prototype); pl.bs = {battle: bt}; pl.sideIndex = lado; pl.cfg = {regras}; pl.R = new Set(regras); return pl; };
const valor = (pl, me, ally, golpe) => { const mv = pl.battle.dex.moves.get(golpe); const o = pl.scoreMove(me, ally, mv, mv.target, pl.dangerTo(me), null); return o.length ? Math.max(...o.map(x => x.value)) : null; };

// 1. Psychic Terrain bloqueia Fake Out em alvo no chão e não em Voador
{
	const bt = batalha([M.ind, M.gal, M.char, M.chomp], [M.inci, M.venu, M.king, M.whim]);
	let n = bt.log.length;
	bt.makeChoices('move 3, move 3 1', 'move 1 2, move 4'); // Fake Out no Gallade (chão)
	const l1 = logDe(bt, n);
	ok('MOTOR', 'Psychic Terrain bloqueia Fake Out em alvo no chão', /Psychic Terrain/.test(l1) && !/\|cant\|p1b: Gallade\|flinch/.test(l1) && /-activate\|p1b: Gallade\|move: Psychic Terrain|\[from\] Psychic Terrain|-fail/.test(l1));
	const b2 = batalha([M.ind, M.char, M.gal, M.chomp], [M.inci, M.venu, M.king, M.whim]);
	n = b2.log.length;
	b2.makeChoices('move 3, move 4', 'move 1 2, move 4'); // Fake Out no Charizard (Voador) que usa Protect? não: Charizard usa Protect -> trocar por Heat Wave
	const b3 = batalha([M.ind, M.char, M.gal, M.chomp], [M.inci, M.venu, M.king, M.whim]);
	n = b3.log.length;
	b3.makeChoices('move 2 -2, move 1', 'move 1 2, move 4');
	ok('MOTOR', 'Fake Out acerta Voador sob Psychic Terrain', /\|cant\|p1b: Charizard\|flinch/.test(logDe(b3, n)));
	// bot
	const pl = bot(bt, 1);
	const inc = bt.sides[1].pokemon.find(p => p.species.name === 'Incineroar');
	ok('BOT', 'estimativa zera prioridade em alvo no chão sob Psychic Terrain', estimateDamage(bt, inc, bt.sides[0].active[1], bt.dex.moves.get('fakeout')).avg === 0);
}
// 2. O terreno também bloqueia a prioridade do próprio time (Sucker Punch do Kingambit do T8/T9)
{
	const bt = batalha([M.ind, M.kingSP, M.gal, M.chomp], [M.inci, M.king, M.venu, M.whim]);
	const n = bt.log.length;
	bt.makeChoices('move 3, move 2 1', 'move 2 2, move 1 2');
	const l = logDe(bt, n);
	ok('MOTOR', 'Psychic Terrain bloqueia o Sucker Punch do nosso lado em alvo no chão', /p1b: Kingambit\|Sucker Punch/.test(l) && !/-damage\|p2a: Incineroar/.test(l.split('Sucker Punch')[1].split('|move|')[0]));
}
// 3. Trick Room com TR ativo desfaz o efeito
{
	const bt = batalha([M.ind, M.gal, M.char, M.chomp], [M.king, M.arch, M.venu, M.whim]);
	bt.makeChoices('move 4, move 4', 'move 4 2, move 4');
	const ligado = !!bt.field.pseudoWeather.trickroom;
	bt.makeChoices('move 4, move 4', 'move 4 2, move 4');
	ok('MOTOR', 'Trick Room com TR ativo desfaz o efeito', ligado && !bt.field.pseudoWeather.trickroom);
	const b2 = batalha([M.ind, M.kingSP, M.gal, M.gard], [M.whim, M.arch, M.venu, M.snea]);
	b2.makeChoices('move 4, move 3 2', 'move 4, move 4');
	const lento = valor(bot(b2, 0), b2.sides[0].active[0], b2.sides[0].active[1], 'trickroom');
	const rapido = valor(bot(b2, 1), b2.sides[1].active[0], b2.sides[1].active[1], 'trickroom');
	ok('BOT', 'com TR ativo, o lado mais lento não repete o TR e o lado mais rápido quer desfazer', !!b2.field.pseudoWeather.trickroom && lento < 0 && rapido > 0.9, `lento ${lento}, rápido ${rapido}`);
}
// 4. Follow Me puxa Sleep Powder (alvo único) e não puxa golpe em área
{
	const bt = batalha([M.ind, M.gal, M.char, M.chomp], [M.venu, M.inci, M.king, M.whim]);
	let n = bt.log.length;
	bt.makeChoices('move 3, move 3 1', 'move 1 2, move 4 1');
	const l = logDe(bt, n);
	ok('MOTOR', 'Follow Me puxa Sleep Powder para a Indeedee', /\|move\|p2a: Venusaur\|Sleep Powder\|p1a: Indeedee/.test(l));
	const b2 = batalha([M.ind, M.gal, M.chomp, M.kingSP], [M.char, M.inci, M.king, M.whim]);
	n = b2.log.length;
	b2.makeChoices('move 3, move 4', 'move 1, move 3 2');
	const l2 = logDe(b2, n);
	ok('MOTOR', 'Follow Me não puxa Heat Wave (o Wide Guard bloqueia)', /Heat Wave/.test(l2) && /Wide Guard/.test(l2) && !/-damage\|p1b: Gallade/.test(l2.split('Heat Wave')[1] || ''));
	// bot: Follow Me vale mais com Sleep Powder do outro lado
	const b3 = batalha([M.ind, M.chomp, M.gal, M.char], [M.venu, M.arch, M.king, M.whim]);
	const pl = bot(b3, 0);
	const v = valor(pl, b3.sides[0].active[0], b3.sides[0].active[1], 'followme');
	ok('BOT', 'Follow Me conta o Sleep Powder de alvo único', v >= 0.5, 'valor ' + v);
}
// 5. Sacred Sword ignora boost de Defesa
{
	const bt = batalha([M.ind, M.gal, M.char, M.chomp], [M.arch, M.king, M.venu, M.whim]);
	const gal = bt.sides[0].active[1], arch = bt.sides[1].active[0];
	const ss = bt.dex.moves.get('sacredsword');
	ok('MOTOR', 'Sacred Sword tem ignoreDefensive nos dados do formato', ss.ignoreDefensive === true);
	const semBoost = estimateDamage(bt, gal, arch, ss).avg;
	arch.boosts.def = 2;
	const comBoost = estimateDamage(bt, gal, arch, ss).avg;
	const lb = bt.dex.moves.get('leafblade');
	arch.boosts.def = 0; const l0 = estimateDamage(bt, gal, arch, lb).avg; arch.boosts.def = 2; const l2 = estimateDamage(bt, gal, arch, lb).avg;
	ok('BOT', 'estimativa do Sacred Sword ignora +2 Def (Stamina)', semBoost === comBoost && l2 < l0, `Sacred Sword ${semBoost} → ${comBoost}; Leaf Blade ${l0} → ${l2}`);
}
// 6. Duas Megas de clima no mesmo turno: fica o clima da mais lenta antes da Mega
{
	const b1 = batalha([M.char, M.gal, M.ind, M.chomp], [M.ttar, M.king, M.venu, M.whim]);
	b1.makeChoices('move 4 mega, move 4', 'move 4 mega, move 4 2');
	ok('MOTOR', 'Charizard 137 + Tyranitar 124 megaevoluem juntos: fica a areia', b1.field.weather === 'sandstorm', 'clima: ' + b1.field.weather);
	const b2 = batalha([M.charLento, M.gal, M.ind, M.chomp], [M.ttar, M.king, M.venu, M.whim]);
	b2.makeChoices('move 4 mega, move 4', 'move 4 mega, move 4 2');
	ok('MOTOR', 'Charizard 120 + Tyranitar 124 megaevoluem juntos: fica o sol', b2.field.weather === 'sunnyday', 'clima: ' + b2.field.weather);
}
// 7. Good as Gold bloqueia o Helping Hand aliado
{
	const bt = batalha([M.ind, M.ghol, M.gal, M.chomp], [M.king, M.arch, M.venu, M.whim]);
	const n = bt.log.length;
	bt.makeChoices('move 2 -2, move 2 1', 'move 4 2, move 4');
	const l = logDe(bt, n);
	ok('MOTOR', 'Good as Gold bloqueia o Helping Hand do aliado', /-immune\|p1b: Gholdengo|\[from\] ability: Good as Gold/.test(l) && !/-singleturn\|p1b: Gholdengo\|Helping Hand/.test(l));
	const pl = bot(bt, 0);
	ok('BOT', 'não usa Helping Hand em aliado com Good as Gold', valor(pl, bt.sides[0].active[0], bt.sides[0].active[1], 'helpinghand') === null);
}
// 8. Wide Guard em turnos seguidos não falha; Expanding Force no terreno é golpe em área
{
	const bt = batalha([M.gal, M.ind, M.char, M.chomp], [M.char, M.gard, M.king, M.whim]);
	let n = bt.log.length;
	bt.makeChoices('move 4, move 3', 'move 1, move 4');
	bt.makeChoices('move 4, move 3', 'move 1, move 4');
	const l = logDe(bt, n);
	ok('MOTOR', 'Wide Guard em dois turnos seguidos bloqueia os dois Heat Wave', (l.match(/-activate\|p1[ab]: [A-Za-z-]+\|move: Wide Guard|\|-activate\|p1.*Wide Guard/g) || []).length >= 2 || (l.match(/Wide Guard/g) || []).length >= 4, 'ocorrências de Wide Guard: ' + (l.match(/Wide Guard/g) || []).length);
	const pl = bot(bt, 0);
	const v = valor(pl, bt.sides[0].active[0], bt.sides[0].active[1], 'wideguard');
	ok('BOT', 'Wide Guard continua valendo no turno seguinte com golpe em área em campo', v >= 0.3, 'valor ' + v);
	const gardv = bt.sides[1].active[1];
	ok('BOT', 'Expanding Force conta como golpe em área no Psychic Terrain', bt.field.terrain === 'psychicterrain' && emArea(bt, gardv, bt.dex.moves.get('expandingforce')));
}
// 9. Raichu-Mega-X troca o Psychic Terrain no turno da Mega e o Fake Out passa
{
	const bt = batalha([M.ind, M.gal, M.char, M.chomp], [M.raiX, M.king, M.venu, M.whim]);
	const n = bt.log.length;
	bt.makeChoices('move 3, move 3 1', 'move 3 1 mega, move 2 2');
	const l = logDe(bt, n);
	ok('MOTOR', 'Raichu-Mega-X: Electric Surge troca o terreno e o Fake Out pega a Indeedee', bt.field.terrain === 'electricterrain' && /\|cant\|p1a: Indeedee\|flinch/.test(l), 'terreno: ' + bt.field.terrain);
}
// 10. Tailwind de Prankster vale no mesmo turno
{
	const bt = batalha([M.gal, M.ind, M.char, M.chomp], [M.whim, M.king, M.venu, M.inci]);
	const n = bt.log.length;
	bt.makeChoices('move 2 2, move 1 2', 'move 3, move 1 1');
	const l = logDe(bt, n);
	const iK = l.indexOf('|move|p2b: Kingambit'), iG = l.indexOf('|move|p1a: Gallade');
	ok('MOTOR', 'Tailwind de Prankster: o Kingambit (70) age antes do Gallade (106) no mesmo turno', iK > 0 && iG > 0 && iK < iG);
}
// 11. Focus Sash, Unburden (estimativas do bot)
{
	const bt = batalha([M.char, M.gal, M.ind, M.chomp], [M.venu, M.snea, M.king, M.whim]);
	const ch = bt.sides[0].active[0], ve = bt.sides[1].active[0], sn = bt.sides[1].active[1];
	bt.field.setWeather('sunnyday', ch);
	const e = estimateDamage(bt, ch, ve, bt.dex.moves.get('heatwave'), {spread: true});
	ok('BOT', 'Focus Sash com HP cheio: Heat Wave na Venusaur não conta como KO', e.avg === ve.maxhp - 1, `dano ${e.avg} de ${ve.maxhp}`);
	const antes = speedOf(bt, sn);
	sn.setItem(''); sn.addVolatile('unburden');
	ok('BOT', 'Unburden dobra a Speed estimada da Sneasler', speedOf(bt, sn) === antes * 2, `${antes} → ${speedOf(bt, sn)}`);
}
// 12. Regra "redir" (lado A): Follow Me perde valor quando o redirecionador cai para os golpes de alvo único
{
	const bt = batalha([M.ind, M.gal, M.char, M.chomp], [M.kingSP, M.chomp, M.venu, M.whim]);
	const ind = bt.sides[0].active[0], gal = bt.sides[0].active[1];
	const sem = valor(bot(bt, 0, ['troca', 'custo', 'previa']), ind, gal, 'followme');
	const com = valor(bot(bt, 0, ['troca', 'custo', 'previa', 'redir']), ind, gal, 'followme');
	ok('REGRA', 'redir: Follow Me vale menos contra Kingambit + Garchomp (a Indeedee cai)', com < sem, `${sem.toFixed(2)} → ${com.toFixed(2)}`);
	const b2 = batalha([M.ind, M.gal, M.char, M.chomp], [M.venu, M.whim, M.king, M.inci]);
	const i2 = b2.sides[0].active[0], g2 = b2.sides[0].active[1];
	const s2 = valor(bot(b2, 0, ['troca', 'custo', 'previa']), i2, g2, 'followme');
	const c2 = valor(bot(b2, 0, ['troca', 'custo', 'previa', 'redir']), i2, g2, 'followme');
	ok('REGRA', 'redir: Follow Me fica igual contra Venusaur + Whimsicott (a Indeedee aguenta)', c2 === s2, `${s2.toFixed(2)} → ${c2.toFixed(2)}`);
}

console.log(falhas ? `\n${falhas} FALHA(S)` : '\nCONTROLE DE MECÂNICAS OK');
process.exit(falhas ? 1 : 0);
