# Resume os resultados de cores/adversario.js e cores/matriz.js (28/out/2026).
import json,os,sys
D='/home/claude/cores/resultados-28out/adv'
ts=sys.argv[1:] or ['N1','B6K','C11K','C7S','C8M','C2C','N3','C3L','C6L','C9M','EDU','HOLO','B6C']
for t in ts:
    f=f'{D}/{t}.json'
    if not (os.path.exists(f) and os.path.getsize(f)): continue
    d=json.load(open(f)); p=d['pior']; c=p['confirmacao']; r=d.get('resposta',{})
    print(f"== {t}: 6x6 bot {round(100*d['bot6x6']['wr'],1)} {d['bot6x6']['ic']} | pior deles {'/'.join(p['previa'])} M {p.get('mega') and p['mega'][0]} -> {round(100*c['wr'],1)} {c['ic']} (triagem {p['triagem']}, fase2 {p['fase2']})")
    print(f"   nossa prévia do bot: {'/'.join(c['previaA'])} lead {list(c['leadsA'])} megaA {c['megasA']} | desmaios nossos {c['desmaiosA']} | deles {c['desmaiosB']}")
    if r: print(f"   resposta: {'/'.join(r['previa'])} M {r.get('mega') and r['mega'][0]} -> {r['confirmacao']['wr']} {r['confirmacao']['ic']}")
    m=f'{D}/{t}-matriz.json'
    if os.path.exists(m) and os.path.getsize(m):
        m=json.load(open(m)); print(f"   jogo: puro {m['puro']} | misto {m['misto']['valor']} nossas {m['misto']['nossas']} deles {m['misto']['deles']}")
        for l,row in zip(m['linhas'],m['matriz']): print('     ',l[:50].ljust(50),row)
        print('      colunas:',m['colunas'])
print('\n### Rodada 2 (resposta deles à nossa prévia recomendada)')
for t in ts:
    f=f'{D}/{t}-r2.json'
    if not (os.path.exists(f) and os.path.getsize(f)): continue
    d=json.load(open(f)); p=d['pior']; c=p['confirmacao']
    print(f"{t}: nossa {'/'.join(d['nossa']['previa'])} M {d['nossa'].get('mega')} | vs bot deles {round(100*d['bot6x6']['wr'],1)} {d['bot6x6']['ic']} | vs melhor resposta {'/'.join(p['previa'])} M {p.get('mega') and p['mega'][0]} -> {round(100*c['wr'],1)} {c['ic']}")
