// Roda a T1-G contra os 11 cores em dois modos:
//   atlas: prévia, lead e Mega fixos como no Atlas/playbook
//   bot:   prévia escolhida pelo bot (mesma preferência de Mega)
// Uso: node cores/rodar-cores.js [N=50]
'use strict';
const fs = require('fs');
const path = require('path');
const {simular, report} = require('../simular.js');
const {CORES} = require('./cores.js');

const N = parseInt(process.argv[2] || '50', 10);
const MODELO = process.argv[3] || null;  // caminho do modelo_adversario.json: o core joga com a política aprendida
const t1g = fs.readFileSync(path.join(__dirname, 'T1G.txt'), 'utf8');
const outDir = path.join(__dirname, MODELO ? 'resultados-modelo' : 'resultados');
fs.mkdirSync(outDir, {recursive: true});

(async () => {
	const linhas = [];
	const json = {};
	for (const core of CORES) {
		json[core.id] = {};
		for (const modo of ['atlas', 'bot']) {
			const opts = {n: N, nomes: ['T1G', core.id], log: true, megaA: core.mega, previaB: core.previaOpp, megaB: core.megaOpp, modeloB: MODELO, semente: 7};
			if (modo === 'atlas') opts.previaA = core.previa;
			const r = await simular(t1g, core.text, opts);
			const s = r.stats;
			const wr = 100 * s.vitorias[0] / Math.max(1, s.batalhas);
			const turnos = s.turnos.reduce((a, b) => a + b, 0) / Math.max(1, s.turnos.length);
			const escolhidos = Object.entries(s.previa[0]).sort((a, b) => b[1] - a[1]).map(([k]) => k).join(', ');
			const leads = Object.keys(s.leads[0]).join(' / ');
			linhas.push(`${core.id.padEnd(4)} ${modo.padEnd(5)} ${wr.toFixed(0).padStart(3)}%  ${turnos.toFixed(1)}t  ${escolhidos}  [lead ${leads}]`);
			const {logs, ...rest} = s;
			json[core.id][modo] = rest;
			fs.writeFileSync(path.join(outDir, `${core.id}-${modo}.txt`), report(r) + '\n\n' +
				logs.map((l, i) => `=== Batalha ${i + 1} (${l.vencedor}, ${l.turnos} turnos) ===\n` +
					`Escolhidos: T1G = ${l.prev[0]?.escolhidos.join(', ')}; ${core.id} = ${l.prev[1]?.escolhidos.join(', ')}\n` +
					`Leads: ${l.prev[0]?.leads.join(' + ')} vs ${l.prev[1]?.leads.join(' + ')}\n${l.texto}\n`).join('\n'));
		}
	}
	fs.writeFileSync(path.join(outDir, 'resumo.json'), JSON.stringify(json, null, 2));
	console.log(linhas.join('\n'));
})().catch(e => { console.error('ERRO:', e.message); process.exit(1); });
