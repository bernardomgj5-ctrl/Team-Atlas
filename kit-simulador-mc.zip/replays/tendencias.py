#!/usr/bin/env python3
"""Tendências por espécie, por ameaça (B6, C1–C10) e do nosso lado, a partir de
partidas.jsonl e acoes.csv. Só Reg M-C. Saída: tendencias.json
"""
import csv, json, os, re
from collections import Counter, defaultdict

DIR = os.path.dirname(os.path.abspath(__file__))
GOLPES = json.load(open(os.path.join(DIR, 'golpes.json')))
STONES = {re.sub(r'[^a-z0-9]', '', k.lower()): v for k, v in json.load(open(os.path.join(DIR, 'megastones.json'))).items()}
MIN_N = 8  # amostra mínima para listar uma espécie


def tid(s):
    return re.sub(r'[^a-z0-9]', '', (s or '').lower())


def golpe_info(nome):
    return GOLPES.get(nome, {})


def dano_alvo_unico(nome):
    g = golpe_info(nome)
    return g.get('cat') in ('Physical', 'Special') and g.get('target') in ('normal', 'any', 'adjacentFoe')


partidas = [json.loads(l) for l in open(os.path.join(DIR, 'partidas.jsonl'))]
partidas = [p for p in partidas if 'regmc' in p['formato']]
BOT = re.compile(r'bot', re.I)
excluidas_bot = [p['id'] for p in partidas if not p['nosso'] and any(BOT.search(n) for n in p['jogadores'].values())]
partidas = [p for p in partidas if p['id'] not in set(excluidas_bot)]
# peso por jogador: cada jogador soma 1 no total do grupo, não importa quantas partidas tenha
_jogos_por_jogador = Counter()
for _p in partidas:
    for _s in ('p1', 'p2'):
        _g = ('nosso' if _s == _p['nosso'] else 'adv_nosso') if _p['nosso'] else 'publico'
        _jogos_por_jogador[(_g, _p['jogadores'].get(_s, '?'))] += 1


SEM_PESO = bool(os.environ.get('SEM_PESO'))


def peso(p, s, g):
    if SEM_PESO:
        return 1.0
    return 1.0 / _jogos_por_jogador[(g, p['jogadores'].get(s, '?'))]
acoes = defaultdict(list)
for r in csv.DictReader(open(os.path.join(DIR, 'acoes.csv'))):
    r['turno'] = int(r['turno'])
    for k in ('area', 'protect', 'primeiro_turno'):
        r[k] = int(r[k] or 0)
    acoes[r['id']].append(r)


def lados(p):
    """(lado, grupo): grupo = 'nosso' | 'adv_nosso' (adversário em partida nossa) | 'publico'"""
    for s in ('p1', 'p2'):
        if p['nosso']:
            yield s, ('nosso' if s == p['nosso'] else 'adv_nosso')
        else:
            yield s, 'publico'


# ---------------------------------------------------------------- ameaças
def sets_de(p, s):
    if p['sets'][s]:
        return [{'sp': re.sub(r'-Mega.*$', '', x['species']), 'item': tid(x['item']), 'moves': x['moves'],
                 'ab': tid(x['ability'])} for x in p['sets'][s]]
    return [{'sp': sp, 'item': '', 'moves': [], 'ab': ''} for sp in p['time'][s]]


def tem(sets, sp, pedra=None):
    for x in sets:
        if x['sp'] == sp and (pedra is None or x['item'] == pedra):
            return True
    return False


def golpe_no_time(sets, golpe):
    return any(tid(golpe) in [tid(m) for m in x['moves']] for x in sets)


def ameacas(sets):
    out = []
    b6 = sum(tem(sets, s) for s in ['Whimsicott', 'Basculegion', 'Floette-Eternal', 'Garchomp', 'Kingambit', 'Charizard'])
    if b6 >= 4:
        out.append('B6')
    if tem(sets, 'Garchomp', 'garchompitez') and tem(sets, 'Raichu', 'raichunitey') and tem(sets, 'Volcarona'):
        out.append('C1')
    # C2 = sol com Chlorophyll sem chuva; C11 (03-META, 08/out) = Charizard-Y com Pelipper (sol + chuva)
    if tem(sets, 'Charizard', 'charizarditey') and tem(sets, 'Pelipper') and \
            (tem(sets, 'Venusaur') or tem(sets, 'Archaludon')):
        out.append('C11')
    elif tem(sets, 'Charizard', 'charizarditey') and tem(sets, 'Venusaur'):
        out.append('C2')
    if tem(sets, 'Torkoal') and golpe_no_time(sets, 'Trick Room'):
        out.append('C3')
    if tem(sets, 'Swampert', 'swampertite') and tem(sets, 'Pelipper'):
        out.append('C4')
    if tem(sets, 'Golisopod', 'golisopite') and tem(sets, 'Politoed'):
        out.append('C5')
    if (tem(sets, 'Floette-Eternal', 'floettite') or tem(sets, 'Salamence', 'salamencite')) and \
            sum(tem(sets, s) for s in ['Basculegion', 'Kingambit', 'Sneasler']) >= 2:
        out.append('C6')
    if tem(sets, 'Raichu', 'raichunitey') and tem(sets, 'Staraptor', 'staraptite'):
        out.append('C7')
    if tem(sets, 'Tyranitar', 'tyranitarite') and tem(sets, 'Excadrill'):
        out.append('C8')
    if tem(sets, 'Gengar', 'gengarite') and golpe_no_time(sets, 'Perish Song'):
        out.append('C9')
    if tem(sets, 'Metagross', 'metagrossite') and any(x['ab'] == 'psychicsurge' for x in sets):
        out.append('C10')
    return out


def pct(a, b):
    return round(100 * a / b, 1) if b else None


# ---------------------------------------------------------------- por espécie
def stats_especies(grupos, rotulo=None):
    E = defaultdict(lambda: Counter())
    t1 = defaultdict(Counter)        # golpes no T1 quando lidera
    golpes = defaultdict(Counter)    # golpes usados em geral
    fake_alvo = defaultdict(Counter)
    mega_turno = defaultdict(Counter)
    jogadores = defaultdict(set)
    for p in partidas:
        if rotulo and p.get('rotulo') != rotulo:
            continue
        A = acoes[p['id']]
        for s, g in lados(p):
            if g not in grupos:
                continue
            sets = {x['sp']: x for x in sets_de(p, s)}
            nome = p['jogadores'].get(s, '?')
            w = peso(p, s, g)
            for sp in set(p['time'][s]):
                E[sp]['n_raw'] += 1
                E[sp]['no_time'] += w
                jogadores[sp].add(nome)
                if sp in p['levados'][s]:
                    E[sp]['levado'] += w
                if sp in p['leads'][s]:
                    E[sp]['lead'] += w
                st = sets.get(sp, {})
                if st.get('item') in STONES and sp in p['levados'][s]:
                    E[sp]['com_pedra_levado'] += w
                    m = p['mega'][s]
                    if m and m['especie'] == sp:
                        E[sp]['mega'] += w
                        mega_turno[sp][m['turno']] += w
                if any(tid(mv) == 'fakeout' for mv in st.get('moves', [])) and sp in p['leads'][s]:
                    E[sp]['lead_com_fakeout'] += w
            for a in A:
                if a['lado'] != s or a['tipo'] != 'golpe' or a.get('travado') == '1' or a.get('carga') == '1':
                    continue
                sp = a['especie']
                E[sp]['acoes'] += w
                golpes[sp][a['golpe']] += w
                E[sp]['protect'] += a['protect'] * w
                if a['turno'] == 1 and sp in p['leads'][s] and a['primeiro_turno']:
                    t1[sp][a['golpe']] += w
                    E[sp]['acoes_t1'] += w
                    if a['golpe'] == 'Fake Out':
                        E[sp]['fakeout_t1'] += w
                        fake_alvo[sp][a['alvo_especie']] += w
            for a in A:
                if a['lado'] == s and a['tipo'] == 'troca' and a['golpe'] == 'voluntaria':
                    E[a['especie']]['entrou_por_troca_vol'] += w
                    if a['alvo_especie']:
                        E[a['alvo_especie']]['saiu_por_troca_vol'] += w
    out = {}
    for sp, c in E.items():
        if c['n_raw'] < MIN_N or (len(jogadores[sp]) < 3 and 'nosso' not in grupos):
            continue
        out[sp] = {
            'n_times': c['n_raw'], 'n_jogadores': len(jogadores[sp]),
            'levado_pct': pct(c['levado'], c['no_time']),
            'lead_pct_quando_levado': pct(c['lead'], c['levado']),
            'mega_pct_quando_levado_com_pedra': pct(c['mega'], c['com_pedra_levado']),
            'mega_t1_pct': pct(mega_turno[sp].get(1, 0), sum(mega_turno[sp].values())),
            'protect_pct_acoes': pct(c['protect'], c['acoes']),
            't1_como_lead': [(g, pct(n, c['acoes_t1'])) for g, n in t1[sp].most_common(5)],
            'fakeout_t1_pct': pct(c['fakeout_t1'], c['lead_com_fakeout']),
            'fakeout_alvos': [(a, pct(n, sum(fake_alvo[sp].values()))) for a, n in fake_alvo[sp].most_common(5)],
            'saidas_voluntarias_por_jogo_levado': round(c['saiu_por_troca_vol'] / c['levado'], 2) if c['levado'] else None,
            'golpes_top': [(g, pct(n, c['acoes'])) for g, n in golpes[sp].most_common(6)],
        }
    return out


# ---------------------------------------------------------------- por ameaça
def stats_ameacas():
    R = {}
    for p in partidas:
        for s, g in lados(p):
            if g == 'nosso':
                continue
            w = peso(p, s, g)
            for amz in ameacas(sets_de(p, s)):
                r = R.setdefault(amz, {'jogos_brutos': 0, 'jogos': 0, 'jogadores': set(), 'vitorias': 0, 'jogos_publicos': 0,
                                       'contra_nos': Counter(), 'levados': Counter(), 'leads': Counter(),
                                       'mega': Counter(), 't1': Counter(), 'n_t1': 0})
                r['jogos'] += w
                r['jogos_brutos'] += 1
                r['jogadores'].add(p['jogadores'].get(s, '?'))
                if g == 'publico':
                    r['jogos_publicos'] += w
                    if p['vencedor'] == s:
                        r['vitorias'] += w
                else:
                    r['contra_nos'][p.get('rotulo', '?') + (' V' if p['vencedor'] == p['nosso'] else ' D')] += 1
                for sp in p['levados'][s]:
                    r['levados'][sp] += w
                r['leads'][' + '.join(sorted(p['leads'][s]))] += w
                r['mega'][p['mega'][s]['especie'] if p['mega'][s] else 'nenhuma'] += w
                for a in acoes[p['id']]:
                    if a['lado'] == s and a['turno'] == 1 and a['tipo'] == 'golpe' and a['especie'] in p['leads'][s] and a['primeiro_turno']:
                        r['t1'][f"{a['especie']}: {a['golpe']}"] += w
                        r['n_t1'] += w
    out = {}
    for k in sorted(R, key=lambda x: (x[0], int(x[1:]) if x[1:].isdigit() else 0)):
        r = R[k]
        n = r['jogos']
        out[k] = {
            'jogos': r['jogos_brutos'], 'peso_efetivo': round(n, 1), 'jogadores': len(r['jogadores']),
            'vitoria_pct_publico': pct(r['vitorias'], r['jogos_publicos']), 'jogos_publicos_peso': round(r['jogos_publicos'], 1),
            'contra_nos': dict(r['contra_nos']),
            'levados': [(sp, pct(c, n)) for sp, c in r['levados'].most_common(8)],
            'leads': [(l, pct(c, n)) for l, c in r['leads'].most_common(5)],
            'mega': [(m, pct(c, n)) for m, c in r['mega'].most_common()],
            't1': [(x, pct(c, r['n_t1'])) for x, c in r['t1'].most_common(8)],
        }
    return out


# ---------------------------------------------------------------- foco e trocas por grupo
def stats_lado(grupo):
    foco_turnos = foco_mesmo = 0
    protect_seguido_tent = protect_seguido = 0
    trocas_vol = turnos = jogos = 0
    for p in partidas:
        A = acoes[p['id']]
        for s, g in lados(p):
            if g != grupo:
                continue
            jogos += 1
            turnos += p['turnos']
            por_turno = defaultdict(list)
            ultimo = {}
            for a in A:
                if a['lado'] != s:
                    continue
                if a['tipo'] == 'troca' and a['golpe'] == 'voluntaria':
                    trocas_vol += 1
                if a['tipo'] == 'golpe' and a.get('travado') != '1':
                    por_turno[a['turno']].append(a)
                    chave = (a['slot'], a['especie'])
                    if a['protect']:
                        if ultimo.get(chave) == a['turno'] - 1:
                            protect_seguido += 1
                        ultimo[chave] = a['turno']
            for t, lst in por_turno.items():
                ofens = [a for a in lst if dano_alvo_unico(a['golpe']) and a['alvo_lado'] == 'oponente']
                if len(ofens) == 2:
                    foco_turnos += 1
                    if ofens[0]['alvo_especie'] == ofens[1]['alvo_especie']:
                        foco_mesmo += 1
    return {'jogos': jogos, 'turnos_medios': round(turnos / jogos, 1) if jogos else None,
            'foco_mesmo_alvo_pct': pct(foco_mesmo, foco_turnos), 'turnos_com_dois_ataques_unicos': foco_turnos,
            'trocas_voluntarias_por_jogo': round(trocas_vol / jogos, 2) if jogos else None,
            'protect_seguido_por_jogo': round(protect_seguido / jogos, 2) if jogos else None}


# ---------------------------------------------------------------- nosso lado por time
def stats_nossos():
    out = {}
    for rot in sorted(set(p.get('rotulo', '') for p in partidas if p['nosso'])):
        ps = [p for p in partidas if p['nosso'] and p.get('rotulo') == rot]
        leads = Counter(); lead_v = Counter(); mega = Counter()
        for p in ps:
            s = p['nosso']
            l = ' + '.join(sorted(p['leads'][s]))
            leads[l] += 1
            if p['vencedor'] == s:
                lead_v[l] += 1
            mega[(p['mega'][s]['especie'] + f" T{p['mega'][s]['turno']}") if p['mega'][s] else 'nenhuma'] += 1
        out[rot] = {'jogos': len(ps), 'vitorias': sum(p['vencedor'] == p['nosso'] for p in ps),
                    'leads': [(l, c, lead_v[l]) for l, c in leads.most_common()],
                    'mega': mega.most_common()}
    return out


res = {
    'excluidas_bot': len(excluidas_bot),
    'amostra': {
        'partidas_mc': len(partidas),
        'publicas': sum(1 for p in partidas if not p['nosso']),
        'nossas': sum(1 for p in partidas if p['nosso']),
        'jogadores_publicos': len({p['jogadores'][s] for p in partidas if not p['nosso'] for s in ('p1', 'p2')}),
        'rating_min_publico': min((p['rating'] for p in partidas if not p['nosso']), default=None),
        'rating_mediano_publico': sorted(p['rating'] for p in partidas if not p['nosso'])[len([1 for p in partidas if not p['nosso']]) // 2] if any(not p['nosso'] for p in partidas) else None,
    },
    'especies_publico': stats_especies({'publico'}),
    'especies_adv_nossos': stats_especies({'adv_nosso'}),
    'especies_nosso': stats_especies({'nosso'}),
    'especies_nosso_t1g': stats_especies({'nosso'}, 'T1G'),
    'especies_nosso_t8': stats_especies({'nosso'}, 'T8'),
    'ameacas': stats_ameacas(),
    'lado': {g: stats_lado(g) for g in ('publico', 'adv_nosso', 'nosso')},
    'nossos_times': stats_nossos(),
}
saida = 'tendencias_por_partida.json' if SEM_PESO else 'tendencias.json'
json.dump(res, open(os.path.join(DIR, saida), 'w'), ensure_ascii=False, indent=1)
print(json.dumps(res['amostra'], ensure_ascii=False))
print(json.dumps(res['lado'], ensure_ascii=False))
