// Confirmação: top-6 de cada core + prévia da §10.3, N maior, semente nova, prévia do adversário fixa e livre
const fs=require('fs');const {simular}=require('../../simular.js');const {TODOS,CORES}=require('./lib.js')
const [,,W,K,N,NG,out]=process.argv;const w=+W,k=+K
const team=fs.readFileSync(__dirname+'/../../cores/T1G-CHARIZARD.txt','utf8');const top=JSON.parse(fs.readFileSync(__dirname+'/top.json'))
const REF={'B6':[['Indeedee-F','Gallade','Charizard','Volcarona'],['Charizard']],'C1':[['Gallade','Garchomp','Volcarona','Milotic'],['Garchomp']],'C2':[['Gallade','Indeedee-F','Charizard','Milotic'],['Charizard']],'C3':[['Charizard','Gallade','Garchomp','Milotic'],['Garchomp']],'C4':[['Charizard','Garchomp','Gallade','Milotic'],['Charizard']],'C5':[['Charizard','Milotic','Garchomp','Volcarona'],['Charizard']],'C6':[['Volcarona','Milotic','Charizard','Gallade'],['Charizard']],'C7':[['Garchomp','Indeedee-F','Charizard','Milotic'],['Charizard']],'C8':[['Gallade','Garchomp','Charizard','Milotic'],['Charizard']],'C9':[['Gallade','Indeedee-F','Garchomp','Milotic'],['Garchomp']],'C10':[['Charizard','Garchomp','Volcarona','Milotic'],['Charizard']]}
const jobs=[]
for(const c of TODOS){const list=[...top[c.id]];const ref=REF[c.id];if(ref&&!list.some(p=>p.previa.join()===ref[0].join()&&p.mega.join()===ref[1].join()))list.push({previa:ref[0],mega:ref[1],ref:true})
 for(const p of list)for(const opp of (c.cand?['livre']:['fixa','livre']))jobs.push({core:c.id,...p,opp,n:+N})}
for(const p of top.GERAL)for(const c of CORES)for(const opp of ['fixa','livre'])jobs.push({core:c.id,previa:p.previa,mega:p.mega,opp,geral:true,n:+NG})
const GREF=[['Charizard','Garchomp','Volcarona','Milotic'],['Charizard']]
if(!top.GERAL.some(p=>p.previa.join()===GREF[0].join()&&p.mega.join()===GREF[1].join()))for(const c of CORES)for(const opp of ['fixa','livre'])jobs.push({core:c.id,previa:GREF[0],mega:GREF[1],opp,geral:true,gref:true,n:+NG})
const mine=jobs.filter((_,x)=>x%k===w)
;(async()=>{for(const jb of mine){const c=TODOS.find(x=>x.id===jb.core)
 const o={n:jb.n,nomes:['A',c.id],previaA:jb.previa,megaA:jb.mega.length?jb.mega:['__nenhuma__'],megaB:c.megaOpp,modeloB:__dirname+'/../../cores/modelo_adversario.json',semente:23}
 if(jb.opp==='fixa')o.previaB=c.previaOpp
 const r=await simular(team,c.text,o);fs.appendFileSync(out,JSON.stringify({...jb,v:r.stats.vitorias[0],n:r.stats.batalhas})+'\n')}
 fs.appendFileSync(out+'.fim',w+'\n')})()
