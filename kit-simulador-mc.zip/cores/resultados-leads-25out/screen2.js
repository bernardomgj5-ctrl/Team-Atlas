// varredura só do C9M (mesmo método do screen.js)
const fs=require('fs');const {simular}=require('../../simular.js');const {C9M}=require('./lib2.js')
const [,,W,K,N,out]=process.argv;const w=+W,k=+K
const team=fs.readFileSync(__dirname+'/../../cores/T1G-CHARIZARD.txt','utf8')
const MON=['Charizard','Gallade','Garchomp','Indeedee-F','Volcarona','Milotic'];const jobs=[]
for(let i=0;i<6;i++)for(let j=i+1;j<6;j++){const rest=MON.filter((_,x)=>x!==i&&x!==j)
 for(let a=0;a<4;a++)for(let b=a+1;b<4;b++){const four=[MON[i],MON[j],rest[a],rest[b]]
  const hasZ=four.includes('Charizard'),hasG=four.includes('Garchomp')
  const megas=hasZ&&hasG?[['Charizard'],['Garchomp']]:hasZ?[['Charizard']]:hasG?[['Garchomp']]:[[]]
  for(const m of megas)jobs.push({core:'C9M',previa:four,mega:m})}}
;(async()=>{for(const jb of jobs.filter((_,x)=>x%k===w)){
 const r=await simular(team,C9M.text,{n:+N,nomes:['A','C9M'],previaA:jb.previa,megaA:jb.mega.length?jb.mega:['__nenhuma__'],previaB:C9M.previaOpp,megaB:C9M.megaOpp,modeloB:__dirname+'/../../cores/modelo_adversario.json',semente:11})
 fs.appendFileSync(out,JSON.stringify({...jb,v:r.stats.vitorias[0],n:r.stats.batalhas})+'\n')}
 fs.appendFileSync(out+'.fim',w+'\n')})()
