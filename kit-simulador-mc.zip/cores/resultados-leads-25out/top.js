// top-6 por core + 3 prévias gerais (média nos 11 cores oficiais)
const fs=require('fs');const {CORES}=require('./lib.js');const L=fs.readFileSync(process.argv[2],'utf8').trim().split('\n').map(JSON.parse)
const by={};for(const r of L)(by[r.core]=by[r.core]||[]).push(r);const top={}
for(const c of Object.keys(by))top[c]=by[c].sort((a,b)=>b.v/b.n-a.v/a.n).slice(0,6).map(r=>({previa:r.previa,mega:r.mega}))
const key=r=>r.previa.join()+'|'+r.mega.join();const g={}
for(const r of L)if(CORES.some(c=>c.id===r.core)){const k=key(r);(g[k]=g[k]||{previa:r.previa,mega:r.mega,v:0,n:0});g[k].v+=r.v;g[k].n+=r.n}
top.GERAL=Object.values(g).sort((a,b)=>b.v/b.n-a.v/a.n).slice(0,3).map(x=>({previa:x.previa,mega:x.mega,screen:x.v/x.n}))
fs.writeFileSync(process.argv[3],JSON.stringify(top,null,1))
