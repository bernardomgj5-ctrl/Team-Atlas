// Runner compacto (modo teste econômico): um time contra os cores de cores.js, uma linha por core.
// Uso: node cores/rodar.js <time.txt> [N=100] [opções]
//   --cores B6,C10        só estes cores (padrão: os 8 ativos)
//   --variantes           inclui B6-Bascu e C10-Floette
//   --regras-a r1,r2      regras do nosso lado (padrão: REGRAS_PADRAO_A do simular.js)
//   --regras-b r1,r2      regras do lado deles (padrão: REGRAS_PADRAO)
//   --previa A,B,C,D      prévia fixa do nosso lado (os dois primeiros lideram); --mega X
//   --semente N           semente (padrão 7); a mesma semente repete a rodada inteira
//   --json arquivo        grava o resultado completo
// A prévia e a Mega dos dois lados ficam com o bot quando não são fixadas. Saída: taxa de vitória
// com IC95 (Wilson) por core, lead e Mega mais usados do nosso lado e o total.
'use strict';
const fs = require('fs');
const path = require('path');
const {simular} = require('../simular.js');
const {CORES, CORES_VARIANTES} = require('./cores.js');
const argv = process.argv.slice(2);
const opt = k => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : undefined; };
const L = s => (s ? s.split(',').map(x => x.trim()).filter(Boolean) : undefined);
const pos = argv.filter((a, i) => !a.startsWith('--') && !(i > 0 && argv[i - 1].startsWith('--') && argv[i - 1] !== '--variantes'));
const arq = pos[0], N = +(pos[1] || 100);
if (!arq) { console.log('uso: node cores/rodar.js <time.txt> [N] [--cores ...] [--variantes] [--regras-a ...] [--regras-b ...] [--previa ...] [--mega ...] [--semente N] [--json arq]'); process.exit(1); }
const wilson = (k, n) => { const z = 1.96, p = k / n, d = 1 + z * z / n, c = p + z * z / (2 * n), m = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)); return [(c - m) / d, (c + m) / d]; };
const pct = x => (100 * x).toFixed(0);
const topo = o => { const e = Object.entries(o || {}).sort((a, b) => b[1] - a[1])[0]; return e ? `${e[0]} ${pct(e[1] / N)}%` : '-'; };
(async () => {
	const time = fs.readFileSync(arq, 'utf8');
	let lista = argv.includes('--variantes') ? [...CORES, ...CORES_VARIANTES] : CORES;
	const so = L(opt('--cores'));
	if (so) lista = [...CORES, ...CORES_VARIANTES].filter(c => so.includes(c.id));
	const res = {time: path.basename(arq), n: N, semente: +(opt('--semente') || 7), cores: {}};
	let v = 0, n = 0, fb = 0;
	for (const c of lista) {
		const r = await simular(time, c.text, {n: N, nomes: ['A', c.id], previaA: L(opt('--previa')), megaA: L(opt('--mega')), megaB: c.megaOpp,
			modeloB: path.join(__dirname, 'modelo_adversario.json'), semente: res.semente, regrasA: L(opt('--regras-a')), regrasB: L(opt('--regras-b'))});
		const s = r.stats, k = s.vitorias[0], [lo, hi] = wilson(k, s.batalhas);
		v += k; n += s.batalhas; fb += s.fallbacks || 0;
		res.cores[c.id] = {v: k, n: s.batalhas, ic: [+pct(lo), +pct(hi)], lead: s.leads[0], mega: s.megas[0]};
		console.log(`${c.id.padEnd(11)} ${pct(k / s.batalhas).padStart(3)}% [${pct(lo)}–${pct(hi)}]  lead ${topo(s.leads[0])} · Mega ${topo(s.megas[0])}`);
	}
	const [lo, hi] = wilson(v, n);
	res.total = {v, n, wr: +(100 * v / n).toFixed(1), fallbacks: fb};
	console.log(`TOTAL       ${(100 * v / n).toFixed(1)}% [${(100 * lo).toFixed(1)}–${(100 * hi).toFixed(1)}] em ${n} batalhas${fb ? ` · ${fb} escolhas inválidas` : ''}`);
	if (opt('--json')) fs.writeFileSync(opt('--json'), JSON.stringify(res, null, 1));
})();
