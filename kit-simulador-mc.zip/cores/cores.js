// Cores de referência para simulação (revisão de 28/out/2026: só arquétipos com uso em Brisbane,
// Nice e Puebla ou na base /teams/ de outubro; ver 03-META §3-A-1).
// Cada core usa a lista real de um jogador (arquivo em cores/candidatos/). SP, nature, item e golpes
// vêm da base /teams/ do champions-multicalc (commit 166578c) quando a lista está lá; senão, da fonte indicada em `fonte`.
// A prévia e a Mega dos dois lados ficam com o bot (o modelo do adversário escolhe 4, leads e Mega);
// megaOpp só onde o core tem uma Mega Stone só.
'use strict';
const fs = require('fs');
const path = require('path');
const lista = id => fs.readFileSync(path.join(__dirname, 'candidatos', id + '.txt'), 'utf8');

const CORES = [
	{id: 'B6', nome: 'B6 Charizard-Y + Froslass-Mega + Sneasler + Kingambit + Whimsicott + Garchomp',
		fonte: 'Kyle Livinghouse, Puebla 1º (paste do Cybertron; Garchomp com Dragon Claw da gameplay)', arquivo: 'B6K'},
	{id: 'C2', nome: 'C2 Sol com Chlorophyll (Charizard-Y/Venusaur/Sylveon/Garchomp Scarf/Incineroar/Toxapex)',
		fonte: 'Paul Chua, Louisville 9º (base /teams/); mesma lista em Puebla 17º, 21º e 38º', arquivo: 'C2C'},
	{id: 'C3', nome: 'C3 TR com sol (Torkoal/Farigiraf/Garchomp-Z/Incineroar/Sneasler/Sylveon)',
		fonte: 'Sebastian Li, Frankfurt 2º (base /teams/); mesmos seis de Méndez, Puebla 18º', arquivo: 'C3L'},
	{id: 'C5', nome: 'C5 Delphox-Mega + Floette-Mega + Incineroar + Sneasler + Sinistcha + Kingambit',
		fonte: 'mattia_vinti, Nice 50º (base /teams/); lista de Brisbane 10º e Puebla 11º', arquivo: 'N3'},
	{id: 'C6', nome: 'C6 Floette-Mega/Salamence-Mega + Basculegion + Kingambit + Sneasler + Rillaboom',
		fonte: 'Ryan Loseto, Louisville 5º (base /teams/); Sato Brisbane 2º, Rolón Puebla 16º', arquivo: 'C6L'},
	{id: 'C7', nome: 'C7 Raichu-Y + Staraptor-Mega + Arcanine-H + Gholdengo + Primarina + Rillaboom',
		fonte: 'schianchi_luca, Nice 23º (base /teams/); mesmos seis de Navarro, Puebla 2º', arquivo: 'C7S'},
	{id: 'C8', nome: 'C8 Areia com Staraptor-Mega + Tyranitar-Mega + Excadrill + Gholdengo + Milotic + Sinistcha',
		fonte: 'composição de Sanvito (Nice 3º) e Mosca (Puebla 3º); sets = spread mais comum de cada espécie na base (lista montada)', arquivo: 'C8M'},
	{id: 'C9', nome: 'C9 Perish Trap (Gengar-Mega + Incineroar + Rillaboom + Kommo-o)',
		fonte: 'Víctor Medina, VR Oct #1 10º e #2 12º; SP pela convenção do pool', arquivo: 'C9M', megaOpp: ['Gengar']},
	{id: 'C10', nome: 'C10 Chuva com Golisopod-Mega + Raichu-Mega-X + Pelipper + Archaludon + Basculegion-F + Sneasler',
		fonte: 'euphitc, Louisville 37º (base /teams/); mesmos seis do 1º e 4º de Nice e de 5 do top 48 de Puebla', arquivo: 'N1'},
	{id: 'C11', nome: 'C11 Sol + chuva (Charizard-Y/Garchomp-Z/Venusaur/Pelipper/Archaludon/Grimmsnarl)',
		fonte: 'Kiran Singh, VR Oct #2 1º e Brisbane 1º (base /teams/); Puebla 7º, 15º, 24º', arquivo: 'C11K'},
].map(c => ({...c, text: lista(c.arquivo)}));

// Variantes testadas à parte
const CORES_VARIANTES = [
	{id: 'B6-Bascu', nome: 'B6 com Basculegion no lugar da Froslass', fonte: 'Cary D’Ortona, Louisville 10º; mesmos seis de Rodríguez, Puebla 5º', arquivo: 'B6C'},
	{id: 'C7-Sneasler', nome: 'Raichu-Y + Blaziken-Mega + Sneasler + Kingambit + Primarina + Rillaboom', fonte: 'composição de Holowiak, Puebla 4º; sets = spread mais comum de cada espécie na base (lista montada); família com Hernández 13º e Galindo 44º em Puebla, Ishaque 6º em Baltimore', arquivo: 'HOLO'},
	{id: 'C10-Floette', nome: 'C10 com Floette-Mega no lugar da Raichu-X', fonte: 'DitzyDoes, Louisville 39º', arquivo: 'N1F'},
].map(c => ({...c, text: lista(c.arquivo)}));

// Fora da lista de 28/out por falta de uso recente (zero no top 48 de Puebla); voltam se reaparecerem.
const CORES_ANTIGOS = ['C1 Rios/Kelsch (Garchomp-Z + Raichu-Y + Volcarona + Fake Out duplo)',
	'C4 Chuva com Swampert-Mega + Pelipper'];

module.exports = {CORES, CORES_VARIANTES, CORES_ANTIGOS};
