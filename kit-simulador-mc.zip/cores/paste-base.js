// Exporta um time da base /teams/ do champions-multicalc no formato Showdown.
// uso: node cores/paste-base.js <trecho do jogador ou pasteId> [--list]
const fs=require('fs');const all=JSON.parse(fs.readFileSync(process.env.HOME+'/.champions-multicalc/teams.json','utf8'))['M-C'];
const q=process.argv[2].toLowerCase();
const hit=all.filter(t=>t.hasSps&&t.sets&&((t.player||'').toLowerCase().includes(q)||(t.pasteId||'').toLowerCase()===q));
const K={hp:'HP',atk:'Atk',def:'Def',spa:'SpA',spd:'SpD',spe:'Spe'};
const base=n=>{const b=n.replace(/-Mega(-[XYZ])?$/,'');return b==='Floette'?'Floette-Eternal':b;};
if(process.argv[3]==='--list'){for(const t of hit)console.log(t.date,t.event||'-',t.placement||'',t.player,t.pasteId,t.members.map(m=>m.name).join(','));process.exit();}
const t=hit[0]; if(!t){console.error('nada');process.exit(1);}
console.error(`# ${t.date} ${t.event||''} ${t.placement||''} ${t.player} pokepast.es/${t.pasteId}`);
t.members.forEach((m,i)=>{const s={...m,...t.sets[i]};const ab=s.ability;
 const ev=Object.entries(s.sps).filter(([k,v])=>v).map(([k,v])=>`${v} ${K[k]}`).join(' / ');
 console.log(`${base(s.name)} @ ${s.item}\nAbility: ${ab}\nEVs: ${ev}\n${s.nature} Nature\n${(s.moves||[]).map(x=>'- '+x).join('\n')}\n`);});
