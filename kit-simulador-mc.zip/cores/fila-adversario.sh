#!/bin/bash
# Fila de times para cores/adversario.js; cada worker pega o próximo time livre (trava por mkdir).
cd /home/claude
OUT=cores/resultados-28out/adv; mkdir -p $OUT
for t in "$@"; do
  mkdir $OUT/$t.lock 2>/dev/null || continue
  node cores/adversario.js cores/candidatos/$t.txt $t 20 150 600 10 --resposta > $OUT/$t.json 2> $OUT/$t.err
done
