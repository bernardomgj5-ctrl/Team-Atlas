// Pontua cada decisão de decisoes_eval.jsonl com a heurística do simular.js.
// Saída: heur.jsonl  {idx, valores: {golpe: valor}}
'use strict';
const fs = require('fs');
const path = require('path');
const {makePlayerClass, loadShowdown} = require('/home/claude/simular.js');
const sim = loadShowdown('/home/claude/pokemon-showdown');
const {Battle, Teams} = sim;
const Player = makePlayerClass(sim.BattlePlayer);
const DIR = __dirname;
const FORMAT = 'gen9championsvgc2026regmc';

const toID = s => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
const WEATHER = {sunnyday: 'sunnyday', raindance: 'raindance', sandstorm: 'sandstorm', snowscape: 'snowscape', snow: 'snowscape',
	desolateland: 'desolateland', primordialsea: 'primordialsea'};
const TERRAIN = {psychicterrain: 'psychicterrain', grassyterrain: 'grassyterrain', electricterrain: 'electricterrain', mistyterrain: 'mistyterrain'};

// SP pela convenção do projeto: nature ofensiva -> 32 no ataque e 32 Spe; Speed reduzida -> 32 HP/32 ataque;
// demais (suporte) -> 32 HP/16 Def/18 SpD
function spConvencao(nature) {
	const n = sim.Dex.natures.get(nature);
	const ev = {hp: 0, atk: 0, def: 0, spa: 0, spd: 0, spe: 0};
	if (n.plus === 'atk' || n.plus === 'spa') {
		if (n.minus === 'spe') { ev.hp = 32; ev[n.plus] = 32; ev.def = 2; } else { ev[n.plus] = 32; ev.spe = 32; ev.hp = 2; }
	} else if (n.plus === 'spe') {
		const atk = n.minus === 'spa' ? 'atk' : 'spa';
		ev[atk] = 32; ev.spe = 32; ev.hp = 2;
	} else {
		ev.hp = 32; ev.def = 16; ev.spd = 18;
	}
	return ev;
}

function montarBatalha(id) {
	const raw = JSON.parse(fs.readFileSync(path.join(DIR, 'raw', id + '.json'), 'utf8'));
	const teams = {};
	for (const l of raw.log.split('\n')) {
		if (l.startsWith('|showteam|')) {
			const side = l.split('|')[2];
			const packed = l.split('|').slice(3).join('|');
			const sets = Teams.unpack(packed);
			for (const s of sets) {
				s.level = 50;
				s.evs = spConvencao(s.nature || 'Serious');
				s.ivs = {hp: 31, atk: 31, def: 31, spa: 31, spd: 31, spe: 31};
			}
			teams[side] = Teams.pack(sets);
		}
	}
	if (!teams.p1 || !teams.p2) return null;
	const b = new Battle({formatid: FORMAT});
	b.setPlayer('p1', {name: 'p1', team: teams.p1});
	b.setPlayer('p2', {name: 'p2', team: teams.p2});
	return b;
}

const base = sp => sp.replace(/-Mega(-[XYZ])?$/, '');
function acharMon(side, especie) {
	return side.pokemon.find(p => base(p.species.name) === especie || base(p.baseSpecies.name) === especie || p.set.species === especie || p.name === especie);
}

function megaNome(p) {
	const it = p.getItem();
	if (!it.megaStone) return null;
	return typeof it.megaStone === 'string' ? it.megaStone : (it.megaStone[p.baseSpecies.name] || Object.values(it.megaStone)[0]);
}

function aplicarMon(b, side, info, slotIdx, megaUsada) {
	const p = acharMon(side, info.especie);
	if (!p) return null;
	if (info.megado && !p.species.isMega) {
		const m = megaNome(p);
		if (m) { try { p.formeChange(m, p.getItem(), true); } catch (e) { /* forma desconhecida: segue base */ } }
	}
	p.isActive = true;
	p.position = slotIdx;
	p.hp = info.hp > 0 ? Math.max(1, Math.round(info.hp / 100 * p.maxhp)) : 0;
	p.fainted = p.hp === 0;
	p.status = ['par', 'brn', 'slp', 'psn', 'tox', 'frz'].includes(info.status) ? info.status : '';
	p.boosts = {atk: 0, def: 0, spa: 0, spd: 0, spe: 0, accuracy: 0, evasion: 0, ...(info.boosts || {})};
	p.canMegaEvo = (!megaUsada && !p.species.isMega) ? megaNome(p) : false;
	p.activeMoveActions = info.turnos_campo === 0 || info.primeiro_turno ? 0 : 1;
	return p;
}

function main() {
	const D = fs.readFileSync(path.join(DIR, 'decisoes_eval.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
	const porJogo = new Map();
	for (const d of D) {
		if (!porJogo.has(d.id)) porJogo.set(d.id, []);
		porJogo.get(d.id).push(d);
	}
	const out = fs.createWriteStream(path.join(DIR, 'heur.jsonl'));
	let ok = 0, falha = 0;
	for (const [id, lista] of porJogo) {
		let b;
		try { b = montarBatalha(id); } catch (e) { b = null; }
		if (!b) { falha += lista.length; continue; }
		const megaUsada = {p1: false, p2: false};
		lista.sort((x, y) => x.turno - y.turno);
		for (const d of lista) {
			try {
				const si = d.lado === 'p1' ? 0 : 1;
				const meu = b.sides[si], dele = b.sides[1 - si];
				for (const s of b.sides) { for (const p of s.pokemon) p.isActive = false; s.active = [null, null]; }
				if (d.megado) megaUsada[d.lado] = true;
				const foeLado = d.lado === 'p1' ? 'p2' : 'p1';
				for (const o of d.oponentes) if (o.megado) megaUsada[foeLado] = true;
				const slot = d.slot === 'a' ? 0 : 1;
				const me = aplicarMon(b, meu, {...d, primeiro_turno: d.primeiro_turno}, slot, megaUsada[d.lado]);
				if (!me) { falha++; continue; }
				meu.active[slot] = me;
				if (d.aliado) {
					const a = aplicarMon(b, meu, d.aliado, 1 - slot, megaUsada[d.lado]);
					if (a && a !== me) meu.active[1 - slot] = a;
				}
				for (const o of d.oponentes) {
					const oi = o.slot === 'a' ? 0 : 1;
					const p = aplicarMon(b, dele, o, oi, megaUsada[foeLado]);
					if (p) dele.active[oi] = p;
				}
				me.lastMove = d.protegeu_antes ? b.dex.moves.get('protect') : null;
				me.volatiles = d.protegeu_antes ? {stall: {id: 'stall'}} : {};
				b.field.weather = WEATHER[toID(d.weather)] || '';
				b.field.terrain = TERRAIN[toID(d.terrain)] || '';
				b.field.pseudoWeather = d.tr ? {trickroom: {id: 'trickroom'}} : {};
				const telas = (lado, lista) => {
					const sc = {};
					for (const t of lista || []) sc[toID(t)] = {id: toID(t)};
					return sc;
				};
				meu.sideConditions = telas(d.lado, d.telas_proprio);
				dele.sideConditions = telas(foeLado, d.telas_oponente);
				if (d.tw_proprio) meu.sideConditions.tailwind = {id: 'tailwind'};
				if (d.tw_oponente) dele.sideConditions.tailwind = {id: 'tailwind'};

				const pl = Object.create(Player.prototype);
				pl.bs = {battle: b}; pl.sideIndex = si; pl.cfg = {};
				const ally = meu.active[1 - slot];
				const danger = pl.dangerTo(me);
				const valores = {};
				for (const ms of me.moveSlots) {
					const mv = b.dex.moves.get(ms.id);
					const opts = pl.scoreMove(me, ally, mv, mv.target, danger, null);
					valores[mv.name] = opts.length ? Math.max(...opts.map(o => o.value)) : 0;
				}
				valores['(troca)'] = 0;
				out.write(JSON.stringify({idx: d.idx, valores}) + '\n');
				ok++;
			} catch (e) {
				falha++;
			}
		}
	}
	out.end();
	console.log(`heurística: ${ok} decisões pontuadas, ${falha} falharam`);
}
main();
