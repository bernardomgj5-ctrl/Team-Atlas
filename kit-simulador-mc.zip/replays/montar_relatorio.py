#!/usr/bin/env python3
"""Gera os arquivos de dados do relatório (pasta relatorio/) a partir de tendencias*.json."""
import json, os

DIR = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(DIR, 'relatorio')
os.makedirs(OUT, exist_ok=True)
W = json.load(open(os.path.join(DIR, 'tendencias.json')))
R = json.load(open(os.path.join(DIR, 'tendencias_por_partida.json')))

NOMES = {
    'B6': 'Whimsicott/Basculegion/Floette/Garchomp/Kingambit/Charizard-Y',
    'C1': 'Rios/Kelsch: Garchomp-Z + Raichu-Y + Volcarona',
    'C2': 'Sol com Chlorophyll: Charizard-Y + Venusaur',
    'C3': 'TR com sol: Torkoal + Trick Room',
    'C4': 'Chuva com Swampert-Mega + Pelipper',
    'C5': 'Golisopod-Mega + Politoed (+ Farigiraf)',
    'C6': 'Floette/Salamence-Mega + Basculegion/Kingambit/Sneasler',
    'C7': 'Raichu-Y + Staraptor-Mega',
    'C8': 'Areia: Mega Tyranitar + Excadrill',
    'C9': 'Perish Trap: Gengar-Mega + Perish Song',
    'C10': 'Metagross-Mega + Psychic Terrain',
    'C11': 'Sol + chuva: Charizard-Y + Pelipper (03-META, 08/out)',
}


def fmt_lista(lst, n=4):
    return ' · '.join(f'{a} {b:.0f}%' for a, b in lst[:n] if b is not None)


def confianca(jog):
    if jog >= 15:
        return 'média'
    if jog >= 8:
        return 'baixa a média'
    if jog >= 2:
        return 'baixa'
    return 'sem amostra'


def salvar(nome, rows):
    with open(os.path.join(OUT, nome + '.json'), 'w') as f:
        json.dump(rows, f, ensure_ascii=False, indent=1)
    print(nome, len(rows))


a = W['amostra']
salvar('amostra', [
    {'metrica': 'Partidas públicas (Reg M-C Bo3, rating ≥ 1300)', 'valor': a['publicas']},
    {'metrica': 'Jogadores distintos na amostra pública', 'valor': a['jogadores_publicos']},
    {'metrica': 'Rating mediano das partidas públicas', 'valor': a['rating_mediano_publico']},
    {'metrica': 'Partidas de contas com "bot" no nome, excluídas', 'valor': W['excluidas_bot']},
    {'metrica': 'Partidas nossas na M-C (REGISTRO + VS Recorder)', 'valor': a['nossas']},
])

linhas = []
for k, v in W['ameacas'].items():
    linhas.append({
        'ameaca': k, 'nome': NOMES.get(k, ''), 'jogos': v['jogos'], 'jogadores': v['jogadores'],
        'vitoria_publico': v['vitoria_pct_publico'],
        'contra_nos': ', '.join(f'{t} {n}' for t, n in sorted(v['contra_nos'].items())) or '—',
        'levados': fmt_lista(v['levados'], 5), 'leads': fmt_lista(v['leads'], 3),
        'mega': fmt_lista(v['mega'], 3), 't1': fmt_lista(v['t1'], 4),
        'confianca': confianca(v['jogadores']),
    })
for k in NOMES:
    if k not in W['ameacas']:
        linhas.append({'ameaca': k, 'nome': NOMES[k], 'jogos': 0, 'jogadores': 0, 'vitoria_publico': None,
                       'contra_nos': '—', 'levados': '', 'leads': '', 'mega': '', 't1': '', 'confianca': 'sem amostra'})
ordem = ['B6'] + [f'C{i}' for i in range(1, 12)]
linhas.sort(key=lambda r: ordem.index(r['ameaca']))
salvar('ameacas', linhas)

linhas = []
for sp, e in W['especies_publico'].items():
    r = R['especies_publico'].get(sp, {})
    dj = dict(e['t1_como_lead']); dp = dict(r.get('t1_como_lead', []))
    golpes = set(dj) | set(dp)
    dif = max((abs(dj.get(g, 0) - dp.get(g, 0)) for g in golpes), default=0)
    linhas.append({
        'especie': sp, 'times': e['n_times'], 'jogadores': e['n_jogadores'],
        'levado': e['levado_pct'], 'lead': e['lead_pct_quando_levado'],
        'mega': e['mega_pct_quando_levado_com_pedra'], 'mega_t1': e['mega_t1_pct'],
        'protect': e['protect_pct_acoes'],
        't1_jogador': fmt_lista(e['t1_como_lead'], 3), 't1_partida': fmt_lista(r.get('t1_como_lead', []), 3),
        'divergencia': 'sim' if dif > 15 else '',
        'saidas': e['saidas_voluntarias_por_jogo_levado'],
    })
linhas.sort(key=lambda r: -r['jogadores'])
salvar('especies', linhas)

N = W['especies_nosso_t1g']; P = W['especies_publico']
linhas = []
for sp in ['Gallade', 'Staraptor', 'Garchomp', 'Indeedee-F', 'Gholdengo', 'Milotic']:
    n = N.get(sp); p = P.get(sp)
    if not n:
        continue
    linhas.append({
        'especie': sp, 'levado_nos': n['levado_pct'], 'lead_nos': n['lead_pct_quando_levado'],
        'lead_pub': p['lead_pct_quando_levado'] if p else None,
        't1_nos': fmt_lista(n['t1_como_lead'], 3), 't1_pub': fmt_lista(p['t1_como_lead'], 3) if p else 'sem amostra pública',
        'protect_nos': n['protect_pct_acoes'], 'protect_pub': p['protect_pct_acoes'] if p else None,
        'jogadores_pub': p['n_jogadores'] if p else 0,
    })
salvar('t1g', linhas)

nomes_grupo = {'publico': 'Amostra pública', 'adv_nosso': 'Nossos adversários', 'nosso': 'Nós (todos os times)'}
salvar('lado', [{'grupo': nomes_grupo[g], 'jogos': v['jogos'], 'turnos': v['turnos_medios'],
                 'foco': v['foco_mesmo_alvo_pct'], 'turnos_foco': v['turnos_com_dois_ataques_unicos'],
                 'trocas': v['trocas_voluntarias_por_jogo'], 'protect_seguido': v['protect_seguido_por_jogo']}
                for g, v in R['lado'].items()])

rot = {'T1G': 'T1-G', 'T8': 'T8', 'T3': 'T3 (geladeira)', 'T7': 'T7 (geladeira)', 'T1': 'T1', 'T1I': 'T1-I (retirado)'}
linhas = []
for k, v in W['nossos_times'].items():
    linhas.append({'time': rot.get(k, k), 'jogos': v['jogos'], 'vitorias': v['vitorias'],
                   'leads': ' · '.join(f'{l} {v2}–{c - v2}' for l, c, v2 in v['leads'][:4]),
                   'mega': ' · '.join(f'{m} ({c})' for m, c in v['mega'][:4])})
salvar('times', linhas)

e = W['especies_publico']; rr = R['especies_publico']


def faixa(sp, golpe, src_w=e, src_r=rr):
    vw = dict(src_w[sp]['t1_como_lead']).get(golpe, 0)
    vr = dict(src_r[sp]['t1_como_lead']).get(golpe, 0)
    lo, hi = sorted([vr, vw])
    return f'{lo:.0f}%' if round(lo) == round(hi) else f'{lo:.0f}–{hi:.0f}%'


def mega_faixa(sp):
    lo, hi = sorted([e[sp]['mega_t1_pct'], rr[sp]['mega_t1_pct']])
    return f'{lo:.0f}%' if round(lo) == round(hi) else f'{lo:.0f}–{hi:.0f}%'


ln = W['lado']; lr = R['lado']
achados = [
    {'n': 1, 'tema': 'Fake Out',
     'achado': f"Fake Out é a abertura mais comum de quem o carrega: no T1 como lead, Raichu {faixa('Raichu', 'Fake Out')}, Incineroar {faixa('Incineroar', 'Fake Out')} e Sneasler {faixa('Sneasler', 'Fake Out')} das ações. O alvo muda demais entre as duas contagens para virar padrão.",
     'confianca': 'média a alta'},
    {'n': 2, 'tema': 'Mega',
     'achado': f"Cerca de metade das Megas não acontece no T1: Raichu {mega_faixa('Raichu')}, Charizard {mega_faixa('Charizard')}, Garchomp {mega_faixa('Garchomp')} e Floette {mega_faixa('Floette-Eternal')} das Megas saem no T1. O Raichu que abre com Fake Out ainda está na forma base, com Lightning Rod.",
     'confianca': 'média a alta'},
    {'n': 3, 'tema': 'Setup no T1',
     'achado': f"Muitos leads gastam o T1 em setup: Gholdengo Nasty Plot {faixa('Gholdengo', 'Nasty Plot')}, Volcarona Quiver Dance {faixa('Volcarona', 'Quiver Dance')}, Floette Calm Mind {faixa('Floette-Eternal', 'Calm Mind')}, Delphox Nasty Plot {faixa('Delphox', 'Nasty Plot')}. Contra eles o T1 costuma ser uma janela de dano livre.",
     'confianca': 'média'},
    {'n': 4, 'tema': 'Protect no T1',
     'achado': f"O Archaludon de lead usa Protect em {faixa('Archaludon', 'Protect')} das ações de T1. Ataque mirado nele no T1 tende a cair no Protect; ligado às derrotas para C11.",
     'confianca': 'média a alta'},
    {'n': 5, 'tema': 'Tailwind',
     'achado': f"Tailwind não é a abertura padrão do Whimsicott neste rating: Moonblast {faixa('Whimsicott', 'Moonblast')}, Tailwind {faixa('Whimsicott', 'Tailwind')}. O Pelipper varia muito entre as contagens (Tailwind {faixa('Pelipper', 'Tailwind')}).",
     'confianca': 'média'},
    {'n': 6, 'tema': 'Sleep Powder',
     'achado': f"A Venusaur de lead usa Sleep Powder em {faixa('Venusaur', 'Sleep Powder')} das ações de T1, empatada com Earth Power ({faixa('Venusaur', 'Earth Power')}). O sono no T1 é provável, não garantido.",
     'confianca': 'média'},
    {'n': 7, 'tema': 'Padrões estáveis',
     'achado': f"Iguais nas duas contagens: Kingambit Kowtow Cleave {faixa('Kingambit', 'Kowtow Cleave')}, Farigiraf Trick Room {faixa('Farigiraf', 'Trick Room')}, Sylveon Hyper Voice {faixa('Sylveon', 'Hyper Voice')}, Indeedee-F Follow Me {faixa('Indeedee-F', 'Follow Me')}.",
     'confianca': 'alta'},
    {'n': 8, 'tema': 'Nossa Indeedee',
     'achado': f"Na T1-G, a nossa Indeedee-F abriu com Trick Room em {dict(W['especies_nosso_t1g']['Indeedee-F']['t1_como_lead']).get('Trick Room', 0):.0f}% e Follow Me em {dict(W['especies_nosso_t1g']['Indeedee-F']['t1_como_lead']).get('Follow Me', 0):.0f}% das ações de T1 (9 ações). No público, Follow Me é a abertura dominante e Trick Room não está entre as quatro primeiras. Com o lead Indeedee + Gallade em 2–6 (REGISTRO §11.11), hipótese a testar: Follow Me no T1, TR depois.",
     'confianca': 'baixa'},
    {'n': 9, 'tema': 'Foco de alvo',
     'achado': f"Quando os dois atacam com golpe de alvo único, o público mira o mesmo Pokémon em {lr['publico']['foco_mesmo_alvo_pct']:.0f}% dos turnos, nossos adversários em {lr['adv_nosso']['foco_mesmo_alvo_pct']:.0f}% e nós em {lr['nosso']['foco_mesmo_alvo_pct']:.0f}% ({lr['nosso']['turnos_com_dois_ataques_unicos']} turnos, todos os nossos times). Hipótese: dividimos os ataques mais que o meta.",
     'confianca': 'baixa a média'},
    {'n': 10, 'tema': 'Cobertura',
     'achado': "C6, C2, C11, C8 e B6 têm de 11 a 20 jogadores na amostra. C1, C3, C4, C5, C7 e C9 têm de 5 a 8, e C10 não aparece. Para C4, prioridade do projeto, não há base para padrão de comportamento.",
     'confianca': '—'},
]
salvar('achados', achados)
