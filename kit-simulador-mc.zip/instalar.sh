#!/usr/bin/env bash
# Restaura o ambiente de simulação numa sessão nova.
# Uso: descompactar kit-simulador-mc.zip em /home/claude e rodar: bash instalar.sh
set -e
cd "$(dirname "$0")"
if [ ! -d pokemon-showdown ]; then
  git clone -q https://github.com/smogon/pokemon-showdown.git
  (cd pokemon-showdown && git checkout -q 9b136a8c8cdb860a8ab96fa063f906604e352547)
fi
(cd pokemon-showdown && npm install --silent && node build >/dev/null)
# arquivos derivados dos replays (decisões e estado por turno)
(cd replays && python3 estruturar.py && python3 decisoes.py && python3 modelo.py preparar) >/dev/null
node simular.js times/T1G.txt times/T1G.txt -n 2 | head -3
node cores/teste-mecanicas.js | tail -1
echo "Pronto. Ex.: node cores/rodar.js times/T1G.txt 100"
