// Resumo do jogo de prévias (cores/previas.sh): uma linha por core.
// Uso: node cores/resumo-previas.js times/T1G.txt
// Colunas: bot x bot (prévia do bot dos dois lados) · pior prévia deles contra a prévia do bot ·
// valor do jogo (duplo oráculo; cai para a matriz se o oráculo não rodou) · nossa prévia de maior peso.
'use strict';
const fs = require('fs');
const path = require('path');
const nome = path.basename(process.argv[2] || 'times/T1G.txt', '.txt');
const D = path.join(__dirname, 'resultados', 'adv-' + nome);
const {CORES, CORES_VARIANTES} = require('./cores.js');
const ler = f => (fs.existsSync(f) && fs.statSync(f).size ? JSON.parse(fs.readFileSync(f, 'utf8')) : null);
for (const c of [...CORES, ...CORES_VARIANTES]) {
	const a = ler(`${D}/${c.id}.json`), m = ler(`${D}/${c.id}-matriz.json`), o = ler(`${D}/${c.id}-oraculo.json`);
	if (!a) continue;
	const jogo = o || (m && {valor: m.misto.valor, nossas: m.misto.nossas, linhas: m.linhas});
	let linha = '-';
	if (jogo) { const i = jogo.nossas.indexOf(Math.max(...jogo.nossas)); linha = `${jogo.linhas[i]} (${Math.round(jogo.nossas[i])}%)`; }
	const p = a.pior, cf = p.confirmacao;
	console.log(`${c.id.padEnd(11)} bot x bot ${(100 * a.bot6x6.wr).toFixed(0)}% · pior deles ${(100 * cf.wr).toFixed(0)}% (${p.previa.join('/')}${p.mega ? ' M ' + p.mega[0] : ''}) · jogo ${jogo ? jogo.valor.toFixed(1) + '%' + (o ? '' : ' (matriz)') : '-'} · nossa: ${linha}`);
}
