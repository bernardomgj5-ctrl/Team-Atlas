# kit-simulador-mc (versão de 10/nov/2026)

Simulador do projeto de Pokémon Champions VGC (Reg M-C). Showdown no commit 9b136a8, formato
`gen9championsvgc2026regmc`. O nosso lado joga com a heurística do bot; o adversário mistura a
heurística com as frequências de 13.438 decisões de replays (`cores/modelo_adversario.json`).

## Restaurar
Descompactar em /home/claude e rodar `bash instalar.sh` (1 a 2 min). O instalador termina com
"CONTROLE DE MECÂNICAS OK". Se não terminar assim, não usar os números.

## Comandos
| Para | Comando |
|---|---|
| Time contra os 8 cores, uma linha por core | `node cores/rodar.js times/T1G.txt 100` |
| Só alguns cores, prévia fixa, outra semente | `node cores/rodar.js times/T1G.txt 300 --cores C6,C10 --previa Gallade,Indeedee-F,Charizard,Garchomp --mega Charizard --semente 11` |
| Regra em teste do nosso lado | `node cores/rodar.js times/T1G.txt 300 --regras-a troca,custo,previa,redir,megatipo` |
| Dois times quaisquer, com log | `node simular.js A.txt B.txt -n 20 --log` |
| Prévia otimizada dos dois lados | `bash cores/previas.sh times/T1G.txt` e depois `node cores/resumo-previas.js times/T1G.txt` |
| Controles | `node cores/teste-mecanicas.js` · `node cores/teste-custo.js` |
| Previsão nos replays | `cd replays && node heuristica.js troca h.jsonl && python3 modelo.py avaliar h.jsonl a.json` |

## Onde está cada coisa
- `times/`: T1G.txt, T8.txt, T9.txt (iguais às fichas do projeto; se a ficha mudar, mudar aqui).
- `cores/cores.js`: as 8 ameaças (B6, C2, C5, C6, C7, C8, C10, C11) e as variantes B6-Bascu e
  C10-Floette. Listas em `cores/candidatos/`; as retiradas (C3, C9, EDU, HOLO) em `candidatos/retirados/`.
  A lista de areia (C8M) usa desde 11/nov os spreads mais frequentes da base em 10/nov, os mesmos dos
  benchmarks das fichas; resultados de C8 anteriores a 11/nov são da lista antiga.
- `cores/historico/`: times, runners e resultados anteriores a 10/nov. Não usar em análise nova.
- `replays/`: base de replays e scripts do modelo do adversário.

## Estado do bot
- Lado A: `troca` + `custo` + `previa` + `redir`. Lado B (modelo): `troca`.
- Desligadas: `protect`, `dividir`, `fim`, `setup`, `megatipo`, `perish`.
- A semente fixa os sorteios do modelo e da batalha: a mesma semente repete a rodada inteira.
  Antes de 10/nov só o modelo era fixado; números antigos "com semente fixa" não eram repetíveis.
- Mecânicas que a estimativa passou a cobrir em 10/nov: Sacred Sword ignora estágios de Defesa,
  Focus Sash e Sturdy com HP cheio (fora da prévia), Expanding Force em área no Psychic Terrain,
  Unburden, Good as Gold contra Helping Hand do aliado, Follow Me puxa golpe de sono de alvo
  único, Wide Guard em turnos seguidos, status com prioridade falha no Psychic Terrain.
- O bot não faz: segurar a Mega por causa do clima, contar o Tailwind de Prankster do mesmo
  turno na ordem de Speed, jogar em torno de Fake Out depois de troca, prever Protect ou troca,
  linha de Perish Song, regras de seleção 8 e 15 da ficha do T1-G.

## Como ler
Simulação é evidência de simulação, não de partida. Dizer N, semente e versão do bot. Com 300
batalhas por core o IC95 é de ±5 a 6 pp; diferença menor que isso num core é ruído.
