// Conjunto novo de 25/out: C5 → N3 (Delphox-Mega), C10 → N1F (chuva com Golisopod), C9 → C9M (Medina)
const fs=require('fs');const path=require('path');const {CORES}=require('../../cores/cores.js')
const rd=id=>fs.readFileSync(path.join(__dirname,'../../cores/candidatos/'+id+'.txt'),'utf8')
const C9M={id:'C9M',text:rd('C9M'),previaOpp:['Gengar','Rillaboom','Incineroar','Kommo-o'],megaOpp:['Gengar']}
const N3={id:'N3',text:rd('N3'),previaOpp:undefined,megaOpp:undefined,cand:true}
const N1F={id:'N1F',text:rd('N1F'),previaOpp:undefined,megaOpp:undefined,cand:true}
const NOVOS=[...CORES.filter(c=>!['C5','C9','C10'].includes(c.id)),N3,C9M,N1F]
module.exports={C9M,NOVOS}
