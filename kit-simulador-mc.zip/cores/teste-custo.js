// Casos de controle da regra "custo": valor de cada golpe com e sem a regra
const path=require('path');const {loadShowdown,makePlayerClass}=require('../simular.js');
const sim=loadShowdown();const Player=makePlayerClass(sim.BattlePlayer);
const T=s=>sim.Teams.pack(sim.Teams.import(s).map(x=>({...x,level:50})));
const nosso=`Garchomp @ Garchompite Z
Ability: Rough Skin
EVs: 18 HP / 32 SpA / 16 Spe
Timid Nature
- Draco Meteor
- Power Gem
- Earth Power
- Protect

Milotic @ Leftovers
Ability: Competitive
EVs: 32 HP / 10 Def / 21 SpA / 3 SpD
Bold Nature
- Ice Beam
- Scald
- Recover
- Protect

Gallade @ Life Orb
Ability: Sharpness
EVs: 32 HP / 16 Atk / 16 Def / 2 SpD
Adamant Nature
- Leaf Blade
- Sacred Sword
- Psycho Cut
- Wide Guard

Volcarona @ Rocky Helmet
Ability: Flame Body
EVs: 32 HP / 10 Def / 1 SpD / 23 Spe
Timid Nature
- Bug Buzz
- Overheat
- Rage Powder
- Tailwind`;
const deles=`Delphox @ Delphoxite
Ability: Blaze
EVs: 32 SpA / 32 Spe
Timid Nature
- Heat Wave
- Psychic
- Nasty Plot
- Protect

Sinistcha
Ability: Hospitality
EVs: 32 HP / 32 Def
Bold Nature
- Matcha Gotcha
- Rage Powder
- Trick Room
- Protect

Incineroar @ Sitrus Berry
Ability: Intimidate
EVs: 32 HP / 20 Def / 14 SpD
Impish Nature
- Fake Out
- Flare Blitz
- Throat Chop
- Parting Shot

Kingambit @ Life Orb
Ability: Defiant
EVs: 32 Atk / 32 HP
Adamant Nature
- Kowtow Cleave
- Sucker Punch
- Swords Dance
- Protect`;
function caso(nome, setup){
 const b=new sim.Battle({formatid:'gen9championsvgc2026regmc'});
 b.setPlayer('p1',{name:'A',team:T(nosso)});b.setPlayer('p2',{name:'B',team:T(deles)});
 b.makeChoices('team 1234','team 1234');
 // Mega nos dois
 const [g,m]=b.sides[0].active,[d,s]=b.sides[1].active;
 b.actions.runMegaEvo(g); b.actions.runMegaEvo(d);
 setup({b,g,m,d,s});
 const res={};
 for(const regras of [['troca'],['troca','custo']]){
  const pl=Object.create(Player.prototype);pl.bs={battle:b};pl.sideIndex=0;pl.cfg={regras};pl.R=new Set(regras);
  const danger=pl.dangerTo(g);const linha={};
  for(const ms of g.moveSlots){const mv=b.dex.moves.get(ms.id);const o=pl.scoreMove(g,m,mv,mv.target,danger,null);
   const alvo=o.filter(x=>x.targetMon===d)[0]||o[0];linha[mv.name]=alvo?+alvo.value.toFixed(3):null}
  res[regras.join('+')]=linha}
 console.log('\n'+nome);for(const k in res)console.log(' ',k.padEnd(12),JSON.stringify(res[k]));
}
caso('1) Delphox-Mega 100% + Sinistcha (Rage Powder) — G1 turno 2',()=>{});
caso('2) Delphox-Mega 100% + Sinistcha caída (sem redirecionamento)',({s})=>{s.hp=0;s.fainted=true});
caso('3) Delphox-Mega 70% (Draco converte KO, Power Gem não)',({d,s})=>{d.hp=Math.round(d.maxhp*0.66);s.hp=0;s.fainted=true});
caso('4) Garchomp ameaçado de KO por alguém mais rápido (+2 Delphox)',({d,s})=>{d.boosts.spa=2;s.hp=0;s.fainted=true});
{const b=new sim.Battle({formatid:'gen9championsvgc2026regmc'});
 b.setPlayer('p1',{name:'A',team:T(nosso)});b.setPlayer('p2',{name:'B',team:T(deles)});
 b.makeChoices('team 1234','team 1234');const [g]=b.sides[0].active,[d]=b.sides[1].active;
 b.actions.runMegaEvo(g); b.actions.runMegaEvo(d);
 const {estimateDamage}=require('../simular.js');
 console.log(g.species.name,g.getTypes(),g.storedStats,g.boosts, d.species.name,d.getTypes(),d.ability,d.hp,d.maxhp,d.storedStats);
 for(const mv of ['dracometeor','powergem']) console.log(mv,estimateDamage(b,g,d,b.dex.moves.get(mv)));}
