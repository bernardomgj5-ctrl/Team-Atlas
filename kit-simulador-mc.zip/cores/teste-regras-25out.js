// Casos de controle das regras previa, redir, megatipo e perish (análise das 22 partidas de 25/out)
const fs=require('fs');const path=require('path');const {loadShowdown,makePlayerClass}=require('../simular.js');
const sim=loadShowdown();const Player=makePlayerClass(sim.BattlePlayer);
const T=s=>sim.Teams.pack(sim.Teams.import(s).map(x=>({...x,level:50})));
const nosso=fs.readFileSync(path.join(__dirname,'T1G-CHARIZARD.txt'),'utf8');
const mk=(team2,c1='team 1234',c2='team 1234')=>{const b=new sim.Battle({formatid:'gen9championsvgc2026regmc'});b.setPlayer('p1',{name:'A',team:T(nosso)});b.setPlayer('p2',{name:'B',team:T(team2)});if(c1)b.makeChoices(c1,c2);return b;};
const pl=(b,regras)=>{const p=Object.create(Player.prototype);p.bs={battle:b};p.sideIndex=0;p.cfg={regras};p.R=new Set(regras);return p;};
const sam=`Zoroark-Hisui @ Focus Sash
Ability: Illusion
EVs: 32 SpA / 32 Spe
Timid Nature
- Bitter Malice
- Protect
- Taunt
- Icy Wind

Raichu @ Raichunite Y
Ability: Lightning Rod
EVs: 32 SpA / 32 Spe
Timid Nature
- Fake Out
- Protect
- Focus Blast
- Zap Cannon

Annihilape @ Choice Scarf
Ability: Defiant
EVs: 32 Atk / 32 Spe
Adamant Nature
- Phantom Force
- U-turn
- Close Combat
- Rage Fist

Altaria @ Haban Berry
Ability: Cloud Nine
EVs: 32 HP / 32 Spe
Timid Nature
- Ice Beam
- Tailwind
- Will-O-Wisp
- Haze

Metagross @ Metagrossite
Ability: Clear Body
EVs: 32 Atk / 32 Spe
Jolly Nature
- Psychic Fangs
- Protect
- Iron Head
- Earthquake

Glimmora @ Life Orb
Ability: Toxic Debris
EVs: 32 SpA / 32 Spe
Timid Nature
- Spiky Shield
- Sludge Bomb
- Earth Power
- Power Gem`;
// 1) prévia contra o time da série 8
{const b=mk(sam,null,null);
 for(const r of [['troca','custo'],['troca','custo','previa']]){const p=pl(b,r);p.cfg.previa=null;const c=p.chooseTeamPreview({maxChosenTeamSize:4});console.log('prévia',r.join('+').padEnd(20),c,p.preview.escolhidos.join(', '))}}
// 2) Rage Powder da Volcarona contra Garchomp-Mega com Power Gem (série 9, jogo 2)
const ig=`Garchomp @ Garchompite Z
Ability: Rough Skin
EVs: 32 SpA
Modest Nature
- Dragon Pulse
- Earth Power
- Power Gem
- Protect

Ninetales-Alola @ Choice Scarf
Ability: Snow Warning
EVs: 32 SpA / 32 Spe
Timid Nature
- Blizzard
- Freeze-Dry
- Icy Wind
- Hypnosis

Sneasler @ Focus Sash
Ability: Unburden
EVs: 32 Atk / 32 Spe
Jolly Nature
- Fake Out
- Dire Claw
- Close Combat
- Protect

Kingambit @ Black Glasses
Ability: Defiant
EVs: 32 HP / 32 Atk
Adamant Nature
- Sucker Punch
- Kowtow Cleave
- Swords Dance
- Protect`;
{const b=mk(ig,'team 2534','team 1234');const [gal,vol]=b.sides[0].active;const [garc]=b.sides[1].active;b.actions.runMegaEvo(garc);
 for(const r of [['troca','custo'],['troca','custo','redir']]){const p=pl(b,r);const mv=b.dex.moves.get('ragepowder');const o=p.scoreMove(vol,gal,mv,mv.target,p.dangerTo(vol),null);
  const best=['bugbuzz','overheat'].map(id=>{const m=b.dex.moves.get(id);return Math.max(...p.scoreMove(vol,gal,m,m.target,p.dangerTo(vol),null).map(x=>x.value))});
  console.log('Rage Powder',r.join('+').padEnd(20),o[0].value.toFixed(3),'| melhor ataque',Math.max(...best).toFixed(3))}}
// 3) Mega do Garchomp contra Raichu com Zap Cannon em campo (série 8)
{const b=mk(sam,'team 3412','team 2615');const [g]=b.sides[0].active;
 for(const r of [['troca','custo'],['troca','custo','megatipo']]){const p=pl(b,r);console.log('Mega Garchomp vs Raichu',r.join('+').padEnd(20),p.querMega(g))}
 const b2=mk(ig,'team 3412','team 3412');const [g2]=b2.sides[0].active;const p2=pl(b2,['megatipo']);console.log('Mega Garchomp vs Sneasler/Kingambit (controle, deve evoluir)',p2.querMega(g2));}
// 4) Perish: preso pelo Gengar-Mega com Shadow Tag
const gen=`Gengar @ Gengarite
Ability: Cursed Body
EVs: 32 HP / 32 SpD
Calm Nature
- Protect
- Perish Song
- Sludge Bomb
- Shadow Ball

Politoed @ Sitrus Berry
Ability: Drizzle
EVs: 32 HP / 32 Def
Bold Nature
- Protect
- Perish Song
- Weather Ball
- Ice Beam

Rillaboom @ Coba Berry
Ability: Grassy Surge
EVs: 32 HP / 32 SpD
Careful Nature
- Protect
- Fake Out
- U-turn
- Grassy Glide

Archaludon @ Leftovers
Ability: Stamina
EVs: 32 HP / 32 SpD
Calm Nature
- Protect
- Electro Shot
- Dragon Pulse
- Flash Cannon`;
{const b=mk(gen,'team 2346','team 1234');const [gal,gar]=b.sides[0].active;const [geng]=b.sides[1].active;b.actions.runMegaEvo(geng);
 gal.addVolatile('perishsong');gal.volatiles.perishsong.duration=2;
 for(const r of [['troca','custo'],['troca','custo','perish']]){const p=pl(b,r);const mv=b.dex.moves.get('psychocut');const o=p.scoreMove(gal,gar,mv,mv.target,p.dangerTo(gal),null);console.log('Psycho Cut sob Perish',r.join('+').padEnd(20),o.map(x=>(x.targetMon.species.name)+' '+x.value.toFixed(3)).join(' | '))}}
{const {bestDamage}=require('../simular.js');const b=mk(sam,null,null);const p=pl(b,['previa']);
 for(const m of b.sides[0].pokemon){const ms=p.matchupScore(m,b.sides[1].pokemon);const f=b.sides[1].pokemon.filter(x=>bestDamage(b,x,m)>=0.75*m.maxhp).map(x=>x.species.name);console.log(m.species.name.padEnd(12),'off',ms.off.toFixed(2),'def',ms.def.toFixed(2),'base',(ms.off-0.6*ms.def+p.roleBonus(m)).toFixed(2),'fortes',f.join(','))}}
