const fs=require('fs');const path=require('path');const {CORES}=require('../../cores/cores.js')
const cand=['N1','N1F','N3'].map(id=>({id,text:fs.readFileSync(path.join(__dirname,'../../cores/candidatos/'+id+'.txt'),'utf8'),previaOpp:undefined,megaOpp:undefined,cand:true}))
module.exports={TODOS:[...CORES,...cand],CORES}
