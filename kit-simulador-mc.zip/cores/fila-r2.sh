#!/bin/bash
# Rodada 2: melhor resposta deles à nossa prévia recomendada (linha maximin pura da matriz).
cd /home/claude; D=cores/resultados-28out/adv
for t in "$@"; do
  until [ -s $D/$t-matriz.json ]; do sleep 20; done
  mkdir $D/$t-r2.lock 2>/dev/null || continue
  L=$(python3 -c "import json;m=json.load(open('$D/$t-matriz.json'));l=m['puro']['linha'];print(l)")
  [ "$L" = "bot" ] && continue
  P=$(echo "$L" | sed 's/ (M .*//; s#/#,#g'); M=$(echo "$L" | sed -n 's/.*(M \(.*\))/\1/p')
  NOSSA="$P" MEGA_A="$M" node cores/adversario.js cores/candidatos/$t.txt $t-r2 20 150 600 8 > $D/$t-r2.json 2> $D/$t-r2.err
done
