#!/usr/bin/env python3
"""Estrutura os logs brutos (raw/*.json) em duas tabelas:
  partidas.jsonl  uma linha por partida
  acoes.csv       uma linha por ação (golpe, troca, falha de ação)
Uso: python3 estruturar.py [nome_do_jogador_nosso]
"""
import csv, json, os, re, sys, glob

DIR = os.path.dirname(os.path.abspath(__file__))
NOSSO = (sys.argv[1] if len(sys.argv) > 1 else 'bernardomgj').lower()
PROTECT = {'Protect', 'Detect', 'Spiky Shield', "King's Shield", 'Baneful Bunker', 'Silk Trap', 'Burning Bulwark'}
PIVOT = {'U-turn', 'Volt Switch', 'Flip Turn', 'Parting Shot', 'Chilly Reception', 'Shed Tail', 'Teleport', 'Baton Pass'}


def base_species(details):
    sp = details.split(',')[0].strip()
    return re.sub(r'-Mega(-[XYZ])?$', '', sp)


def ident(s):
    # "p2a: Indeedee" -> ("p2", "a", "Indeedee")
    m = re.match(r'(p\d)([ab]?): ?(.*)', s)
    return (m.group(1), m.group(2), m.group(3)) if m else (None, None, None)


def ler_showteam(txt):
    sets = []
    for parte in txt.split(']'):
        c = parte.split('|')
        if len(c) < 7:
            continue
        sets.append({'species': c[0], 'item': c[2], 'ability': c[3], 'moves': [m for m in c[4].split(',') if m], 'nature': c[5]})
    return sets


def estruturar(path, fonte):
    d = json.load(open(path))
    linhas = d['log'].split('\n')
    p = {'id': d['id'], 'formato': d.get('formatid', ''), 'fonte': fonte, 'rating': d.get('rating') or 0,
         'jogadores': {}, 'rating_jog': {}, 'time': {'p1': [], 'p2': []}, 'sets': {'p1': [], 'p2': []},
         'levados': {'p1': [], 'p2': []}, 'leads': {'p1': [], 'p2': []}, 'mega': {'p1': None, 'p2': None},
         'vencedor': None, 'turnos': 0, 'desistencia': False, 'nosso': None}
    acoes = []
    turno = 0
    especie = {}  # (side, nick) -> espécie base
    ativos = {}   # (side, slot) -> nick
    ultimo_golpe = {}  # (side, nick) -> golpe do turno anterior
    ultimo_evento = None  # para classificar trocas
    movimentos_no_turno = 0
    for l in linhas:
        if not l.startswith('|'):
            continue
        c = l.split('|')
        cmd = c[1] if len(c) > 1 else ''
        if cmd == 'player' and len(c) > 3 and c[3]:
            p['jogadores'][c[2]] = c[3]
            if len(c) > 5 and c[5].isdigit():
                p['rating_jog'][c[2]] = int(c[5])
            if c[3].lower() == NOSSO:
                p['nosso'] = c[2]
        elif cmd == 'poke':
            p['time'][c[2]].append(base_species(c[3]))
        elif cmd == 'showteam':
            p['sets'][c[2]] = ler_showteam('|'.join(c[3:]))
        elif cmd == 'turn':
            turno = int(c[2])
            p['turnos'] = turno
            movimentos_no_turno = 0
            ultimo_evento = 'turno'
        elif cmd in ('switch', 'drag'):
            side, slot, nick = ident(c[2])
            sp = base_species(c[3])
            especie[(side, nick)] = sp
            ultimo_golpe.pop((side, nick), None)  # reentrada: volta a ser "primeiro turno em campo"
            anterior = ativos.get((side, slot))
            ativos[(side, slot)] = nick
            if sp not in p['levados'][side]:
                p['levados'][side].append(sp)
            if turno == 0:
                p['leads'][side].append(sp)
                continue
            if cmd == 'drag':
                tipo = 'arrastado'
            elif ultimo_evento == 'pivot':
                tipo = 'pivot'
            elif ultimo_evento in ('faint', 'upkeep'):
                tipo = 'forcada'
            elif movimentos_no_turno == 0:
                tipo = 'voluntaria'
            else:
                tipo = 'forcada'
            acoes.append({'id': d['id'], 'turno': turno, 'lado': side, 'slot': slot, 'especie': sp, 'tipo': 'troca',
                          'golpe': tipo, 'alvo_lado': '', 'alvo_especie': especie.get((side, anterior), '') if anterior else '',
                          'area': 0, 'protect': 0, 'primeiro_turno': 0})
        elif cmd == 'move':
            side, slot, nick = ident(c[2])
            golpe = c[3]
            extra = c[5:] if len(c) > 5 else []
            if any('[from]' in x for x in extra) or '[still]' in extra:
                # golpe travado/carregamento: conta como ação, marca
                pass
            alvo_side, alvo_slot, alvo_nick = ident(c[4]) if len(c) > 4 and c[4] else (None, None, None)
            area = int(any(x.startswith('[spread]') for x in extra))
            sp = especie.get((side, nick), nick)
            alvo_sp = especie.get((alvo_side, alvo_nick), alvo_nick or '')
            alvo_rel = '' if not alvo_side else ('proprio' if (alvo_side == side and alvo_nick == nick) else ('aliado' if alvo_side == side else 'oponente'))
            # primeiro turno em campo: a ação anterior dele foi a entrada
            primeiro = int(ultimo_golpe.get((side, nick)) is None)
            acoes.append({'id': d['id'], 'turno': turno, 'lado': side, 'slot': slot, 'especie': sp, 'tipo': 'golpe',
                          'golpe': golpe, 'alvo_lado': alvo_rel, 'alvo_especie': alvo_sp, 'area': area,
                          'protect': int(golpe in PROTECT), 'primeiro_turno': primeiro,
                          'travado': int(any('[from]' in x for x in extra)), 'carga': int('[still]' in extra)})
            ultimo_golpe[(side, nick)] = golpe
            movimentos_no_turno += 1
            ultimo_evento = 'pivot' if golpe in PIVOT else 'move'
        elif cmd == 'cant':
            side, slot, nick = ident(c[2])
            acoes.append({'id': d['id'], 'turno': turno, 'lado': side, 'slot': slot, 'especie': especie.get((side, nick), nick),
                          'tipo': 'nao_agiu', 'golpe': c[3] if len(c) > 3 else '', 'alvo_lado': '', 'alvo_especie': '',
                          'area': 0, 'protect': 0, 'primeiro_turno': 0})
        elif cmd == '-mega':
            side, slot, nick = ident(c[2])
            p['mega'][side] = {'especie': especie.get((side, nick), c[3]), 'turno': turno}
        elif cmd == 'faint':
            ultimo_evento = 'faint'
        elif cmd == 'upkeep':
            ultimo_evento = 'upkeep'
        elif cmd == 'win':
            nome = c[2]
            p['vencedor'] = next((s for s, n in p['jogadores'].items() if n == nome), None)
        elif cmd == '-message' and 'forfeited' in l:
            p['desistencia'] = True
        elif cmd == 'raw' and 'forfeited' in l:
            p['desistencia'] = True
    # 'primeiro turno' deve considerar re-entrada: zera o histórico na troca
    return p, acoes


def main():
    fontes = {}
    for linha in open(os.path.join(DIR, 'fontes.jsonl')):
        r = json.loads(linha)
        fontes.setdefault(r['id'], r)
    partidas, todas = [], []
    for path in sorted(glob.glob(os.path.join(DIR, 'raw', '*.json'))):
        rid = os.path.basename(path)[:-5]
        f = fontes.get(rid, {'fonte': '?', 'rotulo': ''})
        p, acoes = estruturar(path, f['fonte'])
        p['rotulo'] = f.get('rotulo', '')
        partidas.append(p)
        todas.extend(acoes)
    with open(os.path.join(DIR, 'partidas.jsonl'), 'w') as fo:
        for p in partidas:
            fo.write(json.dumps(p, ensure_ascii=False) + '\n')
    campos = ['id', 'turno', 'lado', 'slot', 'especie', 'tipo', 'golpe', 'alvo_lado', 'alvo_especie', 'area',
              'protect', 'primeiro_turno', 'travado', 'carga']
    with open(os.path.join(DIR, 'acoes.csv'), 'w', newline='') as fo:
        w = csv.DictWriter(fo, fieldnames=campos, extrasaction='ignore')
        w.writeheader()
        for a in todas:
            w.writerow(a)
    print(f'{len(partidas)} partidas, {len(todas)} ações')


if __name__ == '__main__':
    main()
