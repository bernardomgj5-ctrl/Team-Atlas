#!/bin/bash
# Jogo de prévias (prévia otimizada dos dois lados) de um time contra os cores de cores.js.
# Uso: bash cores/previas.sh times/T1G.txt [ids dos cores...]      (padrão: os 8 cores ativos)
# Etapas por core: adversario.js (pior prévia deles + nossa resposta) → matriz.js → rodada 2
# (melhor resposta deles à nossa linha) → oraculo.js. Resultados em cores/resultados/adv-<TIME>/.
# Rodar dois em paralelo (uma chamada por metade dos cores) usa os 2 núcleos; cada core leva ~25 min.
# Resumo: node cores/resumo-previas.js times/T1G.txt
cd /home/claude
export TIME=$1; shift
NOME=$(basename "$TIME" .txt); export DIR=cores/resultados/adv-$NOME; mkdir -p "$DIR"
IDS=${@:-B6 C2 C5 C6 C7 C8 C10 C11}
for id in $IDS; do
  A=$(node -e "const {CORES,CORES_VARIANTES}=require('./cores/cores.js');const c=[...CORES,...CORES_VARIANTES].find(x=>x.id==='$id');console.log(c?c.arquivo:'')")
  [ -z "$A" ] && { echo "core $id não existe em cores.js"; continue; }
  mkdir "$DIR/$id.lock" 2>/dev/null || continue
  [ -s "$DIR/$id.json" ] || node cores/adversario.js cores/candidatos/$A.txt $id 20 150 600 10 --resposta > "$DIR/$id.json" 2> "$DIR/$id.err"
  [ -s "$DIR/$id-matriz.json" ] || node cores/matriz.js $id 80 > "$DIR/$id-matriz.json" 2> "$DIR/$id-matriz.err"
  L=$(python3 -I -c "import json;print(json.load(open('$DIR/$id-matriz.json'))['puro']['linha'])")
  if [ "$L" != "bot" ] && [ ! -s "$DIR/$id-r2.json" ]; then
    P=$(echo "$L" | sed 's/ (M .*//; s#/#,#g'); M=$(echo "$L" | sed -n 's/.*(M \(.*\))/\1/p')
    NOSSA="$P" MEGA_A="$M" node cores/adversario.js cores/candidatos/$A.txt $id-r2 20 150 600 8 > "$DIR/$id-r2.json" 2> "$DIR/$id-r2.err"
  fi
  [ -s "$DIR/$id-oraculo.json" ] || node cores/oraculo.js $id > "$DIR/$id-oraculo.json" 2> "$DIR/$id-oraculo.err"
  rmdir "$DIR/$id.lock"
  echo "$id pronto"
done
