// Prévia adversária otimizada contra o T1-G (28/out/2026).
// Para um time adversário de 6, testa todas as escolhas de 4 com o par de lead (15 x 6 = 90; x2 Megas
// quando as duas Mega Stones vão juntas) e procura a que mais derruba o T1-G. O nosso lado escolhe a
// prévia com o bot (regras padrão do lado A); o lado deles joga com o modelo do adversário.
// Etapas: (1) triagem de todas as configurações com n1 batalhas; (2) as k piores para nós com n2;
// (3) a pior da etapa 2 com n3 e semente nova (estimativa sem o viés da seleção) e o 6x6 do bot com n3.
// Opcional (4): resposta nossa à pior prévia: as 90 prévias do T1-G contra ela (n1), as 5 melhores com n2,
// a melhor com n3 e semente nova.
// Uso: node cores/adversario.js <arquivo do time> <rótulo> [n1 n2 n3 k] [--resposta] > saida.json
'use strict';
const fs = require('fs');
const {simular} = require('../simular.js');
const [,, arq, rot, N1 = 16, N2 = 100, N3 = 600, K = 8, flag] = process.argv;
const t1g = fs.readFileSync('cores/T1G-CHARIZARD.txt', 'utf8');
const opp = fs.readFileSync(arq, 'utf8');
const MODELO = 'cores/modelo_adversario.json';
// NOSSA="A,B,C,D" (e MEGA_A="X") fixa a nossa prévia: mede a melhor resposta deles a ela.
const NOSSA = process.env.NOSSA ? {previa: process.env.NOSSA.split(','), mega: process.env.MEGA_A ? [process.env.MEGA_A] : undefined} : {};

const membros = txt => txt.trim().split(/\n\s*\n/).map(b => {
	const [l1] = b.split('\n');
	return {nome: l1.split('@')[0].trim().replace(/\s*\(.*\)/, ''), mega: /ite( [XYZ])?\s*$/.test(l1) && !/White Herb|Light Clay|Rocky Helmet/.test(l1)};
});
const wilson = (k, n) => { const z = 1.96, p = k / n, d = 1 + z * z / n, c = p + z * z / (2 * n), m = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)); return [(c - m) / d, (c + m) / d]; };
const pct = x => +(100 * x).toFixed(1);

function configs(mons) {
	const out = [];
	const idx = [0, 1, 2, 3, 4, 5];
	for (let a = 0; a < 6; a++) for (let b = a + 1; b < 6; b++) for (let c = b + 1; c < 6; c++) for (let d = c + 1; d < 6; d++) {
		const q = [a, b, c, d];
		for (let i = 0; i < 4; i++) for (let j = i + 1; j < 4; j++) {
			const leads = [q[i], q[j]], back = q.filter(x => x !== q[i] && x !== q[j]);
			const previa = [...leads, ...back].map(x => mons[x].nome);
			const megas = [...leads, ...back].filter(x => mons[x].mega).map(x => mons[x].nome);
			if (megas.length <= 1) out.push({previa, mega: megas.length ? megas : undefined});
			else for (const m of megas) out.push({previa, mega: [m, ...megas.filter(x => x !== m)]});
		}
	}
	void idx;
	return out;
}

async function rodar(ladoNosso, ladoDeles, n, semente) {
	const r = await simular(t1g, opp, {n: +n, nomes: ['T1G', 'OPP'], previaA: ladoNosso.previa, megaA: ladoNosso.mega,
		previaB: ladoDeles.previa, megaB: ladoDeles.mega, modeloB: MODELO, semente});
	const s = r.stats;
	return {v: s.vitorias[0], n: s.batalhas, wr: s.vitorias[0] / Math.max(1, s.batalhas), previaA: s.previa[0], leadsA: s.leads[0], megasA: s.megas[0],
		megasB: s.megas[1], desmaiosA: s.desmaios[0], desmaiosB: s.desmaios[1], fb: s.fallbacks};
}

(async () => {
	const mons = membros(opp);
	const cfgs = configs(mons);
	const t0 = Date.now();
	// 1
	const tri = [];
	for (const c of cfgs) tri.push({...c, ...(await rodar(NOSSA, c, N1, 11))});
	tri.sort((a, b) => a.wr - b.wr);
	// 2
	const fase2 = [];
	for (const c of tri.slice(0, +K)) fase2.push({...c, ...(await rodar(NOSSA, c, N2, 23))});
	fase2.sort((a, b) => a.wr - b.wr);
	const pior = fase2[0];
	// 3
	const conf = await rodar(NOSSA, pior, N3, 37);
	const bot = await rodar(NOSSA, {}, N3, 37);
	const res = {rotulo: rot, nossa: NOSSA.previa ? NOSSA : 'bot', arquivo: arq, configs: cfgs.length, n: [+N1, +N2, +N3],
		bot6x6: {...bot, ic: wilson(bot.v, bot.n).map(pct)},
		pior: {previa: pior.previa, mega: pior.mega, triagem: pct(tri.find(x => x.previa.join() === pior.previa.join() && String(x.mega) === String(pior.mega)).wr), fase2: pct(pior.wr), confirmacao: {...conf, ic: wilson(conf.v, conf.n).map(pct)}},
		fase2: fase2.map(x => ({previa: x.previa.join('/'), mega: x.mega && x.mega[0], wr: pct(x.wr)})),
		triagemTop: tri.slice(0, 15).map(x => ({previa: x.previa.join('/'), mega: x.mega && x.mega[0], wr: pct(x.wr)})),
		triagemMelhoresParaNos: tri.slice(-5).map(x => ({previa: x.previa.join('/'), wr: pct(x.wr)})),
	};
	// 4
	if (flag === '--resposta') {
		const nossos = configs(membros(t1g));
		const r4 = [];
		for (const c of nossos) r4.push({...c, ...(await rodar(c, pior, N1, 41))});
		r4.sort((a, b) => b.wr - a.wr);
		const r5 = [];
		for (const c of r4.slice(0, 5)) r5.push({...c, ...(await rodar(c, pior, N2, 43))});
		r5.sort((a, b) => b.wr - a.wr);
		const melhor = r5[0];
		const c6 = await rodar(melhor, pior, N3, 47);
		res.resposta = {previa: melhor.previa, mega: melhor.mega, confirmacao: {v: c6.v, n: c6.n, wr: pct(c6.wr), ic: wilson(c6.v, c6.n).map(pct), megasA: c6.megasA, desmaiosA: c6.desmaiosA},
			top5: r5.map(x => ({previa: x.previa.join('/'), mega: x.mega && x.mega[0], wr: pct(x.wr)}))};
	}
	res.segundos = Math.round((Date.now() - t0) / 1000);
	console.log(JSON.stringify(res, null, 1));
})();
