// Jogo de prévias T1-G x adversário (28/out/2026), a partir do resultado de cores/adversario.js.
// Linhas: prévias nossas (bot + as 5 melhores da resposta); colunas: prévias deles (bot + as 6 piores
// para nós da fase 2). Cada célula com n batalhas. Resolve o jogo de soma zero: valor com estratégias
// puras (maximin) e com estratégias mistas (fictitious play, 20 mil iterações).
// Uso: node cores/matriz.js <time> [n=100] > cores/resultados-28out/adv/<time>-matriz.json
'use strict';
const fs = require('fs');
const {simular} = require('../simular.js');
const [,, T, N = 100] = process.argv;
const adv = JSON.parse(fs.readFileSync(`${process.env.DIR || 'cores/resultados/adv'}/${T}.json`, 'utf8'));
const t1g = fs.readFileSync(process.env.TIME || 'times/T1G.txt', 'utf8');
const opp = fs.readFileSync(adv.arquivo, 'utf8');
const conv = x => ({previa: x.previa.split('/'), mega: x.mega ? [x.mega] : undefined, rot: x.previa + (x.mega ? ' (M ' + x.mega + ')' : '')});
const nossas = [{rot: 'bot'}, ...(adv.resposta ? adv.resposta.top5.map(conv) : [])];
const deles = [{rot: 'bot'}, ...adv.fase2.slice(0, 6).map(conv)];
(async () => {
	const M = [];
	for (const [i, a] of nossas.entries()) {
		M.push([]);
		for (const [j, b] of deles.entries()) {
			const r = await simular(t1g, opp, {n: +N, nomes: ['T1G', 'OPP'], previaA: a.previa, megaA: a.mega, previaB: b.previa, megaB: b.mega,
				modeloB: 'cores/modelo_adversario.json', semente: 101 + 7 * i + j});
			M[i].push(r.stats.vitorias[0] / r.stats.batalhas);
		}
	}
	const minRow = M.map(r => Math.min(...r));
	const iPuro = minRow.indexOf(Math.max(...minRow));
	// fictitious play
	const R = M.length, C = M[0].length, cr = Array(R).fill(0), cc = Array(C).fill(0);
	const sr = Array(R).fill(0), sc = Array(C).fill(0);
	let i = 0, j = 0;
	for (let it = 0; it < 20000; it++) {
		cr[i]++; cc[j]++;
		for (let c = 0; c < C; c++) sc[c] += M[i][c];
		for (let r = 0; r < R; r++) sr[r] += M[r][j];
		i = sr.indexOf(Math.max(...sr)); j = sc.indexOf(Math.min(...sc));
	}
	const px = cr.map(x => x / 20000), py = cc.map(x => x / 20000);
	const valor = px.reduce((s, p, r) => s + p * py.reduce((t, q, c) => t + q * M[r][c], 0), 0);
	const pct = x => +(100 * x).toFixed(1);
	console.log(JSON.stringify({time: T, n: +N, linhas: nossas.map(x => x.rot), colunas: deles.map(x => x.rot),
		matriz: M.map(r => r.map(pct)), puro: {linha: nossas[iPuro].rot, valor: pct(minRow[iPuro])},
		misto: {valor: pct(valor), nossas: px.map(pct), deles: py.map(pct)}}, null, 1));
})();
