const fs=require('fs');const L=fs.readFileSync('confirm.jsonl','utf8').trim().split('\n').map(JSON.parse)
const short={Charizard:'Charizard','Gallade':'Gallade','Garchomp':'Garchomp-Z','Indeedee-F':'Indeedee','Volcarona':'Volcarona','Milotic':'Milotic'}
const wil=(k,n)=>{const z=1.96,p=k/n,d=1+z*z/n,c=(p+z*z/(2*n))/d,h=z*Math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d;return [100*(c-h),100*(c+h)]}
const key=r=>r.previa.slice(0,2).map(x=>short[x]).join(' + ')+' | '+r.previa.slice(2).map(x=>short[x]).join(', ')+' | Mega '+(r.mega[0]?short[r.mega[0]]:'-')
const g={};for(const r of L.filter(r=>!r.geral)){const k=r.core+'§'+key(r);g[k]=g[k]||{core:r.core,key:key(r),ref:!!r.ref,v:0,n:0,parts:{}};g[k].v+=r.v;g[k].n+=r.n;g[k].parts[r.opp]=Math.round(100*r.v/r.n)}
const out={};for(const c of [...new Set(L.map(r=>r.core))]){const rows=Object.values(g).filter(x=>x.core===c).sort((a,b)=>b.v/b.n-a.v/a.n);out[c]=rows
 console.log('\n'+c);for(const r of rows){const ic=wil(r.v,r.n);console.log(`  ${(100*r.v/r.n).toFixed(1)}% [${ic[0].toFixed(0)}–${ic[1].toFixed(0)}] ${JSON.stringify(r.parts)} ${r.key}${r.ref?'  ← §10.3':''}`)}}
const G={};for(const r of L.filter(r=>r.geral)){const k=key(r);G[k]=G[k]||{v:0,n:0,gref:!!r.gref,per:{}};G[k].v+=r.v;G[k].n+=r.n;G[k].per[r.core]=(G[k].per[r.core]||0)+r.v}
console.log('\nGERAL (11 cores oficiais)');for(const [k,x] of Object.entries(G).sort((a,b)=>b[1].v/b[1].n-a[1].v/a[1].n)){const ic=wil(x.v,x.n);console.log(`  ${(100*x.v/x.n).toFixed(1)}% [${ic[0].toFixed(1)}–${ic[1].toFixed(1)}] ${k}${x.gref?'  ← prévia geral da §10.3':''}`)}
fs.writeFileSync('rank.json',JSON.stringify({out,G},null,1))
